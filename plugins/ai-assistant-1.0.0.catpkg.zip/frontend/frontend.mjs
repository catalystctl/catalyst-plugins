//#region \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), s = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, c = (n, r, o) => (o = n == null ? {} : e(i(n)), s(r || !n || !n.__esModule || !a.call(n, "default") ? t(o, "default", {
	value: n,
	enumerable: !0
}) : o, n));
//#endregion
//#region ../sdk-frontend/plugin.ts
function l(e) {
	return {
		manifest: e.manifest,
		tabs: e.tabs,
		routes: e.routes,
		components: e.components,
		onMount: e.onMount,
		onUnmount: e.onUnmount
	};
}
//#endregion
//#region ../sdk-frontend/api.ts
var u = "";
async function d(e, t, n) {
	let { method: r = "GET", body: i, headers: a } = n ?? {}, o = `${u}/api/plugins/${e}/${t.replace(/^\//, "")}`;
	try {
		let e = await fetch(o, {
			method: r,
			credentials: "include",
			headers: {
				...i !== void 0 && !(i instanceof FormData) ? { "Content-Type": "application/json" } : {},
				...a
			},
			body: i === void 0 ? void 0 : i instanceof FormData ? i : JSON.stringify(i)
		});
		if (!e.ok) {
			let t = `HTTP ${e.status}`;
			try {
				let n = await e.json();
				t = n.error || n.message || t;
			} catch {}
			return {
				success: !1,
				error: t
			};
		}
		let t = await e.json();
		return t && typeof t == "object" && "success" in t ? t : {
			success: !0,
			data: t
		};
	} catch (e) {
		return {
			success: !1,
			error: e instanceof Error ? e.message : "Network error"
		};
	}
}
function f(e) {
	return {
		get(t) {
			return d(e, t);
		},
		post(t, n) {
			return d(e, t, {
				method: "POST",
				body: n
			});
		},
		put(t, n) {
			return d(e, t, {
				method: "PUT",
				body: n
			});
		},
		del(t) {
			return d(e, t, { method: "DELETE" });
		},
		delete(t) {
			return d(e, t, { method: "DELETE" });
		},
		patch(t, n) {
			return d(e, t, {
				method: "PATCH",
				body: n
			});
		}
	};
}
//#endregion
//#region ../node_modules/.pnpm/react@19.2.8/node_modules/react/cjs/react.production.js
var p = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element"), n = Symbol.for("react.consumer"), r = Symbol.for("react.context"), i = Symbol.for("react.forward_ref"), a = {
		isMounted: function() {
			return !1;
		},
		enqueueForceUpdate: function() {},
		enqueueReplaceState: function() {},
		enqueueSetState: function() {}
	}, o = Object.assign, s = {};
	function c(e, t, n) {
		this.props = e, this.context = t, this.refs = s, this.updater = n || a;
	}
	c.prototype.isReactComponent = {}, c.prototype.setState = function(e, t) {
		if (typeof e != "object" && typeof e != "function" && e != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
		this.updater.enqueueSetState(this, e, t, "setState");
	}, c.prototype.forceUpdate = function(e) {
		this.updater.enqueueForceUpdate(this, e, "forceUpdate");
	};
	function l() {}
	l.prototype = c.prototype;
	function u(e, t, n) {
		this.props = e, this.context = t, this.refs = s, this.updater = n || a;
	}
	var d = u.prototype = new l();
	d.constructor = u, o(d, c.prototype), d.isPureReactComponent = !0, Array.isArray;
	var f = {
		H: null,
		A: null,
		T: null,
		S: null
	}, p = Object.prototype.hasOwnProperty;
	function m(e, n, r) {
		var i = r.ref;
		return {
			$$typeof: t,
			type: e,
			key: n,
			ref: i === void 0 ? null : i,
			props: r
		};
	}
	e.Component = c, e.createContext = function(e) {
		return e = {
			$$typeof: r,
			_currentValue: e,
			_currentValue2: e,
			_threadCount: 0,
			Provider: null,
			Consumer: null
		}, e.Provider = e, e.Consumer = {
			$$typeof: n,
			_context: e
		}, e;
	}, e.createElement = function(e, t, n) {
		var r, i = {}, a = null;
		if (t != null) for (r in t.key !== void 0 && (a = "" + t.key), t) p.call(t, r) && r !== "key" && r !== "__self" && r !== "__source" && (i[r] = t[r]);
		var o = arguments.length - 2;
		if (o === 1) i.children = n;
		else if (1 < o) {
			for (var s = Array(o), c = 0; c < o; c++) s[c] = arguments[c + 2];
			i.children = s;
		}
		if (e && e.defaultProps) for (r in o = e.defaultProps, o) i[r] === void 0 && (i[r] = o[r]);
		return m(e, a, i);
	}, e.forwardRef = function(e) {
		return {
			$$typeof: i,
			render: e
		};
	}, e.useCallback = function(e, t) {
		return f.H.useCallback(e, t);
	}, e.useContext = function(e) {
		return f.H.useContext(e);
	}, e.useEffect = function(e, t) {
		return f.H.useEffect(e, t);
	}, e.useRef = function(e) {
		return f.H.useRef(e);
	}, e.useState = function(e) {
		return f.H.useState(e);
	};
})), m = /* @__PURE__ */ c((/* @__PURE__ */ o(((e, t) => {
	t.exports = p();
})))(), 1);
m.Component;
//#endregion
//#region ../node_modules/.pnpm/lucide-react@1.31.0_react@19.2.8/node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs
var h = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), g = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), _ = (e) => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()), v = (e) => {
	let t = _(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, y = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "round",
	strokeLinejoin: "round"
}, b = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, x = (0, m.createContext)({}), S = () => (0, m.useContext)(x), C = (0, m.forwardRef)(({ color: e, size: t, strokeWidth: n, absoluteStrokeWidth: r, className: i = "", children: a, iconNode: o, ...s }, c) => {
	let { size: l = 24, strokeWidth: u = 2, absoluteStrokeWidth: d = !1, color: f = "currentColor", className: p = "" } = S() ?? {}, g = r ?? d ? Number(n ?? u) * 24 / Number(t ?? l) : n ?? u;
	return (0, m.createElement)("svg", {
		ref: c,
		...y,
		width: t ?? l ?? y.width,
		height: t ?? l ?? y.height,
		stroke: e ?? f,
		strokeWidth: g,
		className: h("lucide", p, i),
		...!a && !b(s) && { "aria-hidden": "true" },
		...s
	}, [...o.map(([e, t]) => (0, m.createElement)(e, t)), ...Array.isArray(a) ? a : [a]]);
}), w = (e, t) => {
	let n = (0, m.forwardRef)(({ className: n, ...r }, i) => (0, m.createElement)(C, {
		ref: i,
		iconNode: t,
		className: h(`lucide-${g(v(e))}`, `lucide-${e}`, n),
		...r
	}));
	return n.displayName = v(e), n;
}, T = w("bot", [
	["path", {
		d: "M12 8V4H8",
		key: "hb8ula"
	}],
	["rect", {
		width: "16",
		height: "12",
		x: "4",
		y: "8",
		rx: "2",
		key: "enze0r"
	}],
	["path", {
		d: "M2 14h2",
		key: "vft8re"
	}],
	["path", {
		d: "M20 14h2",
		key: "4cs60a"
	}],
	["path", {
		d: "M15 13v2",
		key: "1xurst"
	}],
	["path", {
		d: "M9 13v2",
		key: "rq6x2g"
	}]
]), E = w("circle-check", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}], ["path", {
	d: "m9 12 2 2 4-4",
	key: "dzmm74"
}]]), D = w("copy", [["rect", {
	width: "14",
	height: "14",
	x: "8",
	y: "8",
	rx: "2",
	ry: "2",
	key: "17jyea"
}], ["path", {
	d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
	key: "zix9uf"
}]]), O = w("loader-circle", [["path", {
	d: "M21 12a9 9 0 1 1-6.219-8.56",
	key: "13zald"
}]]), k = w("plus", [["path", {
	d: "M5 12h14",
	key: "1ays0h"
}], ["path", {
	d: "M12 5v14",
	key: "s699le"
}]]), A = w("send", [["path", {
	d: "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",
	key: "1ffxy3"
}], ["path", {
	d: "m21.854 2.147-10.94 10.939",
	key: "12cjpa"
}]]), j = w("server", [
	["rect", {
		width: "20",
		height: "8",
		x: "2",
		y: "2",
		rx: "2",
		ry: "2",
		key: "ngkwjq"
	}],
	["rect", {
		width: "20",
		height: "8",
		x: "2",
		y: "14",
		rx: "2",
		ry: "2",
		key: "iecqi9"
	}],
	["line", {
		x1: "6",
		x2: "6.01",
		y1: "6",
		y2: "6",
		key: "16zg32"
	}],
	["line", {
		x1: "6",
		x2: "6.01",
		y1: "18",
		y2: "18",
		key: "nzw8ys"
	}]
]), M = w("trash-2", [
	["path", {
		d: "M10 11v6",
		key: "nco0om"
	}],
	["path", {
		d: "M14 11v6",
		key: "outv1u"
	}],
	["path", {
		d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",
		key: "miytrc"
	}],
	["path", {
		d: "M3 6h18",
		key: "d0wm0j"
	}],
	["path", {
		d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
		key: "e791ji"
	}]
]), N = w("triangle-alert", [
	["path", {
		d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
		key: "wmoenq"
	}],
	["path", {
		d: "M12 9v4",
		key: "juzpu7"
	}],
	["path", {
		d: "M12 17h.01",
		key: "p32p05"
	}]
]), P = w("wrench", [["path", {
	d: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z",
	key: "1ngwbx"
}]]), F = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element");
	function n(e, n, r) {
		var i = null;
		if (r !== void 0 && (i = "" + r), n.key !== void 0 && (i = "" + n.key), "key" in n) for (var a in r = {}, n) a !== "key" && (r[a] = n[a]);
		else r = n;
		return n = r.ref, {
			$$typeof: t,
			type: e,
			key: i,
			ref: n === void 0 ? null : n,
			props: r
		};
	}
	e.jsx = n, e.jsxs = n;
})), I = (/* @__PURE__ */ o(((e, t) => {
	t.exports = F();
})))(), L = "text-muted-foreground", R = "font-mono", z = (...e) => e.filter(Boolean).join(" ");
function B({ variant: e = "default", size: t = "default", className: n, ...r }) {
	return /* @__PURE__ */ (0, I.jsx)("button", {
		className: z("inline-flex items-center justify-center gap-1.5 rounded-md font-medium transition-colors disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring", {
			default: "h-9 px-4 py-2 text-sm",
			sm: "h-7 rounded-md px-2.5 text-xs"
		}[t], {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			outline: "border border-border bg-transparent shadow-sm hover:bg-accent hover:text-accent-foreground",
			ghost: "hover:bg-accent hover:text-accent-foreground"
		}[e], n),
		...r
	});
}
function V({ value: e, onValueChange: t, placeholder: n, children: r }) {
	return /* @__PURE__ */ (0, I.jsxs)("select", {
		className: "flex h-9 w-full items-center rounded-md border border-border bg-transparent px-3 py-1 text-sm shadow-sm focus:outline-none focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
		value: e || "",
		onChange: (e) => t(e.target.value),
		children: [/* @__PURE__ */ (0, I.jsx)("option", {
			value: "",
			children: n ?? "Select…"
		}), r]
	});
}
function H({ value: e, children: t }) {
	return /* @__PURE__ */ (0, I.jsx)("option", {
		value: e,
		className: "bg-popover text-popover-foreground",
		children: t
	});
}
function U(e) {
	return /* @__PURE__ */ (0, I.jsx)("textarea", {
		...e,
		className: z("flex min-h-[80px] w-full rounded-md border border-border bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", e.className)
	});
}
function W({ children: e, tone: t = "default" }) {
	return /* @__PURE__ */ (0, I.jsx)("span", {
		className: z("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium", {
			default: "border-border bg-muted text-muted-foreground",
			ok: "border-emerald-700/40 bg-emerald-950/40 text-emerald-300",
			warn: "border-amber-700/40 bg-amber-950/40 text-amber-300",
			bad: "border-red-700/40 bg-red-950/40 text-red-300"
		}[t]),
		children: e
	});
}
function G({ className: e }) {
	return /* @__PURE__ */ (0, I.jsx)("div", { className: z("animate-pulse rounded-md bg-muted", e) });
}
function K({ children: e, className: t }) {
	return /* @__PURE__ */ (0, I.jsx)("div", {
		className: z("rounded-lg border border-border bg-card p-4", t),
		children: e
	});
}
//#endregion
//#region frontend/api.ts
var q = f("ai-assistant");
async function J() {
	let e = await q.get("/status");
	if (!e.success) throw Error(e.error || "Failed to load provider status");
	return e;
}
async function Y() {
	let e = await q.post("/provider/test", {});
	if (!e.success) throw Error(e.error || "Provider test failed");
	return e;
}
async function ee() {
	let e = await q.get("/servers");
	if (!e.success) throw Error(e.error || "Failed to list servers");
	return e.servers ?? [];
}
async function X(e) {
	let t = e ? `?serverId=${encodeURIComponent(e)}` : "", n = await q.get(`/conversations${t}`);
	if (!n.success) throw Error(n.error || "Failed to list conversations");
	return n.conversations ?? [];
}
async function Z(e) {
	let t = await q.post("/conversations", {
		serverId: e?.serverId ?? null,
		title: e?.title ?? "New conversation"
	});
	if (!t.success) throw Error(t.error || "Failed to create conversation");
	return t.conversation;
}
async function te(e) {
	let t = await q.get(`/conversations/${e}`);
	if (!t.success) throw Error(t.error || "Failed to load conversation");
	return t;
}
async function ne(e) {
	let t = await q.del(`/conversations/${e}`);
	if (!t.success) throw Error(t.error || "Failed to delete conversation");
}
async function re(e, t) {
	let n = await q.post(`/conversations/${e}/chat`, t);
	if (!n.success) throw Error(n.error || "Chat failed");
	return n;
}
//#endregion
//#region frontend/components.tsx
var Q = [
	{
		label: "Review startup config",
		prompt: "Review this server’s startup command and environment variables. Point out anything misconfigured or risky, and tell me exactly what to change."
	},
	{
		label: "Diagnose crash loop",
		prompt: "This server keeps crashing or fails to start. Read its config files and tell me the most likely causes in order, with the exact file lines or settings behind each one."
	},
	{
		label: "Which files to check?",
		prompt: "List the config and log files I should check first for this kind of server, then read the most important ones and summarize what you find."
	}
];
function ie(e) {
	if (!e) return "";
	let t = Math.max(0, (Date.now() - Date.parse(e)) / 1e3);
	return t < 60 ? `${Math.floor(t)}s ago` : t < 3600 ? `${Math.floor(t / 60)}m ago` : t < 86400 ? `${Math.floor(t / 3600)}h ago` : `${Math.floor(t / 86400)}d ago`;
}
function ae({ msg: e }) {
	let [t, n] = (0, m.useState)(!1), r = e.role === "user";
	return /* @__PURE__ */ (0, I.jsx)("div", {
		className: `flex ${r ? "justify-end" : "justify-start"}`,
		children: /* @__PURE__ */ (0, I.jsxs)("div", {
			className: `max-w-[85%] rounded-lg border px-3 py-2 text-sm ${r ? "border-primary/30 bg-primary/10" : "border-border bg-card"}`,
			children: [
				/* @__PURE__ */ (0, I.jsxs)("div", {
					className: "mb-1 flex items-center gap-1.5 text-[11px]",
					style: { color: "var(--muted-foreground)" },
					children: [
						r ? null : /* @__PURE__ */ (0, I.jsx)(T, { className: "h-3 w-3" }),
						/* @__PURE__ */ (0, I.jsx)("span", { children: r ? "You" : "Assistant" }),
						e.createdAt ? /* @__PURE__ */ (0, I.jsxs)("span", { children: ["· ", ie(e.createdAt)] }) : null,
						/* @__PURE__ */ (0, I.jsx)("button", {
							onClick: () => {
								try {
									navigator.clipboard?.writeText(e.content).then(() => {
										n(!0), setTimeout(() => n(!1), 1200);
									});
								} catch {}
							},
							className: "ml-auto opacity-60 hover:opacity-100",
							"aria-label": "Copy message",
							children: /* @__PURE__ */ (0, I.jsx)(D, { className: "h-3 w-3" })
						}),
						t ? /* @__PURE__ */ (0, I.jsx)("span", {
							className: "text-emerald-400",
							children: "copied"
						}) : null
					]
				}),
				/* @__PURE__ */ (0, I.jsx)("div", {
					className: "whitespace-pre-wrap break-words",
					children: e.content
				}),
				e.toolTrace && e.toolTrace.length > 0 && /* @__PURE__ */ (0, I.jsx)("details", {
					className: "mt-2 text-xs",
					style: { color: "var(--muted-foreground)" },
					children: /* @__PURE__ */ (0, I.jsxs)("summary", {
						className: "cursor-pointer",
						children: [
							/* @__PURE__ */ (0, I.jsx)(P, { className: "mr-1 inline h-3 w-3" }),
							"Checked ",
							e.toolTrace.length,
							" source",
							e.toolTrace.length === 1 ? "" : "s",
							" (",
							e.toolTrace.map((e) => e.tool).join(", "),
							")"
						]
					})
				})
			]
		})
	});
}
function oe({ status: e }) {
	return e ? e.hasApiKey ? /* @__PURE__ */ (0, I.jsxs)(W, {
		tone: "ok",
		children: [
			/* @__PURE__ */ (0, I.jsx)(E, { className: "h-3 w-3" }),
			" ",
			e.model,
			" · ",
			e.provider
		]
	}) : /* @__PURE__ */ (0, I.jsx)(W, {
		tone: "warn",
		children: "No API key — open plugin Settings"
	}) : /* @__PURE__ */ (0, I.jsx)(W, { children: "loading…" });
}
function se(e) {
	let [t, n] = (0, m.useState)(null), [r, i] = (0, m.useState)(null), [a, o] = (0, m.useState)([]), [s, c] = (0, m.useState)(null), [l, u] = (0, m.useState)([]), [d, f] = (0, m.useState)(e ?? ""), [p, h] = (0, m.useState)(""), [g, _] = (0, m.useState)(""), [v, y] = (0, m.useState)(!1), [b, x] = (0, m.useState)(!1), [S, C] = (0, m.useState)(null), [w, T] = (0, m.useState)(!1), [E, D] = (0, m.useState)(null), O = (0, m.useRef)(null);
	(0, m.useEffect)(() => {
		e && f(e);
	}, [e]);
	let k = (0, m.useCallback)(async () => {
		try {
			let [t, r] = await Promise.all([J(), ee()]);
			n(t), i(r);
			let a = await X(e ?? void 0);
			o(a), !s && a.length > 0 && c(a[0].id);
		} catch (e) {
			C(e?.message ?? "Failed to load");
		}
	}, [e, s]);
	(0, m.useEffect)(() => {
		k();
	}, [k]);
	let A = (0, m.useCallback)(async (e) => {
		c(e), x(!0), C(null);
		try {
			let { conversation: t, messages: n } = await te(e);
			u(n), t.serverId && f(t.serverId);
		} catch (e) {
			C(e?.message ?? "Failed to load conversation");
		} finally {
			x(!1);
		}
	}, []);
	return (0, m.useEffect)(() => {
		s && A(s);
	}, [s, A]), (0, m.useEffect)(() => {
		O.current?.scrollIntoView({
			behavior: "smooth",
			block: "end"
		});
	}, [l, v]), {
		status: t,
		servers: r,
		conversations: a,
		activeId: s,
		setActiveId: c,
		messages: l,
		serverId: d,
		setServerId: f,
		input: p,
		setInput: h,
		pastedLogs: g,
		setPastedLogs: _,
		sending: v,
		loadingMsgs: b,
		error: S,
		testing: w,
		testResult: E,
		bottomRef: O,
		refreshAll: k,
		loadConversation: A,
		newConversation: async () => {
			try {
				let e = await Z({ serverId: d || null });
				o((t) => [e, ...t]), c(e.id), u([]);
			} catch (e) {
				C(e?.message ?? "Failed to create conversation");
			}
		},
		removeConversation: async (e) => {
			try {
				await ne(e), o((t) => t.filter((t) => t.id !== e)), s === e && (c(null), u([]));
			} catch (e) {
				C(e?.message ?? "Delete failed");
			}
		},
		send: async (t) => {
			let n = (t ?? p).trim();
			if (!n || v) return;
			C(null);
			let r = s;
			if (!r) try {
				let e = await Z({ serverId: d || null });
				r = e.id, o((t) => [e, ...t]), c(r);
			} catch (e) {
				C(e?.message ?? "Failed to create conversation");
				return;
			}
			let i = {
				role: "user",
				content: n,
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			};
			u((e) => [...e, i]), h("");
			let a = g;
			_(""), y(!0);
			try {
				let t = await re(r, {
					message: n,
					serverId: d || null,
					pastedLogs: a || void 0
				});
				u((e) => [...e, {
					role: "assistant",
					content: t.reply,
					toolTrace: t.toolTrace,
					createdAt: (/* @__PURE__ */ new Date()).toISOString()
				}]);
				let i = await X(e ?? void 0);
				o(i);
			} catch (e) {
				C(e?.message ?? "Chat failed");
			} finally {
				y(!1);
			}
		},
		test: async () => {
			T(!0), D(null);
			try {
				let e = await Y();
				D(`OK · ${e.model} · ${e.latencyMs}ms`);
			} catch (e) {
				D(`Failed: ${e?.message ?? "unknown error"}`);
			} finally {
				T(!1);
			}
		}
	};
}
function $({ lockedServerId: e }) {
	let t = e ?? null, n = se(t), r = n.conversations.find((e) => e.id === n.activeId) ?? null, i = n.servers?.find((e) => e.id === n.serverId || e.uuid === n.serverId)?.name;
	return /* @__PURE__ */ (0, I.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, I.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, I.jsxs)("h2", {
						className: "flex items-center gap-2 text-2xl font-bold",
						children: [/* @__PURE__ */ (0, I.jsx)(T, { className: "h-6 w-6 text-violet-400" }), " AI Assistant"]
					}),
					/* @__PURE__ */ (0, I.jsx)(oe, { status: n.status }),
					n.status && !n.status.fileTunnelAvailable && /* @__PURE__ */ (0, I.jsx)(W, {
						tone: "warn",
						children: "File tunnel unavailable"
					}),
					/* @__PURE__ */ (0, I.jsxs)("div", {
						className: "ml-auto flex items-center gap-2",
						children: [/* @__PURE__ */ (0, I.jsxs)(B, {
							size: "sm",
							variant: "outline",
							onClick: n.test,
							disabled: n.testing,
							children: [n.testing ? /* @__PURE__ */ (0, I.jsx)(O, { className: "h-3.5 w-3.5 animate-spin" }) : null, " Test connection"]
						}), /* @__PURE__ */ (0, I.jsxs)(B, {
							size: "sm",
							variant: "outline",
							onClick: n.newConversation,
							children: [/* @__PURE__ */ (0, I.jsx)(k, { className: "h-3.5 w-3.5" }), " New chat"]
						})]
					})
				]
			}),
			n.testResult && /* @__PURE__ */ (0, I.jsxs)("div", {
				className: "flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-xs",
				style: { color: "text-muted-foreground" },
				children: [n.testResult.startsWith("OK") ? /* @__PURE__ */ (0, I.jsx)(E, { className: "h-4 w-4 text-emerald-400" }) : /* @__PURE__ */ (0, I.jsx)(N, { className: "h-4 w-4 text-amber-400" }), /* @__PURE__ */ (0, I.jsx)("span", {
					style: { fontFamily: "font-mono" },
					children: n.testResult
				})]
			}),
			n.error && /* @__PURE__ */ (0, I.jsxs)("div", {
				className: "flex items-center gap-2 rounded-lg border border-amber-700/40 bg-amber-950/30 px-3 py-2 text-sm text-amber-300",
				children: [
					/* @__PURE__ */ (0, I.jsx)(N, { className: "h-4 w-4 shrink-0" }),
					" ",
					n.error
				]
			}),
			/* @__PURE__ */ (0, I.jsxs)("div", {
				className: "grid grid-cols-1 gap-4 lg:grid-cols-[280px_1fr]",
				children: [/* @__PURE__ */ (0, I.jsxs)("div", {
					className: "space-y-3",
					children: [
						!t && /* @__PURE__ */ (0, I.jsxs)(K, { children: [
							/* @__PURE__ */ (0, I.jsxs)("div", {
								className: "mb-2 text-xs font-semibold uppercase tracking-wide",
								style: { color: "text-muted-foreground" },
								children: [/* @__PURE__ */ (0, I.jsx)(j, { className: "mr-1 inline h-3.5 w-3.5" }), " Server context"]
							}),
							n.servers === null ? /* @__PURE__ */ (0, I.jsx)(G, { className: "h-9 w-full" }) : /* @__PURE__ */ (0, I.jsx)(V, {
								value: n.serverId,
								onValueChange: n.setServerId,
								placeholder: "No server (general chat)",
								children: (n.servers ?? []).map((e) => /* @__PURE__ */ (0, I.jsxs)(H, {
									value: e.id,
									children: [
										e.name,
										" · ",
										e.status
									]
								}, e.id))
							}),
							i && /* @__PURE__ */ (0, I.jsxs)("div", {
								className: "mt-1 text-xs",
								style: { color: "text-muted-foreground" },
								children: ["Chatting about ", i]
							})
						] }),
						/* @__PURE__ */ (0, I.jsxs)(K, { children: [/* @__PURE__ */ (0, I.jsx)("div", {
							className: "mb-2 text-xs font-semibold uppercase tracking-wide",
							style: { color: L },
							children: "Conversations"
						}), /* @__PURE__ */ (0, I.jsxs)("div", {
							className: "max-h-64 space-y-1 overflow-y-auto",
							children: [n.conversations.length === 0 && /* @__PURE__ */ (0, I.jsx)("div", {
								className: "text-xs",
								style: { color: "text-muted-foreground" },
								children: "No conversations yet."
							}), n.conversations.map((e) => /* @__PURE__ */ (0, I.jsxs)("div", {
								className: `group flex items-center gap-1 rounded-md px-2 py-1.5 text-xs ${e.id === n.activeId ? "bg-accent" : "hover:bg-accent/60"}`,
								children: [/* @__PURE__ */ (0, I.jsx)("button", {
									className: "min-w-0 flex-1 truncate text-left",
									onClick: () => n.setActiveId(e.id),
									title: e.title,
									children: e.title || "Untitled"
								}), /* @__PURE__ */ (0, I.jsx)("button", {
									className: "shrink-0 opacity-0 group-hover:opacity-100",
									onClick: () => n.removeConversation(e.id),
									"aria-label": "Delete conversation",
									children: /* @__PURE__ */ (0, I.jsx)(M, { className: "h-3 w-3 text-red-400" })
								})]
							}, e.id))]
						})] }),
						t && /* @__PURE__ */ (0, I.jsxs)(K, { children: [/* @__PURE__ */ (0, I.jsx)("div", {
							className: "mb-2 text-xs font-semibold uppercase tracking-wide",
							style: { color: "text-muted-foreground" },
							children: "Quick diagnostics"
						}), /* @__PURE__ */ (0, I.jsx)("div", {
							className: "flex flex-col gap-1.5",
							children: Q.map((e) => /* @__PURE__ */ (0, I.jsx)(B, {
								size: "sm",
								variant: "outline",
								onClick: () => n.send(e.prompt),
								children: e.label
							}, e.label))
						})] })
					]
				}), /* @__PURE__ */ (0, I.jsxs)(K, {
					className: "flex min-h-[480px] flex-col",
					children: [!n.activeId && n.messages.length === 0 ? /* @__PURE__ */ (0, I.jsxs)("div", {
						className: "flex flex-1 flex-col items-center justify-center gap-2 p-8 text-center text-sm",
						style: { color: L },
						children: [
							/* @__PURE__ */ (0, I.jsx)(T, { className: "h-8 w-8 opacity-50" }),
							/* @__PURE__ */ (0, I.jsx)("div", {
								className: "font-semibold text-foreground",
								children: "Ask about a server, paste a crash log, or review a config."
							}),
							/* @__PURE__ */ (0, I.jsx)("div", {
								className: "max-w-md text-xs",
								children: "The assistant can look up server settings and read server files itself. For console output, paste it below under “Attach logs” so it can cite the exact failing lines."
							}),
							!t && /* @__PURE__ */ (0, I.jsx)("div", {
								className: "mt-2 flex flex-wrap justify-center gap-1.5",
								children: Q.map((e) => /* @__PURE__ */ (0, I.jsx)(B, {
									size: "sm",
									variant: "outline",
									onClick: () => n.send(e.prompt),
									children: e.label
								}, e.label))
							})
						]
					}) : n.loadingMsgs ? /* @__PURE__ */ (0, I.jsxs)("div", {
						className: "flex-1 space-y-2 p-2",
						children: [/* @__PURE__ */ (0, I.jsx)(G, { className: "h-16 w-full" }), /* @__PURE__ */ (0, I.jsx)(G, { className: "h-16 w-full" })]
					}) : /* @__PURE__ */ (0, I.jsxs)("div", {
						className: "flex-1 space-y-3 overflow-y-auto p-1",
						style: { maxHeight: 520 },
						children: [
							n.messages.map((e, t) => /* @__PURE__ */ (0, I.jsx)(ae, { msg: e }, (e._id ?? t) + String(t))),
							n.sending && /* @__PURE__ */ (0, I.jsxs)("div", {
								className: "flex items-center gap-2 text-xs",
								style: { color: "text-muted-foreground" },
								children: [
									/* @__PURE__ */ (0, I.jsx)(O, { className: "h-3.5 w-3.5 animate-spin" }),
									" Thinking",
									r ? "" : "…",
									" — reading servers/files as needed…"
								]
							}),
							/* @__PURE__ */ (0, I.jsx)("div", { ref: n.bottomRef })
						]
					}), /* @__PURE__ */ (0, I.jsxs)("div", {
						className: "mt-3 space-y-2 border-t border-border pt-3",
						children: [
							/* @__PURE__ */ (0, I.jsxs)("details", { children: [
								/* @__PURE__ */ (0, I.jsx)("summary", {
									className: "cursor-pointer text-xs",
									style: { color: L },
									children: "Attach logs (paste console output for analysis)"
								}),
								/* @__PURE__ */ (0, I.jsx)(U, {
									className: "mt-2",
									style: { fontFamily: R },
									placeholder: "Paste server.log / console output here…",
									value: n.pastedLogs,
									onChange: (e) => n.setPastedLogs(e.target.value),
									rows: 5
								}),
								n.pastedLogs && /* @__PURE__ */ (0, I.jsxs)("div", {
									className: "text-[11px]",
									style: { color: "text-muted-foreground" },
									children: [n.pastedLogs.length, " chars attached"]
								})
							] }),
							/* @__PURE__ */ (0, I.jsxs)("div", {
								className: "flex items-end gap-2",
								children: [/* @__PURE__ */ (0, I.jsx)(U, {
									placeholder: n.serverId ? `Ask about ${i ?? "this server"}…` : "Ask anything… (pick a server for grounded answers)",
									value: n.input,
									onChange: (e) => n.setInput(e.target.value),
									onKeyDown: (e) => {
										e.key === "Enter" && !e.shiftKey && (e.preventDefault(), n.send());
									},
									rows: 2
								}), /* @__PURE__ */ (0, I.jsx)(B, {
									onClick: () => n.send(),
									disabled: n.sending || !n.input.trim(),
									children: n.sending ? /* @__PURE__ */ (0, I.jsx)(O, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, I.jsx)(A, { className: "h-4 w-4" })
								})]
							}),
							n.status && !n.status.hasApiKey && /* @__PURE__ */ (0, I.jsx)("div", {
								className: "text-xs text-amber-300",
								children: "No API key configured. Ask the panel owner to set one in Admin → Plugins → AI Assistant → Settings."
							})
						]
					})]
				})]
			})
		]
	});
}
function ce() {
	return /* @__PURE__ */ (0, I.jsx)($, { lockedServerId: null });
}
function le({ serverId: e }) {
	return /* @__PURE__ */ (0, I.jsx)($, { lockedServerId: e });
}
//#endregion
//#region frontend/index.ts
var ue = l({
	manifest: {
		name: "ai-assistant",
		version: "1.0.0",
		displayName: "AI Assistant",
		description: "Chat assistant for server configuration, file inspection and log diagnosis",
		author: "Catalyst Team"
	},
	tabs: [{
		id: "ai-admin",
		label: "AI Assistant",
		icon: "Bot",
		component: ce,
		location: "admin",
		order: 60,
		requiredPermissions: ["admin.read"]
	}, {
		id: "ai-server",
		label: "AI Assistant",
		icon: "Bot",
		component: le,
		location: "server",
		order: 60,
		requiredPermissions: ["server.read"]
	}]
});
//#endregion
export { ue as default };
