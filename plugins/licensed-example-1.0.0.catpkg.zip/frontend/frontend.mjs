//#region \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), s = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, c = (n, r, o) => (o = n == null ? {} : e(i(n)), s(r || !n || !n.__esModule || !a.call(n, "default") ? t(o, "default", {
	value: n,
	enumerable: !0
}) : o, n));
//#endregion
//#region ../sdk-frontend/plugin.ts
function l(e) {
	return {
		manifest: e.manifest,
		tabs: e.tabs,
		routes: e.routes,
		components: e.components,
		onMount: e.onMount,
		onUnmount: e.onUnmount
	};
}
//#endregion
//#region ../sdk-frontend/api.ts
var u = "";
async function d(e, t, n) {
	let { method: r = "GET", body: i, headers: a } = n ?? {}, o = `${u}/api/plugins/${e}/${t.replace(/^\//, "")}`;
	try {
		let e = await fetch(o, {
			method: r,
			credentials: "include",
			headers: {
				...i !== void 0 && !(i instanceof FormData) ? { "Content-Type": "application/json" } : {},
				...a
			},
			body: i === void 0 ? void 0 : i instanceof FormData ? i : JSON.stringify(i)
		});
		if (!e.ok) {
			let t = `HTTP ${e.status}`;
			try {
				let n = await e.json();
				t = n.error || n.message || t;
			} catch {}
			return {
				success: !1,
				error: t
			};
		}
		let t = await e.json();
		return t && typeof t == "object" && "success" in t ? t : {
			success: !0,
			data: t
		};
	} catch (e) {
		return {
			success: !1,
			error: e instanceof Error ? e.message : "Network error"
		};
	}
}
function f(e) {
	return {
		get(t) {
			return d(e, t);
		},
		post(t, n) {
			return d(e, t, {
				method: "POST",
				body: n
			});
		},
		put(t, n) {
			return d(e, t, {
				method: "PUT",
				body: n
			});
		},
		del(t) {
			return d(e, t, { method: "DELETE" });
		},
		delete(t) {
			return d(e, t, { method: "DELETE" });
		},
		patch(t, n) {
			return d(e, t, {
				method: "PATCH",
				body: n
			});
		}
	};
}
//#endregion
//#region ../node_modules/.pnpm/react@19.2.8/node_modules/react/cjs/react.production.js
var p = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element"), n = Symbol.for("react.consumer"), r = Symbol.for("react.context"), i = Symbol.for("react.forward_ref"), a = {
		isMounted: function() {
			return !1;
		},
		enqueueForceUpdate: function() {},
		enqueueReplaceState: function() {},
		enqueueSetState: function() {}
	}, o = Object.assign, s = {};
	function c(e, t, n) {
		this.props = e, this.context = t, this.refs = s, this.updater = n || a;
	}
	c.prototype.isReactComponent = {}, c.prototype.setState = function(e, t) {
		if (typeof e != "object" && typeof e != "function" && e != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
		this.updater.enqueueSetState(this, e, t, "setState");
	}, c.prototype.forceUpdate = function(e) {
		this.updater.enqueueForceUpdate(this, e, "forceUpdate");
	};
	function l() {}
	l.prototype = c.prototype;
	function u(e, t, n) {
		this.props = e, this.context = t, this.refs = s, this.updater = n || a;
	}
	var d = u.prototype = new l();
	d.constructor = u, o(d, c.prototype), d.isPureReactComponent = !0, Array.isArray;
	var f = {
		H: null,
		A: null,
		T: null,
		S: null
	}, p = Object.prototype.hasOwnProperty;
	function m(e, n, r) {
		var i = r.ref;
		return {
			$$typeof: t,
			type: e,
			key: n,
			ref: i === void 0 ? null : i,
			props: r
		};
	}
	e.Component = c, e.createContext = function(e) {
		return e = {
			$$typeof: r,
			_currentValue: e,
			_currentValue2: e,
			_threadCount: 0,
			Provider: null,
			Consumer: null
		}, e.Provider = e, e.Consumer = {
			$$typeof: n,
			_context: e
		}, e;
	}, e.createElement = function(e, t, n) {
		var r, i = {}, a = null;
		if (t != null) for (r in t.key !== void 0 && (a = "" + t.key), t) p.call(t, r) && r !== "key" && r !== "__self" && r !== "__source" && (i[r] = t[r]);
		var o = arguments.length - 2;
		if (o === 1) i.children = n;
		else if (1 < o) {
			for (var s = Array(o), c = 0; c < o; c++) s[c] = arguments[c + 2];
			i.children = s;
		}
		if (e && e.defaultProps) for (r in o = e.defaultProps, o) i[r] === void 0 && (i[r] = o[r]);
		return m(e, a, i);
	}, e.forwardRef = function(e) {
		return {
			$$typeof: i,
			render: e
		};
	}, e.useCallback = function(e, t) {
		return f.H.useCallback(e, t);
	}, e.useContext = function(e) {
		return f.H.useContext(e);
	}, e.useState = function(e) {
		return f.H.useState(e);
	};
})), m = /* @__PURE__ */ c((/* @__PURE__ */ o(((e, t) => {
	t.exports = p();
})))(), 1);
m.Component;
//#endregion
//#region ../node_modules/.pnpm/lucide-react@1.31.0_react@19.2.8/node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs
var h = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), g = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), _ = (e) => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()), v = (e) => {
	let t = _(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, y = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "round",
	strokeLinejoin: "round"
}, b = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, x = (0, m.createContext)({}), S = () => (0, m.useContext)(x), C = (0, m.forwardRef)(({ color: e, size: t, strokeWidth: n, absoluteStrokeWidth: r, className: i = "", children: a, iconNode: o, ...s }, c) => {
	let { size: l = 24, strokeWidth: u = 2, absoluteStrokeWidth: d = !1, color: f = "currentColor", className: p = "" } = S() ?? {}, g = r ?? d ? Number(n ?? u) * 24 / Number(t ?? l) : n ?? u;
	return (0, m.createElement)("svg", {
		ref: c,
		...y,
		width: t ?? l ?? y.width,
		height: t ?? l ?? y.height,
		stroke: e ?? f,
		strokeWidth: g,
		className: h("lucide", p, i),
		...!a && !b(s) && { "aria-hidden": "true" },
		...s
	}, [...o.map(([e, t]) => (0, m.createElement)(e, t)), ...Array.isArray(a) ? a : [a]]);
}), w = (e, t) => {
	let n = (0, m.forwardRef)(({ className: n, ...r }, i) => (0, m.createElement)(C, {
		ref: i,
		iconNode: t,
		className: h(`lucide-${g(v(e))}`, `lucide-${e}`, n),
		...r
	}));
	return n.displayName = v(e), n;
}, T = w("key-round", [["path", {
	d: "M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",
	key: "1s6t7t"
}], ["circle", {
	cx: "16.5",
	cy: "7.5",
	r: ".5",
	fill: "currentColor",
	key: "w0ekpg"
}]]), E = w("loader-circle", [["path", {
	d: "M21 12a9 9 0 1 1-6.219-8.56",
	key: "13zald"
}]]), D = w("refresh-cw", [
	["path", {
		d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
		key: "v9h5vc"
	}],
	["path", {
		d: "M21 3v5h-5",
		key: "1q7to0"
	}],
	["path", {
		d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
		key: "3uifl3"
	}],
	["path", {
		d: "M8 16H3v5",
		key: "1cv678"
	}]
]), O = w("server", [
	["rect", {
		width: "20",
		height: "8",
		x: "2",
		y: "2",
		rx: "2",
		ry: "2",
		key: "ngkwjq"
	}],
	["rect", {
		width: "20",
		height: "8",
		x: "2",
		y: "14",
		rx: "2",
		ry: "2",
		key: "iecqi9"
	}],
	["line", {
		x1: "6",
		x2: "6.01",
		y1: "6",
		y2: "6",
		key: "16zg32"
	}],
	["line", {
		x1: "6",
		x2: "6.01",
		y1: "18",
		y2: "18",
		key: "nzw8ys"
	}]
]), k = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element");
	function n(e, n, r) {
		var i = null;
		if (r !== void 0 && (i = "" + r), n.key !== void 0 && (i = "" + n.key), "key" in n) for (var a in r = {}, n) a !== "key" && (r[a] = n[a]);
		else r = n;
		return n = r.ref, {
			$$typeof: t,
			type: e,
			key: i,
			ref: n === void 0 ? null : n,
			props: r
		};
	}
	e.jsx = n, e.jsxs = n;
})), A = (/* @__PURE__ */ o(((e, t) => {
	t.exports = k();
})))(), j = f("licensed-example");
function M() {
	let [e, t] = (0, m.useState)(null), [n, r] = (0, m.useState)(!1), i = (0, m.useCallback)(async () => {
		r(!0);
		let e = await j.get("premium-report");
		t(e), r(!1);
	}, []), a = e?.success === !0;
	return /* @__PURE__ */ (0, A.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, A.jsxs)("div", {
			className: "rounded-lg border border-zinc-800 bg-zinc-900/60 p-4 space-y-2",
			children: [
				/* @__PURE__ */ (0, A.jsxs)("div", {
					className: "flex items-center gap-2 text-sm font-semibold",
					children: [
						/* @__PURE__ */ (0, A.jsx)(T, { className: "h-4 w-4 text-amber-400" }),
						"License status",
						/* @__PURE__ */ (0, A.jsx)("span", {
							className: a ? "text-emerald-400" : "text-zinc-400",
							children: a ? `active (${e?.license ?? "licensed"})` : e ? "unavailable" : "unknown"
						})
					]
				}),
				/* @__PURE__ */ (0, A.jsx)("div", {
					className: "text-xs text-zinc-500",
					children: "The license key (config.licenseKey) is set from the panel's plugin config UI. This tab never sees it — activation and payload decryption happen in the encrypted backend."
				}),
				e && !a ? /* @__PURE__ */ (0, A.jsx)("div", {
					className: "text-xs text-amber-400",
					children: e.error ?? "request failed"
				}) : null,
				a ? /* @__PURE__ */ (0, A.jsx)("div", {
					className: "flex flex-wrap gap-1",
					children: (e?.entitlements ?? []).map((e) => /* @__PURE__ */ (0, A.jsx)("span", {
						className: "rounded bg-zinc-800 px-1.5 py-0.5 text-[11px] text-zinc-300",
						children: e
					}, e))
				}) : null,
				/* @__PURE__ */ (0, A.jsxs)("button", {
					onClick: i,
					disabled: n,
					className: "inline-flex items-center gap-1.5 rounded bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-500 disabled:opacity-50",
					children: [n ? /* @__PURE__ */ (0, A.jsx)(E, { className: "h-3.5 w-3.5 animate-spin" }) : /* @__PURE__ */ (0, A.jsx)(D, { className: "h-3.5 w-3.5" }), "Load premium report"]
				})
			]
		}), a && e?.report ? /* @__PURE__ */ (0, A.jsxs)("div", {
			className: "rounded-lg border border-zinc-800 bg-zinc-900/60 p-4 space-y-2",
			children: [/* @__PURE__ */ (0, A.jsxs)("div", {
				className: "flex items-center gap-2 text-sm font-semibold",
				children: [
					/* @__PURE__ */ (0, A.jsx)(O, { className: "h-4 w-4 text-emerald-400" }),
					"Premium report",
					/* @__PURE__ */ (0, A.jsxs)("span", {
						className: "text-xs font-normal text-zinc-500",
						children: [
							e.report.serverCount,
							" server(s) · generated ",
							new Date(e.report.generatedAt).toLocaleString()
						]
					})
				]
			}), /* @__PURE__ */ (0, A.jsx)("ul", {
				className: "divide-y divide-zinc-800 text-xs",
				children: e.report.servers.map((e) => /* @__PURE__ */ (0, A.jsxs)("li", {
					className: "flex items-center justify-between py-1",
					children: [/* @__PURE__ */ (0, A.jsx)("span", {
						className: "truncate",
						children: e.name
					}), /* @__PURE__ */ (0, A.jsx)("span", {
						className: "text-zinc-500",
						children: e.status
					})]
				}, e.id))
			})]
		}) : null]
	});
}
//#endregion
//#region frontend/index.ts
var N = l({
	manifest: {
		name: "licensed-example",
		version: "1.0.0",
		displayName: "Licensed Example",
		description: "Reference client for vendor-owned license validation and encrypted payloads.",
		author: "Catalyst Team"
	},
	tabs: [{
		id: "licensed-example",
		label: "Licensed Example",
		icon: "KeyRound",
		component: M,
		location: "admin",
		order: 100,
		requiredPermissions: ["admin.read"]
	}]
});
//#endregion
export { N as default };
