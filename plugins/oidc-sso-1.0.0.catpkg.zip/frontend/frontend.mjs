//#region \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), s = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, c = (n, r, o) => (o = n == null ? {} : e(i(n)), s(r || !n || !n.__esModule || !a.call(n, "default") ? t(o, "default", {
	value: n,
	enumerable: !0
}) : o, n));
//#endregion
//#region ../sdk-frontend/plugin.ts
function l(e) {
	return {
		manifest: e.manifest,
		tabs: e.tabs,
		routes: e.routes,
		components: e.components,
		onMount: e.onMount,
		onUnmount: e.onUnmount
	};
}
//#endregion
//#region ../sdk-frontend/api.ts
var u = "";
async function d(e, t, n) {
	let { method: r = "GET", body: i, headers: a } = n ?? {}, o = `${u}/api/plugins/${e}/${t.replace(/^\//, "")}`;
	try {
		let e = await fetch(o, {
			method: r,
			credentials: "include",
			headers: {
				...i !== void 0 && !(i instanceof FormData) ? { "Content-Type": "application/json" } : {},
				...a
			},
			body: i === void 0 ? void 0 : i instanceof FormData ? i : JSON.stringify(i)
		});
		if (!e.ok) {
			let t = `HTTP ${e.status}`;
			try {
				let n = await e.json();
				t = n.error || n.message || t;
			} catch {}
			return {
				success: !1,
				error: t
			};
		}
		let t = await e.json();
		return t && typeof t == "object" && "success" in t ? t : {
			success: !0,
			data: t
		};
	} catch (e) {
		return {
			success: !1,
			error: e instanceof Error ? e.message : "Network error"
		};
	}
}
function f(e) {
	return {
		get(t) {
			return d(e, t);
		},
		post(t, n) {
			return d(e, t, {
				method: "POST",
				body: n
			});
		},
		put(t, n) {
			return d(e, t, {
				method: "PUT",
				body: n
			});
		},
		del(t) {
			return d(e, t, { method: "DELETE" });
		},
		delete(t) {
			return d(e, t, { method: "DELETE" });
		},
		patch(t, n) {
			return d(e, t, {
				method: "PATCH",
				body: n
			});
		}
	};
}
//#endregion
//#region ../node_modules/.pnpm/react@19.2.8/node_modules/react/cjs/react.production.js
var p = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element"), n = Symbol.for("react.consumer"), r = Symbol.for("react.context"), i = Symbol.for("react.forward_ref"), a = {
		isMounted: function() {
			return !1;
		},
		enqueueForceUpdate: function() {},
		enqueueReplaceState: function() {},
		enqueueSetState: function() {}
	}, o = Object.assign, s = {};
	function c(e, t, n) {
		this.props = e, this.context = t, this.refs = s, this.updater = n || a;
	}
	c.prototype.isReactComponent = {}, c.prototype.setState = function(e, t) {
		if (typeof e != "object" && typeof e != "function" && e != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
		this.updater.enqueueSetState(this, e, t, "setState");
	}, c.prototype.forceUpdate = function(e) {
		this.updater.enqueueForceUpdate(this, e, "forceUpdate");
	};
	function l() {}
	l.prototype = c.prototype;
	function u(e, t, n) {
		this.props = e, this.context = t, this.refs = s, this.updater = n || a;
	}
	var d = u.prototype = new l();
	d.constructor = u, o(d, c.prototype), d.isPureReactComponent = !0, Array.isArray;
	var f = {
		H: null,
		A: null,
		T: null,
		S: null
	}, p = Object.prototype.hasOwnProperty;
	function m(e, n, r) {
		var i = r.ref;
		return {
			$$typeof: t,
			type: e,
			key: n,
			ref: i === void 0 ? null : i,
			props: r
		};
	}
	e.Component = c, e.createContext = function(e) {
		return e = {
			$$typeof: r,
			_currentValue: e,
			_currentValue2: e,
			_threadCount: 0,
			Provider: null,
			Consumer: null
		}, e.Provider = e, e.Consumer = {
			$$typeof: n,
			_context: e
		}, e;
	}, e.createElement = function(e, t, n) {
		var r, i = {}, a = null;
		if (t != null) for (r in t.key !== void 0 && (a = "" + t.key), t) p.call(t, r) && r !== "key" && r !== "__self" && r !== "__source" && (i[r] = t[r]);
		var o = arguments.length - 2;
		if (o === 1) i.children = n;
		else if (1 < o) {
			for (var s = Array(o), c = 0; c < o; c++) s[c] = arguments[c + 2];
			i.children = s;
		}
		if (e && e.defaultProps) for (r in o = e.defaultProps, o) i[r] === void 0 && (i[r] = o[r]);
		return m(e, a, i);
	}, e.forwardRef = function(e) {
		return {
			$$typeof: i,
			render: e
		};
	}, e.useCallback = function(e, t) {
		return f.H.useCallback(e, t);
	}, e.useContext = function(e) {
		return f.H.useContext(e);
	}, e.useEffect = function(e, t) {
		return f.H.useEffect(e, t);
	}, e.useMemo = function(e, t) {
		return f.H.useMemo(e, t);
	}, e.useState = function(e) {
		return f.H.useState(e);
	};
})), m = /* @__PURE__ */ c((/* @__PURE__ */ o(((e, t) => {
	t.exports = p();
})))(), 1);
m.Component;
//#endregion
//#region ../node_modules/.pnpm/lucide-react@1.31.0_react@19.2.8/node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs
var h = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), g = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), _ = (e) => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()), v = (e) => {
	let t = _(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, y = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "round",
	strokeLinejoin: "round"
}, b = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, x = (0, m.createContext)({}), S = () => (0, m.useContext)(x), C = (0, m.forwardRef)(({ color: e, size: t, strokeWidth: n, absoluteStrokeWidth: r, className: i = "", children: a, iconNode: o, ...s }, c) => {
	let { size: l = 24, strokeWidth: u = 2, absoluteStrokeWidth: d = !1, color: f = "currentColor", className: p = "" } = S() ?? {}, g = r ?? d ? Number(n ?? u) * 24 / Number(t ?? l) : n ?? u;
	return (0, m.createElement)("svg", {
		ref: c,
		...y,
		width: t ?? l ?? y.width,
		height: t ?? l ?? y.height,
		stroke: e ?? f,
		strokeWidth: g,
		className: h("lucide", p, i),
		...!a && !b(s) && { "aria-hidden": "true" },
		...s
	}, [...o.map(([e, t]) => (0, m.createElement)(e, t)), ...Array.isArray(a) ? a : [a]]);
}), w = (e, t) => {
	let n = (0, m.forwardRef)(({ className: n, ...r }, i) => (0, m.createElement)(C, {
		ref: i,
		iconNode: t,
		className: h(`lucide-${g(v(e))}`, `lucide-${e}`, n),
		...r
	}));
	return n.displayName = v(e), n;
}, T = w("circle-check", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}], ["path", {
	d: "m9 12 2 2 4-4",
	key: "dzmm74"
}]]), E = w("circle-x", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "m15 9-6 6",
		key: "1uzhvr"
	}],
	["path", {
		d: "m9 9 6 6",
		key: "z0biqf"
	}]
]), D = w("key-round", [["path", {
	d: "M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",
	key: "1s6t7t"
}], ["circle", {
	cx: "16.5",
	cy: "7.5",
	r: ".5",
	fill: "currentColor",
	key: "w0ekpg"
}]]), O = w("loader-circle", [["path", {
	d: "M21 12a9 9 0 1 1-6.219-8.56",
	key: "13zald"
}]]), k = w("plus", [["path", {
	d: "M5 12h14",
	key: "1ays0h"
}], ["path", {
	d: "M12 5v14",
	key: "s699le"
}]]), A = w("refresh-cw", [
	["path", {
		d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
		key: "v9h5vc"
	}],
	["path", {
		d: "M21 3v5h-5",
		key: "1q7to0"
	}],
	["path", {
		d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
		key: "3uifl3"
	}],
	["path", {
		d: "M8 16H3v5",
		key: "1cv678"
	}]
]), j = w("trash-2", [
	["path", {
		d: "M10 11v6",
		key: "nco0om"
	}],
	["path", {
		d: "M14 11v6",
		key: "outv1u"
	}],
	["path", {
		d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",
		key: "miytrc"
	}],
	["path", {
		d: "M3 6h18",
		key: "d0wm0j"
	}],
	["path", {
		d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
		key: "e791ji"
	}]
]), M = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element"), n = Symbol.for("react.fragment");
	function r(e, n, r) {
		var i = null;
		if (r !== void 0 && (i = "" + r), n.key !== void 0 && (i = "" + n.key), "key" in n) for (var a in r = {}, n) a !== "key" && (r[a] = n[a]);
		else r = n;
		return n = r.ref, {
			$$typeof: t,
			type: e,
			key: i,
			ref: n === void 0 ? null : n,
			props: r
		};
	}
	e.Fragment = n, e.jsx = r, e.jsxs = r;
})), N = (/* @__PURE__ */ o(((e, t) => {
	t.exports = M();
})))(), P = "text-muted-foreground", F = "font-mono", I = (...e) => e.filter(Boolean).join(" ");
function L({ variant: e = "default", size: t = "default", className: n, ...r }) {
	return /* @__PURE__ */ (0, N.jsx)("button", {
		className: I("inline-flex items-center justify-center gap-1.5 rounded-md font-medium transition-colors disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring", {
			default: "h-9 px-4 py-2 text-sm",
			sm: "h-7 rounded-md px-2.5 text-xs"
		}[t], {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			outline: "border border-border bg-transparent shadow-sm hover:bg-accent hover:text-accent-foreground",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90"
		}[e], n),
		...r
	});
}
function R({ className: e, ...t }) {
	return /* @__PURE__ */ (0, N.jsx)("input", {
		className: I("flex h-9 w-full rounded-md border border-border bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", e),
		...t
	});
}
function z({ className: e, ...t }) {
	return /* @__PURE__ */ (0, N.jsx)("label", {
		className: I("text-sm font-medium leading-none", e),
		...t
	});
}
function B({ checked: e, onCheckedChange: t, label: n, description: r }) {
	return /* @__PURE__ */ (0, N.jsxs)("label", {
		className: "flex cursor-pointer items-start gap-2.5",
		children: [/* @__PURE__ */ (0, N.jsx)("input", {
			type: "checkbox",
			checked: e,
			onChange: (e) => t(e.target.checked),
			className: "mt-0.5 h-4 w-4 shrink-0 rounded border-border accent-[var(--primary)]"
		}), /* @__PURE__ */ (0, N.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, N.jsx)("span", {
				className: "block text-sm",
				children: n
			}), r ? /* @__PURE__ */ (0, N.jsx)("span", {
				className: I("block text-xs", P),
				children: r
			}) : null]
		})]
	});
}
function V({ title: e, description: t, children: n, actions: r }) {
	return /* @__PURE__ */ (0, N.jsxs)("div", {
		className: "rounded-lg border border-border bg-card p-4 space-y-3",
		children: [/* @__PURE__ */ (0, N.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, N.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, N.jsx)("h3", {
					className: "text-sm font-semibold tracking-tight",
					children: e
				}), t ? /* @__PURE__ */ (0, N.jsx)("p", {
					className: I("mt-0.5 text-xs", P),
					children: t
				}) : null]
			}), r ? /* @__PURE__ */ (0, N.jsx)("div", {
				className: "flex shrink-0 items-center gap-2",
				children: r
			}) : null]
		}), n]
	});
}
function H({ tone: e = "default", children: t }) {
	return /* @__PURE__ */ (0, N.jsx)("span", {
		className: I("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-medium", {
			default: "border-border bg-muted text-muted-foreground",
			success: "border-emerald-500/40 bg-emerald-500/10 text-emerald-500",
			warn: "border-amber-500/40 bg-amber-500/10 text-amber-500",
			danger: "border-red-500/40 bg-red-500/10 text-red-500"
		}[e]),
		children: t
	});
}
function U({ ok: e, children: t }) {
	return /* @__PURE__ */ (0, N.jsxs)("div", {
		className: "flex items-center gap-1.5 text-xs",
		children: [e ? /* @__PURE__ */ (0, N.jsx)(T, { className: "h-3.5 w-3.5 text-emerald-500 shrink-0" }) : /* @__PURE__ */ (0, N.jsx)(E, { className: "h-3.5 w-3.5 text-red-500 shrink-0" }), /* @__PURE__ */ (0, N.jsx)("span", {
			className: "min-w-0 break-words",
			children: t
		})]
	});
}
function W({ className: e }) {
	return /* @__PURE__ */ (0, N.jsx)(D, {
		className: I("h-4 w-4", e),
		"aria-hidden": "true"
	});
}
//#endregion
//#region frontend/api.ts
var G = f("oidc-sso");
async function K(e) {
	if (!e.success) throw Error(e.error || "Request failed");
	return e;
}
async function q() {
	return K(await G.get("/settings"));
}
async function J(e) {
	await K(await G.put("/settings", e));
}
async function Y(e) {
	return K(await G.post("/settings/test", { providerId: e }));
}
async function X() {
	return (await K(await G.get("/panel-roles"))).roles ?? [];
}
async function Z() {
	return K(await G.get("/status"));
}
//#endregion
//#region frontend/components.tsx
function Q(e) {
	return e.toLowerCase().trim().replace(/[^a-z0-9-]+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "").slice(0, 40);
}
function $(e) {
	let { hasClientSecret: t, issues: n, clientSecret: r, ...i } = e;
	return i;
}
var ee = {
	id: "",
	label: "",
	issuer: "",
	discoveryUrl: "",
	clientId: "",
	clientSecret: "",
	scopes: "openid profile email",
	usePkce: !0,
	enabled: !0,
	autoRegister: !0,
	linkExistingByEmail: !0,
	markEmailVerified: !0,
	defaultRoleIds: [],
	emailClaim: "email",
	usernameClaim: "preferred_username",
	nameClaim: "name",
	avatarClaim: "picture"
};
function te({ frontendUrl: e, loginDisabled: t, redirectUri: n, linkCount: r, onSaved: i }) {
	let [a, o] = (0, m.useState)(e), [s, c] = (0, m.useState)(t), [l, u] = (0, m.useState)(!1), [d, f] = (0, m.useState)(null);
	return (0, m.useEffect)(() => {
		o(e), c(t);
	}, [e, t]), /* @__PURE__ */ (0, N.jsxs)(V, {
		title: "Single sign-on",
		description: "One login button, any identity provider. The redirect URI below is shared by every provider — register it once at each IdP.",
		actions: /* @__PURE__ */ (0, N.jsxs)(L, {
			size: "sm",
			onClick: async () => {
				u(!0), f(null);
				try {
					await J({
						frontendUrl: a,
						loginDisabled: s
					}), i();
				} catch (e) {
					f(e.message);
				} finally {
					u(!1);
				}
			},
			disabled: l,
			children: [l ? /* @__PURE__ */ (0, N.jsx)(O, { className: "h-3 w-3 animate-spin" }) : null, "Save"]
		}),
		children: [
			/* @__PURE__ */ (0, N.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, N.jsxs)("div", {
					className: "space-y-1.5",
					children: [
						/* @__PURE__ */ (0, N.jsxs)(z, {
							htmlFor: "oidc-frontend-url",
							children: ["Public URL ", /* @__PURE__ */ (0, N.jsx)(H, { children: "tunnel / proxy setups" })]
						}),
						/* @__PURE__ */ (0, N.jsx)(R, {
							id: "oidc-frontend-url",
							value: a,
							onChange: (e) => o(e.target.value),
							placeholder: "https://panel.example.com — set when a tunnel/proxy hides the public hostname"
						}),
						/* @__PURE__ */ (0, N.jsx)("p", {
							className: I("text-[11px]", P),
							children: "The origin users visit. Used for the redirect URI and post-login redirects. Leave empty for direct deployments where the backend sees the real Host header."
						})
					]
				}), /* @__PURE__ */ (0, N.jsxs)("div", {
					className: "space-y-1.5",
					children: [
						/* @__PURE__ */ (0, N.jsx)(z, { children: "Linked SSO identities" }),
						/* @__PURE__ */ (0, N.jsxs)("div", {
							className: "text-sm",
							children: [
								r,
								" identity",
								r === 1 ? "" : "ies",
								" linked across all providers."
							]
						}),
						/* @__PURE__ */ (0, N.jsx)("p", {
							className: I("text-[11px]", P),
							children: "Links are created automatically on sign-in."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, N.jsx)(B, {
				checked: !s,
				onCheckedChange: (e) => c(!e),
				label: "SSO sign-in enabled",
				description: "Temporarily hides the “Continue with SSO” button on the login page."
			}),
			/* @__PURE__ */ (0, N.jsxs)("div", {
				className: "space-y-1 rounded-md border border-border bg-muted/30 p-3 text-xs",
				children: [/* @__PURE__ */ (0, N.jsx)("div", {
					className: P,
					children: "Register this redirect URI at every identity provider (one URI for all):"
				}), /* @__PURE__ */ (0, N.jsx)("code", {
					className: I("break-all text-[11px]", F),
					children: n
				})]
			}),
			d ? /* @__PURE__ */ (0, N.jsx)(U, {
				ok: !1,
				children: d
			}) : null
		]
	});
}
function ne({ provider: e, panelRoles: t, allProviders: n, onSaved: r }) {
	let [i, a] = (0, m.useState)(e), [o, s] = (0, m.useState)(!1), [c, l] = (0, m.useState)(!1), [u, d] = (0, m.useState)(!1), [f, p] = (0, m.useState)(null), [h, g] = (0, m.useState)(null), [_, v] = (0, m.useState)(""), [y, b] = (0, m.useState)(!1);
	(0, m.useEffect)(() => {
		a(e), v(""), b(!1);
	}, [e]);
	let x = (e, t) => a((n) => ({
		...n,
		[e]: t
	})), S = (e, t) => {
		let { hasClientSecret: n, issues: r, ...i } = e, a = { ...i };
		return t === null ? a.clientSecret = null : t ? a.clientSecret = t : delete a.clientSecret, a;
	}, C = (t, r) => n.map((n) => n.id === e.id ? S(t, r) : S(n, void 0)), w = async (e, t) => {
		l(!0), g(null);
		try {
			await J({ providers: C(e ?? i, t) }), r();
		} catch (e) {
			g(e.message);
		} finally {
			l(!1);
		}
	}, T = async () => {
		let e = {
			...i,
			enabled: !i.enabled
		};
		a(e), await w(e);
	}, E = async () => {
		d(!0);
		try {
			p(await Y(e.id));
		} catch (t) {
			p({
				success: !0,
				providerId: e.id,
				clientConfigured: !1,
				issues: [t.message],
				discovery: {
					ok: !1,
					error: t.message
				}
			});
		} finally {
			d(!1);
		}
	}, D = async () => {
		if (window.confirm(`Remove the "${i.label || i.id}" provider? Linked identities for it stop working.`)) {
			l(!0);
			try {
				await J({ providers: n.filter((t) => t.id !== e.id).map((e) => S(e, void 0)) }), r();
			} catch (e) {
				g(e.message);
			} finally {
				l(!1);
			}
		}
	}, k = async () => {
		let e = _.trim();
		await w(i, e || (y ? null : void 0));
	}, A = (e, t) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t], M = (i.issues ?? []).length === 0;
	return /* @__PURE__ */ (0, N.jsxs)(V, {
		title: i.label || i.id || "Untitled provider",
		description: i.issuer || i.discoveryUrl || "No issuer configured yet",
		actions: /* @__PURE__ */ (0, N.jsxs)(N.Fragment, { children: [
			/* @__PURE__ */ (0, N.jsxs)(L, {
				variant: "outline",
				size: "sm",
				onClick: E,
				disabled: u,
				children: [u ? /* @__PURE__ */ (0, N.jsx)(O, { className: "h-3 w-3 animate-spin" }) : null, "Test"]
			}),
			/* @__PURE__ */ (0, N.jsx)(L, {
				variant: "outline",
				size: "sm",
				onClick: () => s((e) => !e),
				children: o ? "Collapse" : "Configure"
			}),
			/* @__PURE__ */ (0, N.jsx)(L, {
				variant: "outline",
				size: "sm",
				onClick: T,
				disabled: c,
				children: i.enabled ? "Disable" : "Enable"
			})
		] }),
		children: [
			/* @__PURE__ */ (0, N.jsxs)("div", {
				className: "flex flex-wrap items-center gap-1.5",
				children: [
					i.enabled ? /* @__PURE__ */ (0, N.jsx)(H, {
						tone: "success",
						children: "enabled"
					}) : /* @__PURE__ */ (0, N.jsx)(H, { children: "disabled" }),
					M ? /* @__PURE__ */ (0, N.jsx)(H, {
						tone: "success",
						children: "ready"
					}) : /* @__PURE__ */ (0, N.jsx)(H, {
						tone: "warn",
						children: "incomplete"
					}),
					(i.issues ?? []).map((e) => /* @__PURE__ */ (0, N.jsx)(H, {
						tone: "warn",
						children: e
					}, e)),
					/* @__PURE__ */ (0, N.jsxs)("button", {
						type: "button",
						onClick: D,
						className: I("ml-auto inline-flex items-center gap-1 text-xs", P, "hover:text-red-500"),
						children: [/* @__PURE__ */ (0, N.jsx)(j, { className: "h-3.5 w-3.5" }), "Remove"]
					})
				]
			}),
			f ? /* @__PURE__ */ (0, N.jsxs)("div", {
				className: "space-y-1.5 rounded-md border border-border bg-muted/30 p-3",
				children: [
					/* @__PURE__ */ (0, N.jsx)(U, {
						ok: f.clientConfigured,
						children: f.clientConfigured ? "Client ID + secret are configured." : "Client ID or secret missing."
					}),
					f.discovery?.ok ? /* @__PURE__ */ (0, N.jsxs)(N.Fragment, { children: [/* @__PURE__ */ (0, N.jsxs)(U, {
						ok: !0,
						children: [
							"Discovery OK — issuer “",
							f.discovery.issuer,
							"”."
						]
					}), /* @__PURE__ */ (0, N.jsx)("div", {
						className: I("break-all text-[11px]", P, F),
						children: f.discovery.authorizationEndpoint
					})] }) : /* @__PURE__ */ (0, N.jsxs)(U, {
						ok: !1,
						children: ["Discovery: ", f.discovery?.error || "not configured"]
					}),
					f.jwks?.ok ? /* @__PURE__ */ (0, N.jsxs)(U, {
						ok: !0,
						children: [
							"Signing keys reachable (",
							f.jwks.keys,
							" keys)."
						]
					}) : /* @__PURE__ */ (0, N.jsxs)(U, {
						ok: !1,
						children: ["Signing keys: ", f.jwks?.error || "unknown"]
					})
				]
			}) : null,
			o ? /* @__PURE__ */ (0, N.jsxs)("div", {
				className: "space-y-4 pt-1",
				children: [
					/* @__PURE__ */ (0, N.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, N.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, N.jsx)(z, { children: "Display label" }), /* @__PURE__ */ (0, N.jsx)(R, {
									value: i.label,
									onChange: (e) => {
										let t = e.target.value;
										a((e) => ({
											...e,
											label: t,
											id: e.id || Q(t)
										}));
									},
									placeholder: "Company Login"
								})]
							}),
							/* @__PURE__ */ (0, N.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, N.jsx)(z, { children: "ID (used in URLs)" }), /* @__PURE__ */ (0, N.jsx)(R, {
									value: i.id,
									onChange: (e) => x("id", Q(e.target.value)),
									placeholder: "company"
								})]
							}),
							/* @__PURE__ */ (0, N.jsxs)("div", {
								className: "space-y-1.5 sm:col-span-2",
								children: [
									/* @__PURE__ */ (0, N.jsx)(z, { children: "Issuer URL" }),
									/* @__PURE__ */ (0, N.jsx)(R, {
										value: i.issuer,
										onChange: (e) => x("issuer", e.target.value),
										placeholder: "https://auth.example.com/realms/main"
									}),
									/* @__PURE__ */ (0, N.jsx)("p", {
										className: I("text-[11px]", P),
										children: "Keycloak: your realm URL · Authentik: your provider's issuer · Google: https://accounts.google.com · Microsoft: https://login.microsoftonline.com/<tenant>/v2.0 · Okta: https://<domain>/oauth2/default"
									})
								]
							}),
							/* @__PURE__ */ (0, N.jsxs)("div", {
								className: "space-y-1.5 sm:col-span-2",
								children: [/* @__PURE__ */ (0, N.jsx)(z, { children: "Discovery URL override (optional)" }), /* @__PURE__ */ (0, N.jsx)(R, {
									value: i.discoveryUrl,
									onChange: (e) => x("discoveryUrl", e.target.value),
									placeholder: "Defaults to <issuer>/.well-known/openid-configuration"
								})]
							}),
							/* @__PURE__ */ (0, N.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, N.jsx)(z, { children: "Client ID" }), /* @__PURE__ */ (0, N.jsx)(R, {
									value: i.clientId,
									onChange: (e) => x("clientId", e.target.value),
									placeholder: "catalyst-panel"
								})]
							}),
							/* @__PURE__ */ (0, N.jsxs)("div", {
								className: "space-y-1.5",
								children: [
									/* @__PURE__ */ (0, N.jsxs)(z, { children: [
										"Client Secret",
										" ",
										i.hasClientSecret ? /* @__PURE__ */ (0, N.jsx)(H, {
											tone: "success",
											children: "configured"
										}) : /* @__PURE__ */ (0, N.jsx)(H, {
											tone: "warn",
											children: "missing"
										})
									] }),
									/* @__PURE__ */ (0, N.jsx)(R, {
										type: "password",
										value: _,
										onChange: (e) => {
											v(e.target.value), b(!1);
										},
										placeholder: i.hasClientSecret ? "•••• (leave blank to keep)" : "Required for confidential clients"
									}),
									i.hasClientSecret && !_ ? /* @__PURE__ */ (0, N.jsx)(B, {
										checked: y,
										onCheckedChange: b,
										label: "Clear stored secret"
									}) : null
								]
							}),
							/* @__PURE__ */ (0, N.jsxs)("div", {
								className: "space-y-1.5 sm:col-span-2",
								children: [/* @__PURE__ */ (0, N.jsx)(z, { children: "Scopes" }), /* @__PURE__ */ (0, N.jsx)(R, {
									value: i.scopes,
									onChange: (e) => x("scopes", e.target.value),
									placeholder: "openid profile email"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, N.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, N.jsx)(B, {
								checked: i.usePkce,
								onCheckedChange: (e) => x("usePkce", e),
								label: "Use PKCE (S256)",
								description: "Recommended. Turn off only for providers that reject the code_challenge parameter."
							}),
							/* @__PURE__ */ (0, N.jsx)(B, {
								checked: i.autoRegister,
								onCheckedChange: (e) => x("autoRegister", e),
								label: "Create accounts on first sign-in",
								description: "New panel accounts are created for unknown SSO identities (never for the very first panel account)."
							}),
							/* @__PURE__ */ (0, N.jsx)(B, {
								checked: i.linkExistingByEmail,
								onCheckedChange: (e) => x("linkExistingByEmail", e),
								label: "Link existing accounts by matching email",
								description: "An SSO identity whose email matches a panel account links to it (standard OIDC trust model)."
							}),
							/* @__PURE__ */ (0, N.jsx)(B, {
								checked: i.markEmailVerified,
								onCheckedChange: (e) => x("markEmailVerified", e),
								label: "Trust the provider's email verification",
								description: "Mark created accounts as email-verified. Disable to rely only on the email_verified claim."
							})
						]
					}),
					/* @__PURE__ */ (0, N.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, N.jsx)(z, { children: "Claim mappings (claim names at the provider)" }), /* @__PURE__ */ (0, N.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, N.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, N.jsx)(z, {
										htmlFor: `oidc-email-${i.id}`,
										children: "Email claim"
									}), /* @__PURE__ */ (0, N.jsx)(R, {
										id: `oidc-email-${i.id}`,
										value: i.emailClaim,
										onChange: (e) => x("emailClaim", e.target.value),
										placeholder: "email"
									})]
								}),
								/* @__PURE__ */ (0, N.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, N.jsx)(z, {
										htmlFor: `oidc-username-${i.id}`,
										children: "Username claim"
									}), /* @__PURE__ */ (0, N.jsx)(R, {
										id: `oidc-username-${i.id}`,
										value: i.usernameClaim,
										onChange: (e) => x("usernameClaim", e.target.value),
										placeholder: "preferred_username"
									})]
								}),
								/* @__PURE__ */ (0, N.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, N.jsx)(z, {
										htmlFor: `oidc-name-${i.id}`,
										children: "Display-name claim"
									}), /* @__PURE__ */ (0, N.jsx)(R, {
										id: `oidc-name-${i.id}`,
										value: i.nameClaim,
										onChange: (e) => x("nameClaim", e.target.value),
										placeholder: "name"
									})]
								}),
								/* @__PURE__ */ (0, N.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, N.jsx)(z, {
										htmlFor: `oidc-avatar-${i.id}`,
										children: "Avatar claim"
									}), /* @__PURE__ */ (0, N.jsx)(R, {
										id: `oidc-avatar-${i.id}`,
										value: i.avatarClaim,
										onChange: (e) => x("avatarClaim", e.target.value),
										placeholder: "picture"
									})]
								})
							]
						})]
					}),
					t.length > 0 ? /* @__PURE__ */ (0, N.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, N.jsx)(z, { children: "Default panel roles for created accounts" }), /* @__PURE__ */ (0, N.jsx)("div", {
							className: "flex flex-wrap gap-1.5",
							children: t.map((e) => {
								let t = i.defaultRoleIds.includes(e.id);
								return /* @__PURE__ */ (0, N.jsx)("button", {
									type: "button",
									onClick: () => x("defaultRoleIds", A(i.defaultRoleIds, e.id)),
									className: I("rounded-full border px-2.5 py-1 text-xs transition-colors", t ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:bg-accent"),
									children: e.name
								}, e.id);
							})
						})]
					}) : null,
					/* @__PURE__ */ (0, N.jsx)("div", {
						className: "flex justify-end",
						children: /* @__PURE__ */ (0, N.jsxs)(L, {
							size: "sm",
							onClick: () => void k(),
							disabled: c,
							children: [c ? /* @__PURE__ */ (0, N.jsx)(O, { className: "h-3 w-3 animate-spin" }) : null, "Save provider"]
						})
					})
				]
			}) : null,
			h ? /* @__PURE__ */ (0, N.jsx)(U, {
				ok: !1,
				children: h
			}) : null
		]
	});
}
function re({ existing: e, onSaved: t }) {
	let [n, r] = (0, m.useState)(""), [i, a] = (0, m.useState)(""), [o, s] = (0, m.useState)(""), [c, l] = (0, m.useState)(""), [u, d] = (0, m.useState)(!1), [f, p] = (0, m.useState)(null);
	return /* @__PURE__ */ (0, N.jsxs)(V, {
		title: "Add identity provider",
		description: "Each provider gets its own configuration. Users pick theirs on the SSO page when several are enabled.",
		children: [
			/* @__PURE__ */ (0, N.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, N.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, N.jsx)(z, {
							htmlFor: "oidc-new-label",
							children: "Display label"
						}), /* @__PURE__ */ (0, N.jsx)(R, {
							id: "oidc-new-label",
							value: n,
							onChange: (e) => r(e.target.value),
							placeholder: "Company Keycloak"
						})]
					}),
					/* @__PURE__ */ (0, N.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, N.jsx)(z, {
							htmlFor: "oidc-new-issuer",
							children: "Issuer URL"
						}), /* @__PURE__ */ (0, N.jsx)(R, {
							id: "oidc-new-issuer",
							value: i,
							onChange: (e) => a(e.target.value),
							placeholder: "https://auth.example.com/realms/main"
						})]
					}),
					/* @__PURE__ */ (0, N.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, N.jsx)(z, {
							htmlFor: "oidc-new-client",
							children: "Client ID"
						}), /* @__PURE__ */ (0, N.jsx)(R, {
							id: "oidc-new-client",
							value: o,
							onChange: (e) => s(e.target.value),
							placeholder: "catalyst-panel"
						})]
					}),
					/* @__PURE__ */ (0, N.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, N.jsx)(z, {
							htmlFor: "oidc-new-secret",
							children: "Client Secret"
						}), /* @__PURE__ */ (0, N.jsx)(R, {
							id: "oidc-new-secret",
							type: "password",
							value: c,
							onChange: (e) => l(e.target.value),
							placeholder: "Confidential client secret"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, N.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, N.jsx)("span", {
					className: I("text-[11px]", P),
					children: n ? /* @__PURE__ */ (0, N.jsxs)(N.Fragment, { children: ["ID will be ", /* @__PURE__ */ (0, N.jsx)("code", {
						className: F,
						children: Q(n) || "…"
					})] }) : "Claim mappings and sign-in rules use provider defaults — tune them after adding."
				}), /* @__PURE__ */ (0, N.jsxs)(L, {
					size: "sm",
					onClick: async () => {
						let u = Q(n);
						if (!u) {
							p("Give the provider a label first (the ID is derived from it).");
							return;
						}
						if (e.some((e) => e.id === u)) {
							p(`An "${u}" provider already exists — pick a different label.`);
							return;
						}
						d(!0), p(null);
						try {
							await J({ providers: [...e.map($), {
								...ee,
								id: u,
								label: n.trim(),
								issuer: i.trim(),
								clientId: o.trim(),
								clientSecret: c.trim()
							}] }), r(""), a(""), s(""), l(""), t();
						} catch (e) {
							p(e.message);
						} finally {
							d(!1);
						}
					},
					disabled: u,
					children: [u ? /* @__PURE__ */ (0, N.jsx)(O, { className: "h-3 w-3 animate-spin" }) : /* @__PURE__ */ (0, N.jsx)(k, { className: "h-3 w-3" }), "Add provider"]
				})]
			}),
			f ? /* @__PURE__ */ (0, N.jsx)(U, {
				ok: !1,
				children: f
			}) : null
		]
	});
}
function ie() {
	let [e, t] = (0, m.useState)(null), [n, r] = (0, m.useState)(null), [i, a] = (0, m.useState)([]), [o, s] = (0, m.useState)(null), c = (0, m.useCallback)(async () => {
		try {
			let [e, n, i] = await Promise.all([
				q(),
				Z().catch(() => null),
				X().catch(() => [])
			]);
			t(e), r(n), a(i);
		} catch (e) {
			s(e.message);
		}
	}, []);
	(0, m.useEffect)(() => {
		c();
	}, [c]);
	let l = e?.config, u = (0, m.useMemo)(() => {
		if (!l) return null;
		let e = l.providers.filter((e) => e.enabled).length;
		return /* @__PURE__ */ (0, N.jsxs)("span", {
			className: I("text-xs", P),
			children: [
				l.providers.length,
				" provider",
				l.providers.length === 1 ? "" : "s",
				" · ",
				e,
				" enabled",
				l.loginDisabled ? " · sign-in disabled" : ""
			]
		});
	}, [l]);
	return o ? /* @__PURE__ */ (0, N.jsx)("div", {
		className: "space-y-4",
		children: /* @__PURE__ */ (0, N.jsx)(V, {
			title: "OIDC Single Sign-On",
			description: "Failed to load plugin configuration.",
			children: /* @__PURE__ */ (0, N.jsx)(U, {
				ok: !1,
				children: o
			})
		})
	}) : l ? /* @__PURE__ */ (0, N.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, N.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, N.jsx)(W, { className: "h-5 w-5" }),
					/* @__PURE__ */ (0, N.jsx)("h2", {
						className: "text-lg font-semibold tracking-tight",
						children: "OIDC Single Sign-On"
					}),
					l.loginDisabled ? /* @__PURE__ */ (0, N.jsx)(H, {
						tone: "warn",
						children: "sign-in disabled"
					}) : /* @__PURE__ */ (0, N.jsx)(H, {
						tone: "success",
						children: "sign-in enabled"
					}),
					u,
					/* @__PURE__ */ (0, N.jsxs)(L, {
						variant: "outline",
						size: "sm",
						className: "ml-auto",
						onClick: () => void c(),
						children: [/* @__PURE__ */ (0, N.jsx)(A, { className: "h-3 w-3" }), "Refresh"]
					})
				]
			}),
			/* @__PURE__ */ (0, N.jsx)(te, {
				frontendUrl: l.frontendUrl,
				loginDisabled: l.loginDisabled,
				redirectUri: e?.redirectUri || "",
				linkCount: n?.linkCount ?? 0,
				onSaved: () => void c()
			}),
			l.providers.map((e) => /* @__PURE__ */ (0, N.jsx)(ne, {
				provider: e,
				panelRoles: i,
				allProviders: l.providers,
				onSaved: () => void c()
			}, e.id)),
			/* @__PURE__ */ (0, N.jsx)(re, {
				existing: l.providers,
				onSaved: () => void c()
			})
		]
	}) : /* @__PURE__ */ (0, N.jsx)("div", {
		className: "space-y-4",
		children: /* @__PURE__ */ (0, N.jsx)(V, {
			title: "OIDC Single Sign-On",
			children: /* @__PURE__ */ (0, N.jsx)("div", {
				className: I("animate-pulse text-sm", P),
				children: "Loading…"
			})
		})
	});
}
//#endregion
//#region frontend/index.ts
var ae = l({
	manifest: {
		name: "oidc-sso",
		version: "1.0.0",
		displayName: "OIDC Single Sign-On",
		description: "Generic OpenID Connect single sign-on for any compliant identity provider",
		author: "Catalyst Team"
	},
	tabs: [{
		id: "oidc-sso",
		label: "OIDC Single Sign-On",
		icon: "KeyRound",
		component: ie,
		location: "admin",
		order: 85,
		requiredPermissions: ["admin.read"]
	}]
});
//#endregion
export { ae as default };
