//#region \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), s = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, c = (n, r, o) => (o = n == null ? {} : e(i(n)), s(r || !n || !n.__esModule || !a.call(n, "default") ? t(o, "default", {
	value: n,
	enumerable: !0
}) : o, n));
//#endregion
//#region ../sdk-frontend/plugin.ts
function l(e) {
	return {
		manifest: e.manifest,
		tabs: e.tabs,
		routes: e.routes,
		components: e.components,
		onMount: e.onMount,
		onUnmount: e.onUnmount
	};
}
//#endregion
//#region ../sdk-frontend/api.ts
var u = "";
async function d(e, t, n) {
	let { method: r = "GET", body: i, headers: a } = n ?? {}, o = `${u}/api/plugins/${e}/${t.replace(/^\//, "")}`;
	try {
		let e = await fetch(o, {
			method: r,
			credentials: "include",
			headers: {
				...i !== void 0 && !(i instanceof FormData) ? { "Content-Type": "application/json" } : {},
				...a
			},
			body: i === void 0 ? void 0 : i instanceof FormData ? i : JSON.stringify(i)
		});
		if (!e.ok) {
			let t = `HTTP ${e.status}`;
			try {
				let n = await e.json();
				t = n.error || n.message || t;
			} catch {}
			return {
				success: !1,
				error: t
			};
		}
		let t = await e.json();
		return t && typeof t == "object" && "success" in t ? t : {
			success: !0,
			data: t
		};
	} catch (e) {
		return {
			success: !1,
			error: e instanceof Error ? e.message : "Network error"
		};
	}
}
function f(e) {
	return {
		get(t) {
			return d(e, t);
		},
		post(t, n) {
			return d(e, t, {
				method: "POST",
				body: n
			});
		},
		put(t, n) {
			return d(e, t, {
				method: "PUT",
				body: n
			});
		},
		del(t) {
			return d(e, t, { method: "DELETE" });
		},
		patch(t, n) {
			return d(e, t, {
				method: "PATCH",
				body: n
			});
		}
	};
}
//#endregion
//#region ../node_modules/.pnpm/react@19.2.8/node_modules/react/cjs/react.production.js
var p = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element"), n = Symbol.for("react.consumer"), r = Symbol.for("react.context"), i = Symbol.for("react.forward_ref"), a = {
		isMounted: function() {
			return !1;
		},
		enqueueForceUpdate: function() {},
		enqueueReplaceState: function() {},
		enqueueSetState: function() {}
	}, o = Object.assign, s = {};
	function c(e, t, n) {
		this.props = e, this.context = t, this.refs = s, this.updater = n || a;
	}
	c.prototype.isReactComponent = {}, c.prototype.setState = function(e, t) {
		if (typeof e != "object" && typeof e != "function" && e != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
		this.updater.enqueueSetState(this, e, t, "setState");
	}, c.prototype.forceUpdate = function(e) {
		this.updater.enqueueForceUpdate(this, e, "forceUpdate");
	};
	function l() {}
	l.prototype = c.prototype;
	function u(e, t, n) {
		this.props = e, this.context = t, this.refs = s, this.updater = n || a;
	}
	var d = u.prototype = new l();
	d.constructor = u, o(d, c.prototype), d.isPureReactComponent = !0, Array.isArray;
	var f = {
		H: null,
		A: null,
		T: null,
		S: null
	}, p = Object.prototype.hasOwnProperty;
	function m(e, n, r) {
		var i = r.ref;
		return {
			$$typeof: t,
			type: e,
			key: n,
			ref: i === void 0 ? null : i,
			props: r
		};
	}
	e.Component = c, e.createContext = function(e) {
		return e = {
			$$typeof: r,
			_currentValue: e,
			_currentValue2: e,
			_threadCount: 0,
			Provider: null,
			Consumer: null
		}, e.Provider = e, e.Consumer = {
			$$typeof: n,
			_context: e
		}, e;
	}, e.createElement = function(e, t, n) {
		var r, i = {}, a = null;
		if (t != null) for (r in t.key !== void 0 && (a = "" + t.key), t) p.call(t, r) && r !== "key" && r !== "__self" && r !== "__source" && (i[r] = t[r]);
		var o = arguments.length - 2;
		if (o === 1) i.children = n;
		else if (1 < o) {
			for (var s = Array(o), c = 0; c < o; c++) s[c] = arguments[c + 2];
			i.children = s;
		}
		if (e && e.defaultProps) for (r in o = e.defaultProps, o) i[r] === void 0 && (i[r] = o[r]);
		return m(e, a, i);
	}, e.forwardRef = function(e) {
		return {
			$$typeof: i,
			render: e
		};
	}, e.useCallback = function(e, t) {
		return f.H.useCallback(e, t);
	}, e.useContext = function(e) {
		return f.H.useContext(e);
	}, e.useEffect = function(e, t) {
		return f.H.useEffect(e, t);
	}, e.useMemo = function(e, t) {
		return f.H.useMemo(e, t);
	}, e.useRef = function(e) {
		return f.H.useRef(e);
	}, e.useState = function(e) {
		return f.H.useState(e);
	};
})), m = /* @__PURE__ */ c((/* @__PURE__ */ o(((e, t) => {
	t.exports = p();
})))(), 1);
m.Component;
//#endregion
//#region ../node_modules/.pnpm/lucide-react@1.31.0_react@19.2.8/node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs
var h = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), g = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), _ = (e) => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()), v = (e) => {
	let t = _(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, y = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "round",
	strokeLinejoin: "round"
}, b = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, x = (0, m.createContext)({}), S = () => (0, m.useContext)(x), C = (0, m.forwardRef)(({ color: e, size: t, strokeWidth: n, absoluteStrokeWidth: r, className: i = "", children: a, iconNode: o, ...s }, c) => {
	let { size: l = 24, strokeWidth: u = 2, absoluteStrokeWidth: d = !1, color: f = "currentColor", className: p = "" } = S() ?? {}, g = r ?? d ? Number(n ?? u) * 24 / Number(t ?? l) : n ?? u;
	return (0, m.createElement)("svg", {
		ref: c,
		...y,
		width: t ?? l ?? y.width,
		height: t ?? l ?? y.height,
		stroke: e ?? f,
		strokeWidth: g,
		className: h("lucide", p, i),
		...!a && !b(s) && { "aria-hidden": "true" },
		...s
	}, [...o.map(([e, t]) => (0, m.createElement)(e, t)), ...Array.isArray(a) ? a : [a]]);
}), w = (e, t) => {
	let n = (0, m.forwardRef)(({ className: n, ...r }, i) => (0, m.createElement)(C, {
		ref: i,
		iconNode: t,
		className: h(`lucide-${g(v(e))}`, `lucide-${e}`, n),
		...r
	}));
	return n.displayName = v(e), n;
}, T = w("ban", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}], ["path", {
	d: "M4.929 4.929 19.07 19.071",
	key: "196cmz"
}]]), E = w("crosshair", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["line", {
		x1: "22",
		x2: "18",
		y1: "12",
		y2: "12",
		key: "l9bcsi"
	}],
	["line", {
		x1: "6",
		x2: "2",
		y1: "12",
		y2: "12",
		key: "13hhkx"
	}],
	["line", {
		x1: "12",
		x2: "12",
		y1: "6",
		y2: "2",
		key: "10w3f3"
	}],
	["line", {
		x1: "12",
		x2: "12",
		y1: "22",
		y2: "18",
		key: "15g9kq"
	}]
]), D = w("download", [
	["path", {
		d: "M12 15V3",
		key: "m9g1x1"
	}],
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}],
	["path", {
		d: "m7 10 5 5 5-5",
		key: "brsn70"
	}]
]), O = w("loader-circle", [["path", {
	d: "M21 12a9 9 0 1 1-6.219-8.56",
	key: "13zald"
}]]), k = w("message-square", [["path", {
	d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
	key: "18887p"
}]]), A = w("refresh-cw", [
	["path", {
		d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
		key: "v9h5vc"
	}],
	["path", {
		d: "M21 3v5h-5",
		key: "1q7to0"
	}],
	["path", {
		d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
		key: "3uifl3"
	}],
	["path", {
		d: "M8 16H3v5",
		key: "1cv678"
	}]
]), j = w("scroll-text", [
	["path", {
		d: "M15 12h-5",
		key: "r7krc0"
	}],
	["path", {
		d: "M15 8h-5",
		key: "1khuty"
	}],
	["path", {
		d: "M19 17V5a2 2 0 0 0-2-2H4",
		key: "zz82l3"
	}],
	["path", {
		d: "M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3",
		key: "1ph1d7"
	}]
]), ee = w("send", [["path", {
	d: "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",
	key: "1ffxy3"
}], ["path", {
	d: "m21.854 2.147-10.94 10.939",
	key: "12cjpa"
}]]), M = w("shield-alert", [
	["path", {
		d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
		key: "oel41y"
	}],
	["path", {
		d: "M12 8v4",
		key: "1got3b"
	}],
	["path", {
		d: "M12 16h.01",
		key: "1drbdi"
	}]
]), N = w("swords", [
	["polyline", {
		points: "14.5 17.5 3 6 3 3 6 3 17.5 14.5",
		key: "1hfsw2"
	}],
	["line", {
		x1: "13",
		x2: "19",
		y1: "19",
		y2: "13",
		key: "1vrmhu"
	}],
	["line", {
		x1: "16",
		x2: "20",
		y1: "16",
		y2: "20",
		key: "1bron3"
	}],
	["line", {
		x1: "19",
		x2: "21",
		y1: "21",
		y2: "19",
		key: "13pww6"
	}],
	["polyline", {
		points: "14.5 6.5 18 3 21 3 21 6 17.5 9.5",
		key: "hbey2j"
	}],
	["line", {
		x1: "5",
		x2: "9",
		y1: "14",
		y2: "18",
		key: "1hf58s"
	}],
	["line", {
		x1: "7",
		x2: "4",
		y1: "17",
		y2: "20",
		key: "pidxm4"
	}],
	["line", {
		x1: "3",
		x2: "5",
		y1: "19",
		y2: "21",
		key: "1pehsh"
	}]
]), P = w("triangle-alert", [
	["path", {
		d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
		key: "wmoenq"
	}],
	["path", {
		d: "M12 9v4",
		key: "juzpu7"
	}],
	["path", {
		d: "M12 17h.01",
		key: "p32p05"
	}]
]), F = w("trophy", [
	["path", {
		d: "M10 14.66V17a1 1 0 0 1-1 1 2 2 0 0 0-2 2v2",
		key: "pwuv1l"
	}],
	["path", {
		d: "M14 14.66V17a1 1 0 0 0 1 1 2 2 0 0 1 2 2v2",
		key: "1y54w1"
	}],
	["path", {
		d: "M17.916 10H19.5A2.5 2.5 0 0 0 22 7.5V5a1 1 0 0 0-1-1h-3",
		key: "e30mpu"
	}],
	["path", {
		d: "M4 22h16",
		key: "57wxv0"
	}],
	["path", {
		d: "M6 9a6 6 0 0 0 12 0V3a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1z",
		key: "1mhfuq"
	}],
	["path", {
		d: "M6.084 10H4.5A2.5 2.5 0 0 1 2 7.5V5a1 1 0 0 1 1-1h3",
		key: "i0yafy"
	}]
]), I = w("users", [
	["path", {
		d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
		key: "1yyitq"
	}],
	["path", {
		d: "M16 3.128a4 4 0 0 1 0 7.744",
		key: "16gr8j"
	}],
	["path", {
		d: "M22 21v-2a4 4 0 0 0-3-3.87",
		key: "kshegd"
	}],
	["circle", {
		cx: "9",
		cy: "7",
		r: "4",
		key: "nufk8"
	}]
]), L = f("cs16-admin");
async function R(e, t) {
	let n = await e;
	if (n && typeof n == "object" && "success" in n && n.success === !1) throw Error(n.error || "request failed");
	return t && n && typeof n == "object" && t in n ? n[t] : n && typeof n == "object" && "data" in n && t === void 0 ? n.data : n;
}
async function te(e) {
	return R(L.get(`/servers/${encodeURIComponent(e)}/info`));
}
async function z(e, t) {
	let n = await R(L.put(`/servers/${encodeURIComponent(e)}/settings`, t));
	return n.settings ?? n;
}
async function ne(e, t = {}) {
	let n = await R(L.post(`/servers/${encodeURIComponent(e)}/refresh-players`, t.silent ? { silent: !0 } : {}));
	return {
		sent: n.sent,
		transport: n.transport ?? "stdin",
		status: n.status ?? null
	};
}
function B(e, t) {
	if (e === "changed" && Array.isArray(t?.kinds)) return t.kinds.filter((e) => e === "actions" || e === "bans" || e === "settings" || e === "players");
	switch (e) {
		case "player-banned": return [
			"bans",
			"actions",
			"players"
		];
		case "player-kicked": return ["actions", "players"];
		case "map-changed": return ["actions", "players"];
		case "command-sent": return ["actions"];
		default: return ["actions"];
	}
}
function re(e, t, n) {
	let r = !1, i = null, a = null, o = 0, s = () => {
		if (r) return;
		let a;
		try {
			a = `${window.location.protocol === "https:" ? "wss:" : "ws:"}//${window.location.host}/ws`;
		} catch {
			return;
		}
		let s;
		try {
			s = new WebSocket(a);
		} catch {
			c();
			return;
		}
		i = s, s.onopen = () => {
			r || i !== s || (o = 0, n?.(!0));
		}, s.onmessage = (n) => {
			if (!(r || i !== s)) try {
				let r = JSON.parse(String(n.data)), i = typeof r?.type == "string" ? r.type : "";
				if (!i.startsWith("plugin:cs16-admin:")) return;
				let a = r.data ?? {};
				if (a.serverId && a.serverId !== e) return;
				t(B(i.slice(18), a));
			} catch {}
		};
		let l = () => {
			r || i !== s || (n?.(!1), c());
		};
		s.onclose = l, s.onerror = l;
	}, c = () => {
		if (r) return;
		try {
			i?.close();
		} catch {}
		i &&= null;
		let e = Math.min(3e4, 1e3 * 1.6 ** Math.min(o, 8));
		o += 1, a && clearTimeout(a), a = setTimeout(s, e);
	};
	return s(), () => {
		r = !0, a && clearTimeout(a), a = null;
		try {
			i?.close();
		} catch {}
		i = null;
	};
}
async function ie(e) {
	return R(L.get(`/servers/${encodeURIComponent(e)}/transport`));
}
async function V(e) {
	return R(L.post(`/servers/${encodeURIComponent(e)}/rcon-test`, {}));
}
async function H(e) {
	let t = await R(e);
	return {
		sent: t.sent,
		transport: t.transport ?? "stdin"
	};
}
async function ae(e, t) {
	return H(L.post(`/servers/${encodeURIComponent(e)}/command`, { command: t }));
}
async function oe(e, t, n = {}) {
	return H(L.post(`/servers/${encodeURIComponent(e)}/say`, {
		message: t,
		...n
	}));
}
async function se(e, t) {
	return H(L.post(`/servers/${encodeURIComponent(e)}/kick`, t));
}
async function ce(e, t) {
	return H(L.post(`/servers/${encodeURIComponent(e)}/ban`, t));
}
async function le(e, t, n) {
	return H(L.post(`/servers/${encodeURIComponent(e)}/unban`, {
		steamId: t,
		useAmx: n
	}));
}
async function ue(e) {
	return (await R(L.get(`/servers/${encodeURIComponent(e)}/bans`))).bans ?? [];
}
async function de(e, t, n) {
	return H(L.post(`/servers/${encodeURIComponent(e)}/map`, {
		map: t,
		useAmx: n
	}));
}
async function fe(e, t = 1) {
	return H(L.post(`/servers/${encodeURIComponent(e)}/restart`, { seconds: t }));
}
async function pe(e, t, n) {
	return H(L.post(`/servers/${encodeURIComponent(e)}/cvar`, {
		cvar: t,
		value: n
	}));
}
async function me(e, t, n, r = "") {
	return H(L.post(`/servers/${encodeURIComponent(e)}/amx`, {
		action: t,
		target: n,
		extra: r
	}));
}
async function he(e, t = {}) {
	let n = new URLSearchParams();
	t.user && n.set("user", t.user), t.action && n.set("action", t.action), t.search && n.set("search", t.search), t.from && n.set("from", t.from), t.to && n.set("to", t.to), n.set("page", String(t.page ?? 1)), n.set("pageSize", String(t.pageSize ?? 20));
	let r = await R(L.get(`/servers/${encodeURIComponent(e)}/actions?${n.toString()}`));
	return Array.isArray(r) ? {
		actions: r,
		total: r.length,
		page: 1,
		pageSize: r.length,
		users: []
	} : {
		actions: r.actions ?? [],
		total: r.total ?? 0,
		page: r.page ?? 1,
		pageSize: r.pageSize ?? 20,
		users: r.users ?? []
	};
}
function ge(e, t = {}) {
	let n = new URLSearchParams();
	return t.user && n.set("user", t.user), t.action && n.set("action", t.action), t.search && n.set("search", t.search), t.from && n.set("from", t.from), t.to && n.set("to", t.to), `/api/plugins/cs16-admin/servers/${encodeURIComponent(e)}/actions.csv?${n.toString()}`;
}
async function _e(e) {
	let t = await R(L.get(`/servers/${encodeURIComponent(e)}/ban-files`));
	return {
		available: !!t.available,
		files: t.files ?? {}
	};
}
async function ve(e, t = 500) {
	let n = await fetch(`/api/servers/${encodeURIComponent(e)}/logs?lines=${t}`, { credentials: "include" });
	if (!n.ok) throw Error(`console history failed (HTTP ${n.status})`);
	let r = await n.json(), i = r?.data?.logs ?? r?.logs ?? [];
	return Array.isArray(i) ? i : [];
}
function ye(e, t, n) {
	let r = !1, i = null;
	try {
		i = new EventSource(`/api/servers/${encodeURIComponent(e)}/console/stream`, { withCredentials: !0 });
	} catch {
		return n?.(!1), () => {};
	}
	n?.(!1);
	let a = (e) => {
		if (!r) try {
			let n = JSON.parse(e.data);
			t(typeof n?.data == "string" ? n.data : String(e.data ?? ""), typeof n?.stream == "string" ? n.stream : "stdout");
		} catch {
			t(String(e.data ?? ""), "stdout");
		}
	};
	return i.addEventListener("console_output", a), i.onopen = () => n?.(!0), i.onerror = () => n?.(!1), () => {
		r = !0;
		try {
			i?.removeEventListener("console_output", a), i?.close();
		} catch {}
		i = null;
	};
}
//#endregion
//#region frontend/parsers.ts
var be = /^L\s+\d{2}\/\d{2}\/\d{4}\s+-\s+\d{2}:\d{2}:\d{2}:\s*/;
function xe(e) {
	return e.replace(be, "");
}
function Se(e) {
	let t = e, n = !1;
	return /^\*DEAD\*/i.test(t) && (n = !0, t = t.replace(/^\*DEAD\*\s*/i, "")), t = t.replace(/^\((Terrorist|Counter-Terrorist|Spectator|TERRORIST|CT|T)\)\s*/i, "").replace(/\s*\((Terrorist|Counter-Terrorist|Spectator)\)\s*$/i, "").trim(), {
		name: t || e.trim(),
		isDead: n
	};
}
function Ce(e) {
	let t = (e || "").toUpperCase();
	return t ? t === "CT" || t.includes("COUNTER") ? "CT" : t === "T" || t.includes("TERRORIST") ? "T" : t.includes("SPEC") ? "SPEC" : null : null;
}
var we = /"(.+?)<(\d+)><([^>]+)><([^>]*)>"\s+(say|say_team)\s+"(.*)"\s*$/, Te = /"(.+?)<(\d+)><([^>]+)><([^>]*)>"/;
function Ee(e, t) {
	let n = xe(e);
	if (/\bServer\s+say\s+"/i.test(n)) {
		let r = n.match(/\bServer\s+say\s+"(.*)"\s*$/i);
		return r ? {
			key: t,
			name: "Server",
			steamId: "",
			userid: null,
			team: null,
			isTeam: !1,
			isDead: !1,
			message: r[1],
			raw: e
		} : null;
	}
	let r = n.match(we);
	if (!r) return null;
	let [, i, a, o, s, c, l] = r, { name: u, isDead: d } = Se(i);
	return {
		key: t,
		name: u,
		steamId: (o || "").trim(),
		userid: Number.isFinite(Number(a)) ? Number(a) : null,
		team: Ce(s),
		isTeam: c === "say_team",
		isDead: d,
		message: l,
		raw: e
	};
}
function De(e, t) {
	let n = xe(e), r = n.match(Te);
	if (!r) {
		let r = n.match(/Dropped\s+"([^"]+)"\s+from\s+server/i);
		return r ? {
			key: t,
			kind: "disconnected",
			name: r[1],
			steamId: "",
			raw: e
		} : null;
	}
	let [, i, , a] = r, { name: o } = Se(i), s = n.toLowerCase();
	return s.includes("connected, address") ? {
		key: t,
		kind: "connected",
		name: o,
		steamId: a,
		raw: e
	} : s.includes("disconnected") || s.includes("dropped") ? {
		key: t,
		kind: "disconnected",
		name: o,
		steamId: a,
		raw: e
	} : s.includes("entered the game") ? {
		key: t,
		kind: "entered",
		name: o,
		steamId: a,
		raw: e
	} : s.includes("joined team") ? {
		key: t,
		kind: "team-join",
		name: o,
		steamId: a,
		raw: e
	} : null;
}
var Oe = /Team\s+"([^"]+)"\s+scored\s+"(\d+)"/i, ke = /Loading\s+map\s+"([^"]+)"/i, Ae = /Started\s+map\s+"([^"]+)"/i;
function je(e) {
	let t = e.trim().toUpperCase();
	return t === "CT" || t.includes("COUNTER") ? "CT" : t === "T" || t.includes("TERROR") ? "T" : null;
}
function Me(e, t) {
	let n = xe(e);
	if (/World\s+triggered\s+"Round_Start"/i.test(n)) return {
		key: t,
		kind: "round-start",
		raw: e
	};
	if (/World\s+triggered\s+"Round_Draw"/i.test(n)) return {
		key: t,
		kind: "round-draw",
		winner: null,
		raw: e
	};
	if (/World\s+triggered\s+"Round_End"/i.test(n)) return {
		key: t,
		kind: "round-end",
		raw: e
	};
	if (/World\s+triggered\s+"Game_Commencing"/i.test(n)) return {
		key: t,
		kind: "game-commencing",
		raw: e
	};
	if (/(Round_Restart|Game\s+restarted|Restarting\s+round)/i.test(n)) return {
		key: t,
		kind: "restart",
		raw: e
	};
	let r = n.match(Oe);
	if (r) {
		let n = je(r[1]);
		if (!n) return null;
		let i = Number(r[2]);
		return {
			key: t,
			kind: "score",
			raw: e,
			ctScore: n === "CT" ? i : void 0,
			tScore: n === "T" ? i : void 0
		};
	}
	if (/CTs_Win/i.test(n)) return {
		key: t,
		kind: "round-end",
		winner: "CT",
		raw: e
	};
	if (/Terrorists?_Win/i.test(n)) return {
		key: t,
		kind: "round-end",
		winner: "T",
		raw: e
	};
	let i = n.match(ke);
	if (i) return {
		key: t,
		kind: "map-loading",
		map: i[1],
		raw: e
	};
	let a = n.match(Ae);
	return a ? {
		key: t,
		kind: "map-started",
		map: a[1],
		raw: e
	} : null;
}
var Ne = /^hostname\s*:\s*(.+)$/i, Pe = /^map\s*:\s*(\S+)/i, Fe = /^players\s*:\s*(\d+)\s+active\s*\((\d+)\s*max\)/i, Ie = /^#\s+(\d+)\s+"([^"]*)"\s+(\d+)\s+(\S+)(.*)$/;
function Le(e) {
	let t = {
		hostname: null,
		map: null,
		playersActive: null,
		playersMax: null,
		players: []
	}, n = String(e || "").split("\n"), r = 0;
	for (let e = 0; e < n.length; e++) Ne.test(n[e].trim()) && (r = e);
	let i = /* @__PURE__ */ new Set();
	for (let e = r; e < n.length; e++) {
		let r = n[e].trim();
		if (!r) continue;
		let a = r.match(Ne);
		if (a) {
			t.hostname = a[1].trim();
			continue;
		}
		let o = r.match(Pe);
		if (o) {
			t.map = o[1].trim();
			continue;
		}
		let s = r.match(Fe);
		if (s) {
			t.playersActive = Number(s[1]), t.playersMax = Number(s[2]);
			continue;
		}
		let c = r.match(Ie);
		if (c) {
			let e = Number(c[1]), n = c[2], r = Number(c[3]), a = c[4], o = (c[5] || "").trim().split(/\s+/).filter(Boolean), s = `${r}:${a}:${n}`;
			if (i.has(s)) continue;
			i.add(s), t.players.push({
				slot: Number.isFinite(e) ? e : null,
				userid: Number.isFinite(r) ? r : null,
				name: n,
				steamId: a,
				frag: o.length > 0 && /^-?\d+$/.test(o[0]) ? Number(o[0]) : null,
				time: o.length > 1 ? o[1] : null,
				ping: o.length > 2 && /^\d+$/.test(o[2]) ? Number(o[2]) : null,
				loss: o.length > 3 && /^\d+$/.test(o[3]) ? Number(o[3]) : null,
				address: o.length > 4 ? o[o.length - 1] : null,
				isBot: a === "BOT"
			});
		}
	}
	return t;
}
function Re() {
	return {
		map: null,
		round: 0,
		ctScore: 0,
		tScore: 0,
		history: []
	};
}
function ze(e, t) {
	let n = {
		...e,
		history: [...e.history]
	};
	switch (t.kind) {
		case "round-start": return n.round = e.round + 1, n;
		case "round-end": {
			let r = t.winner ?? null, i = e.round === 0 ? e.history.length + 1 : e.round;
			return n.history = [...e.history, {
				round: i,
				winner: r ?? "Draw",
				ctScore: e.ctScore + +(r === "CT"),
				tScore: e.tScore + +(r === "T")
			}], r === "CT" && (n.ctScore = e.ctScore + 1), r === "T" && (n.tScore = e.tScore + 1), n;
		}
		case "round-draw": return n.history = [...e.history, {
			round: e.round || e.history.length + 1,
			winner: "Draw",
			ctScore: e.ctScore,
			tScore: e.tScore
		}], n;
		case "score": return typeof t.ctScore == "number" && (n.ctScore = t.ctScore), typeof t.tScore == "number" && (n.tScore = t.tScore), n;
		case "map-loading":
		case "map-started": return {
			map: t.map ?? e.map,
			round: 0,
			ctScore: 0,
			tScore: 0,
			history: []
		};
		case "game-commencing":
		case "restart": return {
			...e,
			round: 0,
			ctScore: 0,
			tScore: 0,
			history: []
		};
		default: return n;
	}
}
//#endregion
//#region ../node_modules/.pnpm/react@19.2.8/node_modules/react/cjs/react-jsx-runtime.production.js
var Be = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element");
	function n(e, n, r) {
		var i = null;
		if (r !== void 0 && (i = "" + r), n.key !== void 0 && (i = "" + n.key), "key" in n) for (var a in r = {}, n) a !== "key" && (r[a] = n[a]);
		else r = n;
		return n = r.ref, {
			$$typeof: t,
			type: e,
			key: i,
			ref: n === void 0 ? null : n,
			props: r
		};
	}
	e.jsx = n, e.jsxs = n;
})), U = (/* @__PURE__ */ o(((e, t) => {
	t.exports = Be();
})))(), Ve = "text-muted-foreground", W = (...e) => e.filter(Boolean).join(" ");
function G({ variant: e = "default", size: t = "default", className: n, ...r }) {
	return /* @__PURE__ */ (0, U.jsx)("button", {
		className: W("inline-flex items-center justify-center gap-1.5 rounded-md font-medium transition-colors disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring whitespace-nowrap", {
			default: "h-9 px-4 py-2 text-sm",
			sm: "h-7 rounded-md px-2.5 text-xs",
			xs: "h-6 rounded px-2 text-[11px]"
		}[t], {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			outline: "border border-border bg-transparent shadow-sm hover:bg-accent hover:text-accent-foreground",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			danger: "border border-red-800/60 bg-red-950/40 text-red-300 hover:bg-red-900/40"
		}[e], n),
		...r
	});
}
function K({ className: e, children: t }) {
	return /* @__PURE__ */ (0, U.jsx)("div", {
		className: W("rounded-lg border border-border bg-card p-4", e),
		children: t
	});
}
function q({ children: e }) {
	return /* @__PURE__ */ (0, U.jsx)("h3", {
		className: "text-sm font-semibold mb-3",
		children: e
	});
}
function J({ tone: e = "zinc", title: t, children: n }) {
	return /* @__PURE__ */ (0, U.jsx)("span", {
		title: t,
		className: W("inline-flex items-center rounded border px-1.5 py-0.5 text-[11px] font-medium", {
			zinc: "border-zinc-700/60 bg-zinc-800/60 text-zinc-300",
			green: "border-emerald-700/50 bg-emerald-950/40 text-emerald-300",
			red: "border-red-700/50 bg-red-950/40 text-red-300",
			amber: "border-amber-700/50 bg-amber-950/40 text-amber-300",
			blue: "border-sky-700/50 bg-sky-950/40 text-sky-300",
			purple: "border-purple-700/50 bg-purple-950/40 text-purple-300"
		}[e]),
		children: n
	});
}
function Y(e) {
	return /* @__PURE__ */ (0, U.jsx)("input", {
		...e,
		className: W("flex h-9 w-full rounded-md border border-border bg-transparent px-3 py-1 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring disabled:opacity-50", e.className)
	});
}
function He({ value: e, onValueChange: t, placeholder: n, children: r, className: i }) {
	return /* @__PURE__ */ (0, U.jsxs)("select", {
		className: W("flex h-9 w-full items-center rounded-md border border-border bg-transparent px-3 py-1 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring disabled:opacity-50", i),
		value: e || "",
		onChange: (e) => t(e.target.value),
		children: [/* @__PURE__ */ (0, U.jsx)("option", {
			value: "",
			disabled: !0,
			children: n ?? "Select…"
		}), r]
	});
}
function X({ value: e, children: t }) {
	return /* @__PURE__ */ (0, U.jsx)("option", {
		value: e,
		className: "bg-popover text-popover-foreground",
		children: t
	});
}
function Z({ className: e }) {
	return /* @__PURE__ */ (0, U.jsx)("div", { className: W("animate-pulse rounded-md bg-muted", e) });
}
function Q({ label: e, value: t, sub: n }) {
	return /* @__PURE__ */ (0, U.jsxs)("div", {
		className: "rounded-lg border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, U.jsx)("div", {
				className: W("text-xs font-medium uppercase tracking-wide", Ve),
				children: e
			}),
			/* @__PURE__ */ (0, U.jsx)("div", {
				className: "mt-1 text-2xl font-bold",
				children: t
			}),
			n ? /* @__PURE__ */ (0, U.jsx)("div", {
				className: W("mt-0.5 text-xs", Ve),
				children: n
			}) : null
		]
	});
}
function $({ className: e }) {
	return /* @__PURE__ */ (0, U.jsx)(O, { className: W("h-4 w-4 animate-spin", e) });
}
//#endregion
//#region frontend/components.tsx
var Ue = 500, We = 15e3, Ge = 2e4;
function Ke(e = 3e4) {
	let [t, n] = (0, m.useState)(() => Date.now());
	return (0, m.useEffect)(() => {
		let t = setInterval(() => n(Date.now()), e);
		return () => clearInterval(t);
	}, [e]), t;
}
function qe(e, t) {
	if (!e) return "never";
	let n = Math.max(0, ((t ?? Date.now()) - Date.parse(e)) / 1e3);
	return Number.isFinite(n) ? n < 60 ? `${Math.floor(n)}s ago` : n < 3600 ? `${Math.floor(n / 60)}m ago` : n < 86400 ? `${Math.floor(n / 3600)}h ago` : `${Math.floor(n / 86400)}d ago` : "never";
}
function Je(e) {
	return String(e || "").replace(/\r\n/g, "\n").split("\n");
}
function Ye(e) {
	return e === "CT" ? /* @__PURE__ */ (0, U.jsx)(J, {
		tone: "blue",
		children: "CT"
	}) : e === "T" ? /* @__PURE__ */ (0, U.jsx)(J, {
		tone: "red",
		children: "T"
	}) : e === "SPEC" ? /* @__PURE__ */ (0, U.jsx)(J, {
		tone: "zinc",
		children: "SPEC"
	}) : null;
}
function Xe({ serverId: e }) {
	let [t, n] = (0, m.useState)(null), [r, i] = (0, m.useState)(null), [a, o] = (0, m.useState)(null), [s, c] = (0, m.useState)([]), [l, u] = (0, m.useState)(null), [d, f] = (0, m.useState)(!0), [p, h] = (0, m.useState)(null), [g, _] = (0, m.useState)(!1), [v, y] = (0, m.useState)(null), [b, x] = (0, m.useState)(0), [S, C] = (0, m.useState)(""), [w, T] = (0, m.useState)([]), [E, D] = (0, m.useState)([]), [O, k] = (0, m.useState)([]), A = (0, m.useRef)(0), j = (0, m.useRef)(""), ee = Ke(), M = (0, m.useCallback)((e, t) => {
		if (t === "stdin" || t === "system" || !e) return;
		j.current = (j.current + e).slice(-2e5), C(j.current);
		let n = [], r = [], i = [];
		for (let t of Je(e)) {
			if (!t.trim()) continue;
			let e = Ee(t, "");
			if (e) {
				e.key = `${Date.now().toString(36)}-${A.current++}`, n.push(e);
				continue;
			}
			let a = De(t, "");
			a && (a.key = `${Date.now().toString(36)}-${A.current++}`, r.push(a));
			let o = Me(t, "");
			o && (o.key = `${Date.now().toString(36)}-${A.current++}`, i.push(o));
		}
		n.length && T((e) => [...e, ...n].slice(-300)), r.length && D((e) => [...e, ...r].slice(-300)), i.length && k((e) => [...e, ...i].slice(-300));
	}, []), N = (0, m.useCallback)(async () => {
		h(null);
		try {
			let [t, r, a] = await Promise.all([
				te(e),
				ue(e).catch(() => []),
				ie(e).catch(() => null)
			]);
			n(t.server), i(t.settings), c(r), u(t.actionCount ?? null), o(a);
		} catch (e) {
			h(e?.message || "Failed to load CS 1.6 admin data");
		} finally {
			f(!1);
		}
	}, [e]);
	(0, m.useEffect)(() => {
		let t = !1;
		return f(!0), T([]), D([]), k([]), j.current = "", C(""), y(null), N(), ve(e, Ue).then((e) => {
			if (t) return;
			let n = e.map((e) => e.data).join("");
			n && M(n, "stdout");
		}, (e) => {
			t || y(e?.message || "Console history unavailable");
		}), () => {
			t = !0;
		};
	}, [
		e,
		N,
		M
	]), (0, m.useEffect)(() => ye(e, (e, t) => M(e, t), _), [e, M]);
	let F = (0, m.useRef)(!1), I = (0, m.useCallback)(async () => {
		if (!F.current && !(typeof document < "u" && document.hidden)) {
			F.current = !0;
			try {
				let t = await ne(e, { silent: !0 });
				t.status && M(t.status.endsWith("\n") ? t.status : `${t.status}\n`, "stdout");
			} catch {} finally {
				F.current = !1;
			}
		}
	}, [e, M]);
	(0, m.useEffect)(() => {
		let e = setTimeout(() => void I(), 1200);
		return () => clearTimeout(e);
	}, [e, I]);
	let L = (0, m.useMemo)(() => Le(S), [S]), R = (0, m.useMemo)(() => {
		let e = Re();
		L.map && (e = {
			...e,
			map: L.map
		});
		for (let t of O) e = ze(e, t);
		return e;
	}, [O, L.map]), z = (0, m.useCallback)(async () => {
		await N(), x((e) => e + 1), I();
	}, [N, I]);
	(0, m.useEffect)(() => re(e, (e) => {
		N(), (e.includes("actions") || e.includes("bans") || e.includes("settings")) && x((e) => e + 1), e.includes("players") && I();
	}), [
		e,
		N,
		I
	]);
	let B = !r || r.enabled !== !1, V = (t?.status ?? "").toLowerCase() === "running";
	(0, m.useEffect)(() => {
		if (!B) return;
		let e = setInterval(() => {
			(V || !t) && I();
		}, We);
		return () => clearInterval(e);
	}, [
		B,
		V,
		t,
		I
	]), (0, m.useEffect)(() => {
		if (!B) return;
		let e = setInterval(() => {
			typeof document < "u" && document.hidden || N();
		}, Ge);
		return () => clearInterval(e);
	}, [B, N]);
	let H = (0, m.useRef)(!1);
	(0, m.useEffect)(() => {
		g && !H.current && (N(), I(), x((e) => e + 1)), H.current = g;
	}, [
		g,
		N,
		I
	]), (0, m.useEffect)(() => {
		let e = () => {
			N(), I(), x((e) => e + 1);
		}, t = () => {
			typeof document < "u" && !document.hidden && e();
		};
		return window.addEventListener("focus", e), document.addEventListener("visibilitychange", t), () => {
			window.removeEventListener("focus", e), document.removeEventListener("visibilitychange", t);
		};
	}, [N, I]);
	let ae = (0, m.useCallback)(async () => {
		await N(), x((e) => e + 1);
		try {
			let t = await ne(e);
			t.status && M(t.status.endsWith("\n") ? t.status : `${t.status}\n`, "stdout");
		} catch (e) {
			h(e?.message || "Failed to request status");
		}
	}, [
		N,
		e,
		M
	]);
	return d && !t ? /* @__PURE__ */ (0, U.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, U.jsx)(Z, { className: "h-10 w-64" }),
			/* @__PURE__ */ (0, U.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-4 gap-3",
				children: [
					/* @__PURE__ */ (0, U.jsx)(Z, { className: "h-20 w-full" }),
					/* @__PURE__ */ (0, U.jsx)(Z, { className: "h-20 w-full" }),
					/* @__PURE__ */ (0, U.jsx)(Z, { className: "h-20 w-full" }),
					/* @__PURE__ */ (0, U.jsx)(Z, { className: "h-20 w-full" })
				]
			}),
			/* @__PURE__ */ (0, U.jsx)(Z, { className: "h-64 w-full" })
		]
	}) : r && r.enabled === !1 ? /* @__PURE__ */ (0, U.jsx)(Ze, {
		serverId: e,
		serverName: t?.name ?? null,
		onEnabled: (e) => i(e)
	}) : /* @__PURE__ */ (0, U.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, U.jsx)(Qe, {
				info: t,
				connected: g,
				playersActive: L.playersActive ?? L.players.length,
				playersMax: L.playersMax,
				map: R.map ?? L.map,
				transport: a,
				onRefresh: ae
			}),
			p ? /* @__PURE__ */ (0, U.jsxs)("div", {
				className: "flex items-center gap-2 rounded-lg border border-red-700/40 bg-red-950/30 px-3 py-2 text-sm text-red-300",
				children: [
					/* @__PURE__ */ (0, U.jsx)(P, { className: "h-4 w-4 shrink-0" }),
					" ",
					p
				]
			}) : null,
			v ? /* @__PURE__ */ (0, U.jsxs)("div", {
				className: "flex items-center gap-2 rounded-lg border border-amber-700/40 bg-amber-950/30 px-3 py-2 text-sm text-amber-300",
				children: [
					/* @__PURE__ */ (0, U.jsx)(P, { className: "h-4 w-4 shrink-0" }),
					" Live parsing is limited: ",
					v,
					" (needs console.read)."
				]
			}) : null,
			/* @__PURE__ */ (0, U.jsxs)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
				children: [
					/* @__PURE__ */ (0, U.jsx)(Q, {
						label: "Players",
						value: `${L.playersActive ?? L.players.length}${L.playersMax ? ` / ${L.playersMax}` : ""}`,
						sub: g ? "live stream" : "auto-refresh"
					}),
					/* @__PURE__ */ (0, U.jsx)(Q, {
						label: "Map",
						value: R.map ?? L.map ?? "—",
						sub: t?.status ? `server ${t.status}` : void 0
					}),
					/* @__PURE__ */ (0, U.jsx)(Q, {
						label: "Round",
						value: R.round > 0 ? String(R.round) : "—",
						sub: `CT ${R.ctScore} : ${R.tScore} T`
					}),
					/* @__PURE__ */ (0, U.jsx)(Q, {
						label: "Active bans",
						value: String(s.filter((e) => (e.status ?? "active") === "active").length),
						sub: l == null ? "audit log below" : `${l} audit entries`
					})
				]
			}),
			/* @__PURE__ */ (0, U.jsx)($e, {
				serverId: e,
				players: L.players,
				useAmx: r?.useAmx ?? !0,
				onChanged: z
			}),
			/* @__PURE__ */ (0, U.jsxs)("div", {
				className: "grid grid-cols-1 xl:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ (0, U.jsx)(et, {
					serverId: e,
					chat: w,
					notices: E,
					useAmx: r?.useAmx ?? !0,
					onSent: z
				}), /* @__PURE__ */ (0, U.jsx)(tt, {
					match: R,
					serverId: e,
					useAmx: r?.useAmx ?? !0,
					onChanged: z
				})]
			}),
			/* @__PURE__ */ (0, U.jsx)(nt, {
				serverId: e,
				bans: s,
				defaultMinutes: r?.defaultBanMinutes ?? 1440,
				useAmx: r?.useAmx ?? !0,
				onChanged: z,
				now: ee
			}),
			/* @__PURE__ */ (0, U.jsx)(it, {
				serverId: e,
				settings: r,
				transport: a,
				onSettingsChanged: (e) => i(e),
				onTransportChanged: (e) => o(e),
				onChanged: z,
				auditRefreshKey: b
			})
		]
	});
}
function Ze({ serverId: e, serverName: t, onEnabled: n }) {
	let [r, i] = (0, m.useState)(!1), [a, o] = (0, m.useState)(null), s = async () => {
		i(!0), o(null);
		try {
			n(await z(e, { enabled: !0 }));
		} catch (e) {
			o(e?.message || "Failed to enable CS 1.6 Admin for this server");
		} finally {
			i(!1);
		}
	};
	return /* @__PURE__ */ (0, U.jsxs)(K, {
		className: "max-w-xl",
		children: [
			/* @__PURE__ */ (0, U.jsx)(q, { children: /* @__PURE__ */ (0, U.jsxs)("span", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, U.jsx)(E, { className: "h-4 w-4" }), " CS 1.6 Admin is off for this server"]
			}) }),
			/* @__PURE__ */ (0, U.jsxs)("p", {
				className: "text-sm mb-4",
				style: { color: "var(--muted-foreground)" },
				children: [t ? /* @__PURE__ */ (0, U.jsx)("span", {
					className: "font-medium text-foreground",
					children: t
				}) : "This server", " is not managed by the CS 1.6 tab yet. Enable it to unlock live players, chat, rounds, kick, ban, map control and cvars here. Other servers are unaffected."]
			}),
			a ? /* @__PURE__ */ (0, U.jsx)("p", {
				className: "mb-2 text-xs text-red-300",
				children: a
			}) : null,
			/* @__PURE__ */ (0, U.jsxs)(G, {
				size: "sm",
				onClick: () => void s(),
				disabled: r,
				children: [r ? /* @__PURE__ */ (0, U.jsx)($, {}) : null, " Enable for this server"]
			})
		]
	});
}
function Qe({ info: e, connected: t, playersActive: n, playersMax: r, map: i, transport: a, onRefresh: o }) {
	let [s, c] = (0, m.useState)(!1);
	return /* @__PURE__ */ (0, U.jsxs)("div", {
		className: "flex flex-wrap items-start justify-between gap-3",
		children: [/* @__PURE__ */ (0, U.jsxs)("div", { children: [/* @__PURE__ */ (0, U.jsxs)("h2", {
			className: "text-2xl font-bold flex items-center gap-2",
			children: [/* @__PURE__ */ (0, U.jsx)(E, { className: "h-6 w-6 text-orange-400" }), " CS 1.6 Admin"]
		}), /* @__PURE__ */ (0, U.jsxs)("p", {
			className: "text-sm mt-1",
			style: { color: "var(--muted-foreground)" },
			children: [
				e ? /* @__PURE__ */ (0, U.jsx)("span", {
					className: "font-medium text-foreground",
					children: e.name
				}) : "Server management",
				i ? /* @__PURE__ */ (0, U.jsxs)("span", {
					className: "font-mono",
					children: [" · ", i]
				}) : null,
				/* @__PURE__ */ (0, U.jsxs)("span", { children: [
					" · ",
					n,
					r ? `/${r}` : "",
					" players"
				] })
			]
		})] }), /* @__PURE__ */ (0, U.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, U.jsx)(J, {
					tone: t ? "green" : "amber",
					children: t ? "Live" : "Connecting…"
				}),
				a?.rcon.available ? /* @__PURE__ */ (0, U.jsx)(J, {
					tone: "blue",
					title: `RCON via ${a.rcon.source} (${a.rcon.host}:${a.rcon.port})`,
					children: "RCON"
				}) : a ? /* @__PURE__ */ (0, U.jsx)(J, {
					tone: "zinc",
					title: a.rcon.reason ?? "RCON not configured — commands use console input",
					children: "Console"
				}) : null,
				/* @__PURE__ */ (0, U.jsxs)(G, {
					size: "sm",
					variant: "outline",
					onClick: () => {
						c(!0), Promise.resolve(o()).finally(() => setTimeout(() => c(!1), 1200));
					},
					disabled: s,
					children: [s ? /* @__PURE__ */ (0, U.jsx)($, {}) : /* @__PURE__ */ (0, U.jsx)(A, { className: "h-3.5 w-3.5" }), " Refresh status"]
				})
			]
		})]
	});
}
function $e({ serverId: e, players: t, useAmx: n, onChanged: r }) {
	let [i, a] = (0, m.useState)(""), [o, s] = (0, m.useState)(""), [c, l] = (0, m.useState)(""), [u, d] = (0, m.useState)("1440"), [f, p] = (0, m.useState)(null), [h, g] = (0, m.useState)(null), _ = (0, m.useMemo)(() => {
		let e = i.trim().toLowerCase();
		return e ? t.filter((t) => t.name.toLowerCase().includes(e) || t.steamId.toLowerCase().includes(e) || String(t.userid ?? "").includes(e)) : t;
	}, [t, i]), v = (0, m.useMemo)(() => t.find((e) => (e.userid == null ? e.name : `#${e.userid}`) === o) ?? null, [t, o]), y = (0, m.useCallback)(async (e, t) => {
		p(e), g(null);
		try {
			let e = await t();
			await r(), g(`Command sent${e?.transport === "rcon" ? " via RCON." : " via console."}`);
		} catch (e) {
			g(e?.message || "Command failed");
		} finally {
			p(null);
		}
	}, [r]), b = (t) => y(`kick-${t.userid ?? t.name}`, () => se(e, {
		userid: t.userid == null ? void 0 : `#${t.userid}`,
		name: t.userid == null ? t.name : void 0,
		steamId: t.steamId,
		reason: c || void 0,
		useAmx: n
	})), x = (t) => y(`ban-${t.userid ?? t.name}`, () => ce(e, {
		steamId: t.steamId,
		name: t.name,
		minutes: Number(u) || 0,
		reason: c || void 0,
		useAmx: n
	}));
	return /* @__PURE__ */ (0, U.jsxs)(K, { children: [
		/* @__PURE__ */ (0, U.jsx)(q, { children: /* @__PURE__ */ (0, U.jsxs)("span", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, U.jsx)(I, { className: "h-4 w-4" }),
				" Players (",
				_.length,
				")"
			]
		}) }),
		/* @__PURE__ */ (0, U.jsxs)("div", {
			className: "flex flex-col md:flex-row gap-2 mb-3",
			children: [
				/* @__PURE__ */ (0, U.jsx)(Y, {
					placeholder: "Filter by name, SteamID or userid…",
					value: i,
					onChange: (e) => a(e.target.value)
				}),
				/* @__PURE__ */ (0, U.jsx)(Y, {
					placeholder: "Reason (optional)",
					value: c,
					onChange: (e) => l(e.target.value),
					className: "md:max-w-64"
				}),
				/* @__PURE__ */ (0, U.jsx)(Y, {
					placeholder: "Ban minutes (0 = permanent)",
					value: u,
					onChange: (e) => d(e.target.value),
					inputMode: "numeric",
					className: "md:max-w-48"
				})
			]
		}),
		t.length === 0 ? /* @__PURE__ */ (0, U.jsxs)("p", {
			className: "text-sm",
			style: { color: "var(--muted-foreground)" },
			children: [
				"No players parsed yet. Press ",
				/* @__PURE__ */ (0, U.jsx)("strong", { children: "Refresh status" }),
				" while the server is running, then watch this list populate from the ",
				/* @__PURE__ */ (0, U.jsx)("span", {
					className: "font-mono",
					children: "status"
				}),
				" dump."
			]
		}) : /* @__PURE__ */ (0, U.jsx)("div", {
			className: "overflow-x-auto rounded-md border border-border",
			children: /* @__PURE__ */ (0, U.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, U.jsx)("thead", { children: /* @__PURE__ */ (0, U.jsxs)("tr", {
					className: "text-left text-xs uppercase tracking-wide",
					style: { color: "var(--muted-foreground)" },
					children: [
						/* @__PURE__ */ (0, U.jsx)("th", {
							className: "px-3 py-2",
							children: "Player"
						}),
						/* @__PURE__ */ (0, U.jsx)("th", {
							className: "px-3 py-2",
							children: "SteamID"
						}),
						/* @__PURE__ */ (0, U.jsx)("th", {
							className: "px-3 py-2 hidden sm:table-cell",
							children: "Userid"
						}),
						/* @__PURE__ */ (0, U.jsx)("th", {
							className: "px-3 py-2 hidden md:table-cell",
							children: "Frag / Ping"
						}),
						/* @__PURE__ */ (0, U.jsx)("th", {
							className: "px-3 py-2 text-right",
							children: "Actions"
						})
					]
				}) }), /* @__PURE__ */ (0, U.jsx)("tbody", { children: _.map((e) => {
					let t = `${e.userid ?? e.slot ?? e.name}-${e.steamId}`, n = e.userid == null ? e.name : `#${e.userid}`, r = o === n;
					return /* @__PURE__ */ (0, U.jsxs)("tr", {
						className: `border-t border-border cursor-pointer ${r ? "bg-accent/40" : ""}`,
						onClick: () => s(r ? "" : n),
						children: [
							/* @__PURE__ */ (0, U.jsxs)("td", {
								className: "px-3 py-2",
								children: [/* @__PURE__ */ (0, U.jsx)("span", {
									className: "font-medium",
									children: e.name
								}), e.isBot ? /* @__PURE__ */ (0, U.jsx)("span", {
									className: "ml-2",
									children: /* @__PURE__ */ (0, U.jsx)(J, {
										tone: "zinc",
										children: "BOT"
									})
								}) : null]
							}),
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-3 py-2 font-mono text-xs",
								children: e.steamId
							}),
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-3 py-2 hidden sm:table-cell font-mono text-xs",
								children: e.userid == null ? "—" : `#${e.userid}`
							}),
							/* @__PURE__ */ (0, U.jsxs)("td", {
								className: "px-3 py-2 hidden md:table-cell text-xs",
								style: { color: "var(--muted-foreground)" },
								children: [
									e.frag ?? "—",
									" / ",
									e.ping ?? "—"
								]
							}),
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, U.jsxs)("div", {
									className: "flex justify-end gap-1.5",
									onClick: (e) => e.stopPropagation(),
									children: [/* @__PURE__ */ (0, U.jsxs)(G, {
										size: "xs",
										variant: "outline",
										disabled: f != null,
										onClick: () => b(e),
										children: [f === `kick-${e.userid ?? e.name}` ? /* @__PURE__ */ (0, U.jsx)($, { className: "h-3 w-3" }) : null, " Kick"]
									}), /* @__PURE__ */ (0, U.jsxs)(G, {
										size: "xs",
										variant: "danger",
										disabled: f != null || e.isBot,
										onClick: () => x(e),
										children: [f === `ban-${e.userid ?? e.name}` ? /* @__PURE__ */ (0, U.jsx)($, { className: "h-3 w-3" }) : null, " Ban"]
									})]
								})
							})
						]
					}, t);
				}) })]
			})
		}),
		v ? /* @__PURE__ */ (0, U.jsxs)("p", {
			className: "mt-2 text-xs",
			style: { color: "var(--muted-foreground)" },
			children: [
				"Selected ",
				/* @__PURE__ */ (0, U.jsx)("span", {
					className: "font-mono",
					children: v.name
				}),
				" (",
				v.steamId,
				") — the reason and ban-minutes fields above apply to the Kick / Ban buttons."
			]
		}) : null,
		h ? /* @__PURE__ */ (0, U.jsx)("p", {
			className: "mt-2 text-xs text-amber-300",
			children: h
		}) : null
	] });
}
function et({ serverId: e, chat: t, notices: n, useAmx: r, onSent: i }) {
	let [a, o] = (0, m.useState)(""), [s, c] = (0, m.useState)(!1), [l, u] = (0, m.useState)(""), [d, f] = (0, m.useState)(!0), [p, h] = (0, m.useState)(!1), [g, _] = (0, m.useState)(null), v = (0, m.useRef)(null);
	(0, m.useEffect)(() => {
		v.current?.scrollIntoView({ block: "nearest" });
	}, [t.length, n.length]);
	let y = (0, m.useMemo)(() => {
		let e = l.trim().toLowerCase();
		return (e ? t.filter((t) => t.name.toLowerCase().includes(e) || t.message.toLowerCase().includes(e)) : t).slice(-120);
	}, [t, l]), b = async () => {
		let t = a.trim();
		if (!(!t || p)) {
			h(!0), _(null);
			try {
				await oe(e, t, {
					team: s,
					useAmx: r
				}), o(""), i?.();
			} catch (e) {
				_(e?.message || "Failed to send chat");
			} finally {
				h(!1);
			}
		}
	};
	return /* @__PURE__ */ (0, U.jsxs)(K, {
		className: "flex flex-col min-h-[420px]",
		children: [
			/* @__PURE__ */ (0, U.jsx)(q, { children: /* @__PURE__ */ (0, U.jsxs)("span", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, U.jsx)(k, { className: "h-4 w-4" }),
					" Live chat (",
					t.length,
					")"
				]
			}) }),
			/* @__PURE__ */ (0, U.jsxs)("div", {
				className: "flex gap-2 mb-2",
				children: [/* @__PURE__ */ (0, U.jsx)(Y, {
					placeholder: "Filter chat…",
					value: l,
					onChange: (e) => u(e.target.value)
				}), /* @__PURE__ */ (0, U.jsx)(G, {
					size: "sm",
					variant: d ? "default" : "outline",
					onClick: () => f((e) => !e),
					children: "Joins"
				})]
			}),
			/* @__PURE__ */ (0, U.jsxs)("div", {
				className: "flex-1 min-h-[240px] max-h-[360px] overflow-y-auto space-y-1.5 rounded-md border border-border bg-black/20 p-2",
				children: [
					y.length === 0 && (!d || n.length === 0) ? /* @__PURE__ */ (0, U.jsxs)("p", {
						className: "text-xs p-2",
						style: { color: "var(--muted-foreground)" },
						children: [
							"No chat yet. Player ",
							/* @__PURE__ */ (0, U.jsx)("span", {
								className: "font-mono",
								children: "say"
							}),
							" and ",
							/* @__PURE__ */ (0, U.jsx)("span", {
								className: "font-mono",
								children: "say_team"
							}),
							" ",
							"lines appear here live. Use the box below to write into the game as admin."
						]
					}) : null,
					y.map((e) => /* @__PURE__ */ (0, U.jsxs)("div", {
						className: "text-[13px] leading-snug",
						children: [
							/* @__PURE__ */ (0, U.jsxs)("span", {
								className: "inline-flex items-center gap-1 mr-1.5",
								children: [
									Ye(e.team),
									e.isTeam ? /* @__PURE__ */ (0, U.jsx)(J, {
										tone: "purple",
										children: "TEAM"
									}) : null,
									e.isDead ? /* @__PURE__ */ (0, U.jsx)(J, {
										tone: "zinc",
										children: "DEAD"
									}) : null
								]
							}),
							/* @__PURE__ */ (0, U.jsx)("span", {
								className: "font-semibold",
								children: e.name
							}),
							/* @__PURE__ */ (0, U.jsx)("span", {
								className: "font-mono text-[11px] ml-1",
								style: { color: "var(--muted-foreground)" },
								children: e.steamId
							}),
							/* @__PURE__ */ (0, U.jsxs)("span", { children: [": ", e.message] })
						]
					}, e.key)),
					d ? n.slice(-20).map((e) => /* @__PURE__ */ (0, U.jsxs)("div", {
						className: "text-[12px]",
						style: { color: "var(--muted-foreground)" },
						children: [
							e.kind === "connected" ? `→ ${e.name} connected` : null,
							e.kind === "disconnected" ? `← ${e.name} left` : null,
							e.kind === "entered" ? `• ${e.name} entered the game` : null,
							e.kind === "team-join" ? `• ${e.name} joined a team` : null
						]
					}, e.key)) : null,
					/* @__PURE__ */ (0, U.jsx)("div", { ref: v })
				]
			}),
			/* @__PURE__ */ (0, U.jsxs)("div", {
				className: "flex gap-2 mt-3",
				children: [
					/* @__PURE__ */ (0, U.jsx)(Y, {
						placeholder: r ? "Admin message (amx_say)…" : "Admin message (say)…",
						value: a,
						onChange: (e) => o(e.target.value),
						onKeyDown: (e) => {
							e.key === "Enter" && b();
						},
						maxLength: 256
					}),
					/* @__PURE__ */ (0, U.jsx)(G, {
						size: "sm",
						variant: s ? "default" : "outline",
						onClick: () => c((e) => !e),
						title: "Send as team chat",
						children: "Team"
					}),
					/* @__PURE__ */ (0, U.jsxs)(G, {
						size: "sm",
						onClick: () => void b(),
						disabled: p || !a.trim(),
						children: [p ? /* @__PURE__ */ (0, U.jsx)($, {}) : /* @__PURE__ */ (0, U.jsx)(ee, { className: "h-3.5 w-3.5" }), " Say"]
					})
				]
			}),
			g ? /* @__PURE__ */ (0, U.jsx)("p", {
				className: "mt-2 text-xs text-red-300",
				children: g
			}) : null,
			/* @__PURE__ */ (0, U.jsxs)("p", {
				className: "mt-1 text-[11px]",
				style: { color: "var(--muted-foreground)" },
				children: ["Live feed · ", r ? "AMX mode" : "vanilla say"]
			})
		]
	});
}
function tt({ match: e, serverId: t, useAmx: n, onChanged: r }) {
	let [i, a] = (0, m.useState)(""), [o, s] = (0, m.useState)(null), [c, l] = (0, m.useState)(null), u = async (e, t) => {
		s(e), l(null);
		try {
			let e = await t();
			l(`Command sent${e?.transport === "rcon" ? " via RCON." : " via console."}`), a(""), r?.();
		} catch (e) {
			l(e?.message || "Command failed");
		} finally {
			s(null);
		}
	};
	return /* @__PURE__ */ (0, U.jsxs)(K, {
		className: "min-h-[420px]",
		children: [
			/* @__PURE__ */ (0, U.jsx)(q, { children: /* @__PURE__ */ (0, U.jsxs)("span", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, U.jsx)(F, { className: "h-4 w-4" }), " Rounds and map"]
			}) }),
			/* @__PURE__ */ (0, U.jsxs)("div", {
				className: "flex items-center gap-6 mb-3",
				children: [
					/* @__PURE__ */ (0, U.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, U.jsx)("div", {
							className: "text-[11px] uppercase tracking-wide",
							style: { color: "var(--muted-foreground)" },
							children: "CT"
						}), /* @__PURE__ */ (0, U.jsx)("div", {
							className: "text-3xl font-bold text-sky-300",
							children: e.ctScore
						})]
					}),
					/* @__PURE__ */ (0, U.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, U.jsx)("div", {
							className: "text-[11px] uppercase tracking-wide",
							style: { color: "var(--muted-foreground)" },
							children: "Round"
						}), /* @__PURE__ */ (0, U.jsx)("div", {
							className: "text-3xl font-bold",
							children: e.round || "—"
						})]
					}),
					/* @__PURE__ */ (0, U.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, U.jsx)("div", {
							className: "text-[11px] uppercase tracking-wide",
							style: { color: "var(--muted-foreground)" },
							children: "T"
						}), /* @__PURE__ */ (0, U.jsx)("div", {
							className: "text-3xl font-bold text-red-300",
							children: e.tScore
						})]
					}),
					/* @__PURE__ */ (0, U.jsx)("div", {
						className: "text-sm",
						style: { color: "var(--muted-foreground)" },
						children: e.map ? /* @__PURE__ */ (0, U.jsxs)("span", { children: ["Map ", /* @__PURE__ */ (0, U.jsx)("span", {
							className: "font-mono text-foreground",
							children: e.map
						})] }) : "Map unknown yet"
					})
				]
			}),
			e.history.length === 0 ? /* @__PURE__ */ (0, U.jsxs)("p", {
				className: "text-xs mb-3",
				style: { color: "var(--muted-foreground)" },
				children: [
					"Round history builds from ",
					/* @__PURE__ */ (0, U.jsx)("span", {
						className: "font-mono",
						children: "Round_Start"
					}),
					" / ",
					/* @__PURE__ */ (0, U.jsx)("span", {
						className: "font-mono",
						children: "Round_End"
					}),
					" ",
					"and ",
					/* @__PURE__ */ (0, U.jsx)("span", {
						className: "font-mono",
						children: "Team scored"
					}),
					" lines. Scores also sync from status-driven score lines."
				]
			}) : /* @__PURE__ */ (0, U.jsx)("div", {
				className: "mb-3 max-h-40 overflow-y-auto rounded-md border border-border",
				children: /* @__PURE__ */ (0, U.jsxs)("table", {
					className: "w-full text-xs",
					children: [/* @__PURE__ */ (0, U.jsx)("thead", { children: /* @__PURE__ */ (0, U.jsxs)("tr", {
						className: "text-left uppercase tracking-wide",
						style: { color: "var(--muted-foreground)" },
						children: [
							/* @__PURE__ */ (0, U.jsx)("th", {
								className: "px-2 py-1",
								children: "Round"
							}),
							/* @__PURE__ */ (0, U.jsx)("th", {
								className: "px-2 py-1",
								children: "Winner"
							}),
							/* @__PURE__ */ (0, U.jsx)("th", {
								className: "px-2 py-1",
								children: "CT : T"
							})
						]
					}) }), /* @__PURE__ */ (0, U.jsx)("tbody", { children: [...e.history].slice(-12).reverse().map((e) => /* @__PURE__ */ (0, U.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-2 py-1 font-mono",
								children: e.round
							}),
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-2 py-1",
								children: e.winner === "CT" ? /* @__PURE__ */ (0, U.jsx)(J, {
									tone: "blue",
									children: "CT"
								}) : e.winner === "T" ? /* @__PURE__ */ (0, U.jsx)(J, {
									tone: "red",
									children: "T"
								}) : /* @__PURE__ */ (0, U.jsx)(J, {
									tone: "zinc",
									children: "Draw"
								})
							}),
							/* @__PURE__ */ (0, U.jsxs)("td", {
								className: "px-2 py-1 font-mono",
								children: [
									e.ctScore,
									" : ",
									e.tScore
								]
							})
						]
					}, e.round)) })]
				})
			}),
			/* @__PURE__ */ (0, U.jsxs)("div", {
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ (0, U.jsx)(Y, {
						placeholder: "Map name, e.g. de_dust2",
						value: i,
						onChange: (e) => a(e.target.value)
					}),
					/* @__PURE__ */ (0, U.jsxs)(G, {
						size: "sm",
						disabled: o != null || !i.trim(),
						onClick: () => void u("map", () => de(t, i.trim(), n)),
						children: [o === "map" ? /* @__PURE__ */ (0, U.jsx)($, {}) : null, " Change map"]
					}),
					/* @__PURE__ */ (0, U.jsxs)(G, {
						size: "sm",
						variant: "outline",
						disabled: o != null,
						onClick: () => void u("restart", () => fe(t, 1)),
						children: [o === "restart" ? /* @__PURE__ */ (0, U.jsx)($, {}) : /* @__PURE__ */ (0, U.jsx)(N, { className: "h-3.5 w-3.5" }), " Restart"]
					})
				]
			}),
			c ? /* @__PURE__ */ (0, U.jsx)("p", {
				className: "mt-2 text-xs text-amber-300",
				children: c
			}) : null
		]
	});
}
function nt({ serverId: e, bans: t, defaultMinutes: n, useAmx: r, onChanged: i, now: a }) {
	let [o, s] = (0, m.useState)(""), [c, l] = (0, m.useState)(""), [u, d] = (0, m.useState)(String(n || 1440)), [f, p] = (0, m.useState)(""), [h, g] = (0, m.useState)(""), [_, v] = (0, m.useState)(!1), [y, b] = (0, m.useState)(null), [x, S] = (0, m.useState)(null);
	(0, m.useEffect)(() => {
		d(String(n || 1440));
	}, [n]);
	let C = async () => {
		if (!(!o.trim() || _)) {
			v(!0), b(null);
			try {
				await ce(e, {
					steamId: o.trim(),
					name: c.trim() || void 0,
					minutes: Number(u) || 0,
					reason: f.trim() || void 0,
					useAmx: r
				}), s(""), l(""), p(""), await i();
			} catch (e) {
				b(e?.message || "Ban failed");
			} finally {
				v(!1);
			}
		}
	}, w = async (t) => {
		v(!0), b(null), S(null);
		try {
			let n = await le(e, t.steamId, r);
			S(`Unbanned ${t.steamId}${n.transport === "rcon" ? " via RCON." : " via console."}`), await i();
		} catch (e) {
			b(e?.message || "Unban failed");
		} finally {
			v(!1);
		}
	}, E = async () => {
		if (!(!h.trim() || _)) {
			v(!0), b(null), S(null);
			try {
				let t = h.trim(), n = await le(e, t, r);
				S(`Unbanned ${t}${n.transport === "rcon" ? " via RCON." : " via console."}`), g(""), await i();
			} catch (e) {
				b(e?.message || "Unban failed");
			} finally {
				v(!1);
			}
		}
	}, D = t.filter((e) => (e.status ?? "active") === "active");
	return /* @__PURE__ */ (0, U.jsxs)(K, { children: [
		/* @__PURE__ */ (0, U.jsx)(q, { children: /* @__PURE__ */ (0, U.jsxs)("span", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, U.jsx)(T, { className: "h-4 w-4" }),
				" Bans (",
				D.length,
				" active)"
			]
		}) }),
		/* @__PURE__ */ (0, U.jsxs)("div", {
			className: "grid grid-cols-1 md:grid-cols-[1fr_1fr_140px_1fr_auto] gap-2 mb-3",
			children: [
				/* @__PURE__ */ (0, U.jsx)(Y, {
					placeholder: "SteamID, e.g. STEAM_0:1:12345",
					value: o,
					onChange: (e) => s(e.target.value),
					className: "font-mono"
				}),
				/* @__PURE__ */ (0, U.jsx)(Y, {
					placeholder: "Player name (optional)",
					value: c,
					onChange: (e) => l(e.target.value)
				}),
				/* @__PURE__ */ (0, U.jsx)(Y, {
					placeholder: "Minutes (0 = permanent)",
					value: u,
					onChange: (e) => d(e.target.value),
					inputMode: "numeric"
				}),
				/* @__PURE__ */ (0, U.jsx)(Y, {
					placeholder: "Reason (optional)",
					value: f,
					onChange: (e) => p(e.target.value)
				}),
				/* @__PURE__ */ (0, U.jsxs)(G, {
					size: "sm",
					onClick: () => void C(),
					disabled: _ || !o.trim(),
					children: [_ ? /* @__PURE__ */ (0, U.jsx)($, {}) : /* @__PURE__ */ (0, U.jsx)(M, { className: "h-3.5 w-3.5" }), " Ban"]
				})
			]
		}),
		y ? /* @__PURE__ */ (0, U.jsx)("p", {
			className: "mb-2 text-xs text-red-300",
			children: y
		}) : null,
		x ? /* @__PURE__ */ (0, U.jsx)("p", {
			className: "mb-2 text-xs text-emerald-300",
			children: x
		}) : null,
		/* @__PURE__ */ (0, U.jsxs)("div", {
			className: "flex flex-col sm:flex-row gap-2 mb-2",
			children: [/* @__PURE__ */ (0, U.jsx)(Y, {
				placeholder: "Unban any SteamID, e.g. STEAM_0:1:12345",
				value: h,
				onChange: (e) => g(e.target.value),
				onKeyDown: (e) => {
					e.key === "Enter" && E();
				},
				className: "font-mono"
			}), /* @__PURE__ */ (0, U.jsxs)(G, {
				size: "sm",
				variant: "outline",
				onClick: () => void E(),
				disabled: _ || !h.trim(),
				children: [_ ? /* @__PURE__ */ (0, U.jsx)($, {}) : null, " Unban SteamID"]
			})]
		}),
		/* @__PURE__ */ (0, U.jsx)("p", {
			className: "text-[11px] mb-3",
			style: { color: "var(--muted-foreground)" },
			children: "Unbanning works for any ban on the server, including ones made outside this tab or before the plugin was installed. Matching entries in the list below are marked as unbanned."
		}),
		t.length === 0 ? /* @__PURE__ */ (0, U.jsxs)("p", {
			className: "text-sm",
			style: { color: "var(--muted-foreground)" },
			children: [
				"No bans recorded by this tab yet. Bans issued here are enforced with",
				" ",
				/* @__PURE__ */ (0, U.jsx)("span", {
					className: "font-mono",
					children: "banid"
				}),
				" / ",
				/* @__PURE__ */ (0, U.jsx)("span", {
					className: "font-mono",
					children: "amx_ban"
				}),
				" and stored so they survive restarts."
			]
		}) : /* @__PURE__ */ (0, U.jsx)("div", {
			className: "max-h-64 overflow-y-auto rounded-md border border-border",
			children: /* @__PURE__ */ (0, U.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, U.jsx)("thead", { children: /* @__PURE__ */ (0, U.jsxs)("tr", {
					className: "text-left text-xs uppercase tracking-wide",
					style: { color: "var(--muted-foreground)" },
					children: [
						/* @__PURE__ */ (0, U.jsx)("th", {
							className: "px-3 py-2",
							children: "SteamID / Name"
						}),
						/* @__PURE__ */ (0, U.jsx)("th", {
							className: "px-3 py-2 hidden sm:table-cell",
							children: "Length"
						}),
						/* @__PURE__ */ (0, U.jsx)("th", {
							className: "px-3 py-2 hidden md:table-cell",
							children: "When"
						}),
						/* @__PURE__ */ (0, U.jsx)("th", {
							className: "px-3 py-2 text-right",
							children: "Status"
						})
					]
				}) }), /* @__PURE__ */ (0, U.jsx)("tbody", { children: t.slice(0, 50).map((e) => {
					let t = e.id ?? e._id ?? `${e.steamId}-${e.createdAt}`, n = (e.status ?? "active") === "active";
					return /* @__PURE__ */ (0, U.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, U.jsxs)("td", {
								className: "px-3 py-2",
								children: [/* @__PURE__ */ (0, U.jsx)("div", {
									className: "font-mono text-xs",
									children: e.steamId
								}), /* @__PURE__ */ (0, U.jsxs)("div", {
									className: "text-xs",
									style: { color: "var(--muted-foreground)" },
									children: [e.name ?? "—", e.reason ? ` · ${e.reason}` : ""]
								})]
							}),
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-3 py-2 hidden sm:table-cell text-xs",
								children: e.minutes === 0 ? "permanent" : `${e.minutes}m`
							}),
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-3 py-2 hidden md:table-cell text-xs",
								style: { color: "var(--muted-foreground)" },
								children: qe(e.createdAt, a)
							}),
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-3 py-2 text-right",
								children: n ? /* @__PURE__ */ (0, U.jsx)(G, {
									size: "xs",
									variant: "outline",
									disabled: _,
									onClick: () => void w(e),
									children: "Unban"
								}) : /* @__PURE__ */ (0, U.jsx)(J, {
									tone: "zinc",
									children: e.status
								})
							})
						]
					}, t);
				}) })]
			})
		})
	] });
}
var rt = [
	{
		cvar: "mp_timelimit",
		label: "Time limit (min)",
		placeholder: "20"
	},
	{
		cvar: "mp_maxrounds",
		label: "Max rounds",
		placeholder: "0"
	},
	{
		cvar: "mp_winlimit",
		label: "Win limit",
		placeholder: "0"
	},
	{
		cvar: "mp_freezetime",
		label: "Freeze time (s)",
		placeholder: "6"
	},
	{
		cvar: "mp_roundtime",
		label: "Round time (min)",
		placeholder: "2.5"
	},
	{
		cvar: "sv_password",
		label: "Server password",
		placeholder: "empty = public"
	},
	{
		cvar: "hostname",
		label: "Hostname",
		placeholder: "My CS 1.6 Server"
	},
	{
		cvar: "sv_alltalk",
		label: "Alltalk (0/1)",
		placeholder: "0"
	}
];
function it({ serverId: e, settings: t, transport: n, onSettingsChanged: r, onTransportChanged: i, onChanged: a, auditRefreshKey: o }) {
	let [s, c] = (0, m.useState)({}), [l, u] = (0, m.useState)(null), [d, f] = (0, m.useState)(""), [p, h] = (0, m.useState)(null), [g, _] = (0, m.useState)(""), [v, y] = (0, m.useState)(!1), [b, x] = (0, m.useState)(null), [S, C] = (0, m.useState)(null), [w, T] = (0, m.useState)(!1), [E, D] = (0, m.useState)("auto"), [O, k] = (0, m.useState)(""), [A, j] = (0, m.useState)(""), [M, N] = (0, m.useState)(""), [P, F] = (0, m.useState)(!1), [I, L] = (0, m.useState)(null);
	(0, m.useEffect)(() => {
		t && (D(t.transport ?? "auto"), k(t.rconHost ?? ""), j(t.rconPort ? String(t.rconPort) : ""));
	}, [
		t?.transport,
		t?.rconHost,
		t?.rconPort
	]);
	let R = (e) => e === "rcon" ? " via RCON." : " via console.", te = async (t) => {
		let n = (s[t] ?? "").trim();
		if (n) {
			u(t), x(null);
			try {
				let r = await pe(e, t, n);
				x(`${t} sent${R(r.transport)}`), await a();
			} catch (e) {
				x(e?.message || "Cvar failed");
			} finally {
				u(null);
			}
		}
	}, ne = async (t) => {
		if (!d.trim()) {
			x("AMX needs a target (#userid or name).");
			return;
		}
		h(t), x(null);
		try {
			let n = await me(e, t, d.trim());
			x(`amx_${t} sent${R(n.transport)}`), await a();
		} catch (e) {
			x(e?.message || "AMX command failed");
		} finally {
			h(null);
		}
	}, B = async () => {
		if (!(!g.trim() || v)) {
			y(!0), x(null);
			try {
				let t = await ae(e, g.trim());
				x(`Command sent${R(t.transport)}`), _(""), await a();
			} catch (e) {
				x(e?.message || "Command failed");
			} finally {
				y(!1);
			}
		}
	}, re = async () => {
		F(!0), x(null);
		try {
			let t = {
				transport: E,
				rconHost: O.trim(),
				rconPort: A.trim() === "" ? 0 : Number(A)
			};
			M && (t.rconPassword = M), r(await z(e, t)), N(""), i(await ie(e).catch(() => null)), await a(), x("Transport settings saved.");
		} catch (e) {
			x(e?.message || "Failed to save transport settings");
		} finally {
			F(!1);
		}
	}, H = async () => {
		F(!0), L(null);
		try {
			let t = await V(e);
			L(`RCON ok (${t.latencyMs}ms, via ${t.source}): ${String(t.output || "").split("\n")[0].slice(0, 120)}`);
		} catch (e) {
			L(e?.message || "RCON test failed");
		} finally {
			F(!1);
		}
	}, oe = async () => {
		if (t) try {
			r(await z(e, { useAmx: !t.useAmx }));
		} catch (e) {
			x(e?.message || "Failed to save settings");
		}
	}, se = async () => {
		if (t) try {
			r(await z(e, { enabled: !t.enabled })), await a();
		} catch (e) {
			x(e?.message || "Failed to save settings");
		}
	}, ce = async () => {
		if (T((e) => !e), !S) try {
			let t = await _e(e);
			C(t.available ? t.files : { "banned.cfg": "(file tunnel unavailable)" });
		} catch (e) {
			C({ error: e?.message || "Failed to load ban files" });
		}
	};
	return /* @__PURE__ */ (0, U.jsxs)("div", {
		className: "grid grid-cols-1 xl:grid-cols-2 gap-4",
		children: [
			/* @__PURE__ */ (0, U.jsxs)(K, { children: [
				/* @__PURE__ */ (0, U.jsx)(q, { children: "Match settings" }),
				/* @__PURE__ */ (0, U.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3",
					children: rt.map((e) => /* @__PURE__ */ (0, U.jsxs)("div", {
						className: "flex gap-1.5",
						children: [/* @__PURE__ */ (0, U.jsx)(Y, {
							placeholder: `${e.label} (${e.cvar})`,
							value: s[e.cvar] ?? "",
							onChange: (t) => c((n) => ({
								...n,
								[e.cvar]: t.target.value
							})),
							title: e.cvar
						}), /* @__PURE__ */ (0, U.jsx)(G, {
							size: "sm",
							variant: "outline",
							disabled: l != null,
							onClick: () => void te(e.cvar),
							children: l === e.cvar ? /* @__PURE__ */ (0, U.jsx)($, {}) : "Set"
						})]
					}, e.cvar))
				}),
				/* @__PURE__ */ (0, U.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, U.jsx)(J, {
							tone: t?.enabled === !1 ? "zinc" : "green",
							children: t?.enabled === !1 ? "Disabled for this server" : "Enabled for this server"
						}),
						/* @__PURE__ */ (0, U.jsx)(G, {
							size: "sm",
							variant: "outline",
							onClick: () => void se(),
							children: t?.enabled === !1 ? "Enable for this server" : "Disable for this server"
						}),
						/* @__PURE__ */ (0, U.jsx)(J, {
							tone: t?.useAmx ? "green" : "zinc",
							children: t?.useAmx ? "AMX mode" : "Vanilla mode"
						}),
						/* @__PURE__ */ (0, U.jsxs)(G, {
							size: "sm",
							variant: "outline",
							onClick: () => void oe(),
							children: [
								"Use ",
								t?.useAmx ? "vanilla" : "AMX",
								" commands"
							]
						}),
						/* @__PURE__ */ (0, U.jsxs)(J, {
							tone: "zinc",
							children: [t?.defaultBanMinutes ?? 1440, " min default ban"]
						})
					]
				}),
				/* @__PURE__ */ (0, U.jsxs)("div", {
					className: "mt-4 border-t border-border pt-3",
					children: [
						/* @__PURE__ */ (0, U.jsx)("div", {
							className: "text-xs font-semibold uppercase tracking-wide mb-2",
							style: { color: "var(--muted-foreground)" },
							children: "Command transport (RCON / console)"
						}),
						n ? /* @__PURE__ */ (0, U.jsx)("p", {
							className: "text-xs mb-2",
							style: { color: "var(--muted-foreground)" },
							children: n.rcon.available ? /* @__PURE__ */ (0, U.jsxs)("span", { children: [
								"RCON reachable at ",
								/* @__PURE__ */ (0, U.jsxs)("span", {
									className: "font-mono",
									children: [
										n.rcon.host,
										":",
										n.rcon.port
									]
								}),
								" (password from ",
								n.rcon.source,
								")."
							] }) : /* @__PURE__ */ (0, U.jsxs)("span", { children: [
								"RCON unavailable: ",
								n.rcon.reason,
								" Commands use console input."
							] })
						}) : null,
						/* @__PURE__ */ (0, U.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-2 mb-2",
							children: [
								/* @__PURE__ */ (0, U.jsxs)(He, {
									value: E,
									onValueChange: D,
									placeholder: "Transport mode",
									children: [
										/* @__PURE__ */ (0, U.jsx)(X, {
											value: "auto",
											children: "Auto (RCON when available)"
										}),
										/* @__PURE__ */ (0, U.jsx)(X, {
											value: "rcon",
											children: "RCON only"
										}),
										/* @__PURE__ */ (0, U.jsx)(X, {
											value: "stdin",
											children: "Console input only"
										})
									]
								}),
								/* @__PURE__ */ (0, U.jsx)(Y, {
									type: "password",
									placeholder: t?.rconConfigured ? "RCON password stored (enter new to replace)" : "RCON password (or set rcon_password in server.cfg)",
									value: M,
									onChange: (e) => N(e.target.value),
									autoComplete: "off"
								}),
								/* @__PURE__ */ (0, U.jsx)(Y, {
									placeholder: "RCON host (blank = server address)",
									value: O,
									onChange: (e) => k(e.target.value),
									className: "font-mono"
								}),
								/* @__PURE__ */ (0, U.jsx)(Y, {
									placeholder: "RCON port (blank = game port)",
									value: A,
									onChange: (e) => j(e.target.value),
									inputMode: "numeric",
									className: "font-mono"
								})
							]
						}),
						/* @__PURE__ */ (0, U.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, U.jsxs)(G, {
								size: "sm",
								variant: "outline",
								disabled: P,
								onClick: () => void re(),
								children: [P ? /* @__PURE__ */ (0, U.jsx)($, {}) : null, " Save transport"]
							}), /* @__PURE__ */ (0, U.jsxs)(G, {
								size: "sm",
								variant: "outline",
								disabled: P,
								onClick: () => void H(),
								children: [P ? /* @__PURE__ */ (0, U.jsx)($, {}) : null, " Test RCON"]
							})]
						}),
						I ? /* @__PURE__ */ (0, U.jsx)("p", {
							className: "mt-2 text-xs text-amber-300",
							children: I
						}) : null
					]
				}),
				b ? /* @__PURE__ */ (0, U.jsx)("p", {
					className: "mt-2 text-xs text-amber-300",
					children: b
				}) : null
			] }),
			/* @__PURE__ */ (0, U.jsxs)(K, { children: [
				/* @__PURE__ */ (0, U.jsx)(q, { children: "Quick AMX and console" }),
				/* @__PURE__ */ (0, U.jsx)("div", {
					className: "flex gap-2 mb-2",
					children: /* @__PURE__ */ (0, U.jsx)(Y, {
						placeholder: "Target #userid or name",
						value: d,
						onChange: (e) => f(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, U.jsx)("div", {
					className: "flex flex-wrap gap-1.5 mb-3",
					children: [
						"slap",
						"slay",
						"gag",
						"ungag",
						"mute",
						"unmute"
					].map((e) => /* @__PURE__ */ (0, U.jsxs)(G, {
						size: "xs",
						variant: "outline",
						disabled: p != null,
						onClick: () => void ne(e),
						children: [
							p === e ? /* @__PURE__ */ (0, U.jsx)($, { className: "h-3 w-3" }) : null,
							" amx_",
							e
						]
					}, e))
				}),
				/* @__PURE__ */ (0, U.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, U.jsx)(Y, {
						placeholder: "Validated command, e.g. status, say hello, mp_timelimit 20",
						value: g,
						onChange: (e) => _(e.target.value),
						onKeyDown: (e) => {
							e.key === "Enter" && B();
						},
						className: "font-mono"
					}), /* @__PURE__ */ (0, U.jsxs)(G, {
						size: "sm",
						onClick: () => void B(),
						disabled: v || !g.trim(),
						children: [v ? /* @__PURE__ */ (0, U.jsx)($, {}) : /* @__PURE__ */ (0, U.jsx)(ee, { className: "h-3.5 w-3.5" }), " Send"]
					})]
				}),
				/* @__PURE__ */ (0, U.jsxs)("div", {
					className: "mt-3",
					children: [/* @__PURE__ */ (0, U.jsxs)(G, {
						size: "sm",
						variant: "ghost",
						onClick: () => void ce(),
						children: [w ? "Hide" : "Show", " ban files (banned.cfg / listip.cfg)"]
					}), w && S ? /* @__PURE__ */ (0, U.jsx)("div", {
						className: "mt-2 space-y-2 max-h-48 overflow-y-auto",
						children: Object.entries(S).map(([e, t]) => /* @__PURE__ */ (0, U.jsxs)("div", { children: [/* @__PURE__ */ (0, U.jsx)("div", {
							className: "font-mono text-[11px]",
							style: { color: "var(--muted-foreground)" },
							children: e
						}), /* @__PURE__ */ (0, U.jsx)("pre", {
							className: "whitespace-pre-wrap break-all rounded bg-black/30 p-2 text-[11px] font-mono max-h-32 overflow-y-auto",
							children: t || "(empty)"
						})] }, e))
					}) : null]
				})
			] }),
			/* @__PURE__ */ (0, U.jsx)(ot, {
				serverId: e,
				refreshKey: o
			})
		]
	});
}
var at = [
	"command",
	"say",
	"kick",
	"ban",
	"unban",
	"map",
	"restart",
	"cvar",
	"amx_slap",
	"amx_slay",
	"amx_gag",
	"amx_ungag",
	"amx_mute",
	"amx_unmute",
	"refresh-players",
	"settings",
	"rcon-test"
];
function ot({ serverId: e, refreshKey: t }) {
	let [n, r] = (0, m.useState)(""), [i, a] = (0, m.useState)(""), [o, s] = (0, m.useState)(""), [c, l] = (0, m.useState)(""), [u, d] = (0, m.useState)(""), [f, p] = (0, m.useState)(""), [h, g] = (0, m.useState)(1), [_, v] = (0, m.useState)(null), [y, b] = (0, m.useState)(!0), [x, S] = (0, m.useState)(null), C = Ke(), w = (0, m.useCallback)(async () => {
		b(!0), S(null);
		try {
			let t = await he(e, {
				user: n || void 0,
				action: i || void 0,
				search: c || void 0,
				from: u || void 0,
				to: f || void 0,
				page: h,
				pageSize: 20
			});
			v(t);
		} catch (e) {
			S(e?.message || "Failed to load audit log");
		} finally {
			b(!1);
		}
	}, [
		e,
		n,
		i,
		c,
		u,
		f,
		h
	]);
	(0, m.useEffect)(() => {
		g(1);
	}, [
		e,
		n,
		i,
		c,
		u,
		f
	]), (0, m.useEffect)(() => {
		w();
	}, [w]), (0, m.useEffect)(() => {
		t && w();
	}, [t]), (0, m.useEffect)(() => {
		let e = setInterval(() => {
			w();
		}, 15e3);
		return () => clearInterval(e);
	}, [w]);
	let T = _ ? Math.max(1, Math.ceil(_.total / _.pageSize)) : 1, E = ge(e, {
		user: n || void 0,
		action: i || void 0,
		search: c || void 0,
		from: u || void 0,
		to: f || void 0
	});
	return /* @__PURE__ */ (0, U.jsxs)(K, {
		className: "xl:col-span-2",
		children: [
			/* @__PURE__ */ (0, U.jsx)(q, { children: /* @__PURE__ */ (0, U.jsxs)("span", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, U.jsx)(j, { className: "h-4 w-4" }),
					" Audit log",
					_ ? /* @__PURE__ */ (0, U.jsxs)("span", {
						className: "font-normal",
						style: { color: "var(--muted-foreground)" },
						children: [
							"(",
							_.total,
							")"
						]
					}) : null
				]
			}) }),
			/* @__PURE__ */ (0, U.jsxs)("div", {
				className: "grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-2 mb-3",
				children: [
					/* @__PURE__ */ (0, U.jsxs)(He, {
						value: n,
						onValueChange: r,
						placeholder: "All users",
						children: [n ? /* @__PURE__ */ (0, U.jsx)(X, {
							value: n,
							children: _?.users.find((e) => e.id === n)?.name ?? n
						}) : null, (_?.users ?? []).filter((e) => e.id !== n).map((e) => /* @__PURE__ */ (0, U.jsx)(X, {
							value: e.id,
							children: e.name
						}, e.id))]
					}),
					/* @__PURE__ */ (0, U.jsx)(He, {
						value: i,
						onValueChange: a,
						placeholder: "All actions",
						children: at.map((e) => /* @__PURE__ */ (0, U.jsx)(X, {
							value: e,
							children: e
						}, e))
					}),
					/* @__PURE__ */ (0, U.jsx)(Y, {
						placeholder: "Search command, target…",
						value: o,
						onChange: (e) => s(e.target.value),
						onKeyDown: (e) => {
							e.key === "Enter" && l(o.trim());
						}
					}),
					/* @__PURE__ */ (0, U.jsx)(Y, {
						type: "date",
						"aria-label": "From date",
						value: u,
						onChange: (e) => d(e.target.value)
					}),
					/* @__PURE__ */ (0, U.jsx)(Y, {
						type: "date",
						"aria-label": "To date",
						value: f,
						onChange: (e) => p(e.target.value)
					}),
					/* @__PURE__ */ (0, U.jsxs)("div", {
						className: "flex gap-1.5",
						children: [/* @__PURE__ */ (0, U.jsx)(G, {
							size: "sm",
							variant: "outline",
							onClick: () => l(o.trim()),
							children: "Filter"
						}), /* @__PURE__ */ (0, U.jsx)(G, {
							size: "sm",
							variant: "ghost",
							onClick: () => {
								r(""), a(""), s(""), l(""), d(""), p("");
							},
							children: "Clear"
						})]
					})
				]
			}),
			x ? /* @__PURE__ */ (0, U.jsx)("p", {
				className: "mb-2 text-xs text-red-300",
				children: x
			}) : null,
			y && !_ ? /* @__PURE__ */ (0, U.jsx)(Z, { className: "h-40 w-full" }) : !_ || _.actions.length === 0 ? /* @__PURE__ */ (0, U.jsx)("p", {
				className: "text-sm",
				style: { color: "var(--muted-foreground)" },
				children: "No audit entries match. Every kick, ban, map change, cvar, raw command, chat message and settings change from this tab is recorded here with the admin who did it."
			}) : /* @__PURE__ */ (0, U.jsx)("div", {
				className: "max-h-80 overflow-y-auto rounded-md border border-border",
				children: /* @__PURE__ */ (0, U.jsxs)("table", {
					className: "w-full text-xs",
					children: [/* @__PURE__ */ (0, U.jsx)("thead", { children: /* @__PURE__ */ (0, U.jsxs)("tr", {
						className: "text-left uppercase tracking-wide",
						style: { color: "var(--muted-foreground)" },
						children: [
							/* @__PURE__ */ (0, U.jsx)("th", {
								className: "px-3 py-2",
								children: "When"
							}),
							/* @__PURE__ */ (0, U.jsx)("th", {
								className: "px-3 py-2",
								children: "User"
							}),
							/* @__PURE__ */ (0, U.jsx)("th", {
								className: "px-3 py-2",
								children: "Action"
							}),
							/* @__PURE__ */ (0, U.jsx)("th", {
								className: "px-3 py-2 hidden sm:table-cell",
								children: "Target"
							}),
							/* @__PURE__ */ (0, U.jsx)("th", {
								className: "px-3 py-2 hidden md:table-cell",
								children: "Command"
							})
						]
					}) }), /* @__PURE__ */ (0, U.jsx)("tbody", { children: _.actions.map((e) => /* @__PURE__ */ (0, U.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-3 py-1.5 whitespace-nowrap",
								title: e.createdAt ?? "",
								style: { color: "var(--muted-foreground)" },
								children: qe(e.createdAt, C)
							}),
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-3 py-1.5 font-medium",
								title: e.createdBy ?? "",
								children: e.createdByName || e.createdBy || "—"
							}),
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-3 py-1.5",
								children: /* @__PURE__ */ (0, U.jsx)(J, {
									tone: "zinc",
									children: e.action
								})
							}),
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-3 py-1.5 hidden sm:table-cell font-mono",
								children: e.target ?? "—"
							}),
							/* @__PURE__ */ (0, U.jsx)("td", {
								className: "px-3 py-1.5 hidden md:table-cell font-mono max-w-64 truncate",
								title: e.detail ?? e.command,
								children: e.command
							})
						]
					}, e.id ?? e._id ?? `${e.command}-${e.createdAt}`)) })]
				})
			}),
			/* @__PURE__ */ (0, U.jsxs)("div", {
				className: "mt-2 flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, U.jsx)(G, {
						size: "sm",
						variant: "outline",
						disabled: h <= 1 || y,
						onClick: () => g((e) => Math.max(1, e - 1)),
						children: "Previous"
					}),
					/* @__PURE__ */ (0, U.jsxs)("span", {
						className: "text-xs",
						style: { color: "var(--muted-foreground)" },
						children: [
							"Page ",
							_?.page ?? h,
							" of ",
							T,
							_ ? ` · ${_.total} entr${_.total === 1 ? "y" : "ies"}` : ""
						]
					}),
					/* @__PURE__ */ (0, U.jsx)(G, {
						size: "sm",
						variant: "outline",
						disabled: !_ || h >= T || y,
						onClick: () => g((e) => e + 1),
						children: "Next"
					}),
					/* @__PURE__ */ (0, U.jsx)("div", { className: "flex-1" }),
					/* @__PURE__ */ (0, U.jsxs)(G, {
						size: "sm",
						variant: "ghost",
						disabled: y,
						onClick: () => void w(),
						children: [y ? /* @__PURE__ */ (0, U.jsx)($, {}) : /* @__PURE__ */ (0, U.jsx)(A, { className: "h-3.5 w-3.5" }), " Refresh"]
					}),
					/* @__PURE__ */ (0, U.jsx)("a", {
						href: E,
						download: !0,
						children: /* @__PURE__ */ (0, U.jsxs)(G, {
							size: "sm",
							variant: "outline",
							type: "button",
							children: [/* @__PURE__ */ (0, U.jsx)(D, { className: "h-3.5 w-3.5" }), " Export CSV"]
						})
					})
				]
			})
		]
	});
}
//#endregion
//#region frontend/index.ts
var st = l({
	manifest: {
		name: "cs16-admin",
		version: "1.3.0",
		displayName: "CS 1.6 Server Admin",
		description: "Live management for CS 1.6 servers: chat, players, rounds, kick, ban and match control",
		author: "Catalyst Team"
	},
	tabs: [{
		id: "cs16-admin",
		label: "CS 1.6 Admin",
		icon: "Crosshair",
		component: Xe,
		location: "server",
		order: 20,
		requiredPermissions: ["server.read"],
		templateFilter: {
			namePattern: "(counter[ -]?strike|\\bcs\\b|\\bhlds\\b|cstrike)[\\s\\S]*1\\.6|1\\.6[\\s\\S]*(counter[ -]?strike|\\bcs\\b|\\bhlds\\b|cstrike)|cstrike",
			env: { HLDS_GAME: "cstrike" }
		}
	}]
});
//#endregion
export { st as default };
