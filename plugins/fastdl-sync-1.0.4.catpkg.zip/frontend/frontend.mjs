//#region \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), s = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, c = (n, r, o) => (o = n == null ? {} : e(i(n)), s(r || !n || !n.__esModule || !a.call(n, "default") ? t(o, "default", {
	value: n,
	enumerable: !0
}) : o, n));
//#endregion
//#region ../sdk-frontend/plugin.ts
function l(e) {
	return {
		manifest: e.manifest,
		tabs: e.tabs,
		routes: e.routes,
		components: e.components,
		onMount: e.onMount,
		onUnmount: e.onUnmount
	};
}
//#endregion
//#region ../sdk-frontend/api.ts
var u = "";
async function d(e, t, n) {
	let { method: r = "GET", body: i, headers: a } = n ?? {}, o = `${u}/api/plugins/${e}/${t.replace(/^\//, "")}`;
	try {
		let e = await fetch(o, {
			method: r,
			credentials: "include",
			headers: {
				...i !== void 0 && !(i instanceof FormData) ? { "Content-Type": "application/json" } : {},
				...a
			},
			body: i === void 0 ? void 0 : i instanceof FormData ? i : JSON.stringify(i)
		});
		if (!e.ok) {
			let t = `HTTP ${e.status}`;
			try {
				let n = await e.json();
				t = n.error || n.message || t;
			} catch {}
			return {
				success: !1,
				error: t
			};
		}
		let t = await e.json();
		return t && typeof t == "object" && "success" in t ? t : {
			success: !0,
			data: t
		};
	} catch (e) {
		return {
			success: !1,
			error: e instanceof Error ? e.message : "Network error"
		};
	}
}
function f(e) {
	return {
		get(t) {
			return d(e, t);
		},
		post(t, n) {
			return d(e, t, {
				method: "POST",
				body: n
			});
		},
		put(t, n) {
			return d(e, t, {
				method: "PUT",
				body: n
			});
		},
		del(t) {
			return d(e, t, { method: "DELETE" });
		},
		patch(t, n) {
			return d(e, t, {
				method: "PATCH",
				body: n
			});
		}
	};
}
//#endregion
//#region ../node_modules/.pnpm/react@19.2.8/node_modules/react/cjs/react.production.js
var p = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element"), n = Symbol.for("react.consumer"), r = Symbol.for("react.context"), i = Symbol.for("react.forward_ref"), a = {
		isMounted: function() {
			return !1;
		},
		enqueueForceUpdate: function() {},
		enqueueReplaceState: function() {},
		enqueueSetState: function() {}
	}, o = Object.assign, s = {};
	function c(e, t, n) {
		this.props = e, this.context = t, this.refs = s, this.updater = n || a;
	}
	c.prototype.isReactComponent = {}, c.prototype.setState = function(e, t) {
		if (typeof e != "object" && typeof e != "function" && e != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
		this.updater.enqueueSetState(this, e, t, "setState");
	}, c.prototype.forceUpdate = function(e) {
		this.updater.enqueueForceUpdate(this, e, "forceUpdate");
	};
	function l() {}
	l.prototype = c.prototype;
	function u(e, t, n) {
		this.props = e, this.context = t, this.refs = s, this.updater = n || a;
	}
	var d = u.prototype = new l();
	d.constructor = u, o(d, c.prototype), d.isPureReactComponent = !0, Array.isArray;
	var f = {
		H: null,
		A: null,
		T: null,
		S: null
	}, p = Object.prototype.hasOwnProperty;
	function m(e, n, r) {
		var i = r.ref;
		return {
			$$typeof: t,
			type: e,
			key: n,
			ref: i === void 0 ? null : i,
			props: r
		};
	}
	e.Component = c, e.createContext = function(e) {
		return e = {
			$$typeof: r,
			_currentValue: e,
			_currentValue2: e,
			_threadCount: 0,
			Provider: null,
			Consumer: null
		}, e.Provider = e, e.Consumer = {
			$$typeof: n,
			_context: e
		}, e;
	}, e.createElement = function(e, t, n) {
		var r, i = {}, a = null;
		if (t != null) for (r in t.key !== void 0 && (a = "" + t.key), t) p.call(t, r) && r !== "key" && r !== "__self" && r !== "__source" && (i[r] = t[r]);
		var o = arguments.length - 2;
		if (o === 1) i.children = n;
		else if (1 < o) {
			for (var s = Array(o), c = 0; c < o; c++) s[c] = arguments[c + 2];
			i.children = s;
		}
		if (e && e.defaultProps) for (r in o = e.defaultProps, o) i[r] === void 0 && (i[r] = o[r]);
		return m(e, a, i);
	}, e.forwardRef = function(e) {
		return {
			$$typeof: i,
			render: e
		};
	}, e.useCallback = function(e, t) {
		return f.H.useCallback(e, t);
	}, e.useContext = function(e) {
		return f.H.useContext(e);
	}, e.useEffect = function(e, t) {
		return f.H.useEffect(e, t);
	}, e.useState = function(e) {
		return f.H.useState(e);
	};
})), m = /* @__PURE__ */ c((/* @__PURE__ */ o(((e, t) => {
	t.exports = p();
})))(), 1);
m.Component;
//#endregion
//#region ../node_modules/.pnpm/lucide-react@1.31.0_react@19.2.8/node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs
var h = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), g = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), _ = (e) => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()), v = (e) => {
	let t = _(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, y = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "round",
	strokeLinejoin: "round"
}, b = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, x = (0, m.createContext)({}), S = () => (0, m.useContext)(x), C = (0, m.forwardRef)(({ color: e, size: t, strokeWidth: n, absoluteStrokeWidth: r, className: i = "", children: a, iconNode: o, ...s }, c) => {
	let { size: l = 24, strokeWidth: u = 2, absoluteStrokeWidth: d = !1, color: f = "currentColor", className: p = "" } = S() ?? {}, g = r ?? d ? Number(n ?? u) * 24 / Number(t ?? l) : n ?? u;
	return (0, m.createElement)("svg", {
		ref: c,
		...y,
		width: t ?? l ?? y.width,
		height: t ?? l ?? y.height,
		stroke: e ?? f,
		strokeWidth: g,
		className: h("lucide", p, i),
		...!a && !b(s) && { "aria-hidden": "true" },
		...s
	}, [...o.map(([e, t]) => (0, m.createElement)(e, t)), ...Array.isArray(a) ? a : [a]]);
}), w = (e, t) => {
	let n = (0, m.forwardRef)(({ className: n, ...r }, i) => (0, m.createElement)(C, {
		ref: i,
		iconNode: t,
		className: h(`lucide-${g(v(e))}`, `lucide-${e}`, n),
		...r
	}));
	return n.displayName = v(e), n;
}, T = w("circle-check", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}], ["path", {
	d: "m9 12 2 2 4-4",
	key: "dzmm74"
}]]), E = w("clock", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}], ["path", {
	d: "M12 6v6l4 2",
	key: "mmk7yg"
}]]), D = w("copy", [["rect", {
	width: "14",
	height: "14",
	x: "8",
	y: "8",
	rx: "2",
	ry: "2",
	key: "17jyea"
}], ["path", {
	d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
	key: "zix9uf"
}]]), O = w("download", [
	["path", {
		d: "M12 15V3",
		key: "m9g1x1"
	}],
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}],
	["path", {
		d: "m7 10 5 5 5-5",
		key: "brsn70"
	}]
]), k = w("loader-circle", [["path", {
	d: "M21 12a9 9 0 1 1-6.219-8.56",
	key: "13zald"
}]]), A = w("plus", [["path", {
	d: "M5 12h14",
	key: "1ays0h"
}], ["path", {
	d: "M12 5v14",
	key: "s699le"
}]]), j = w("refresh-cw", [
	["path", {
		d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
		key: "v9h5vc"
	}],
	["path", {
		d: "M21 3v5h-5",
		key: "1q7to0"
	}],
	["path", {
		d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
		key: "3uifl3"
	}],
	["path", {
		d: "M8 16H3v5",
		key: "1cv678"
	}]
]), M = w("trash-2", [
	["path", {
		d: "M10 11v6",
		key: "nco0om"
	}],
	["path", {
		d: "M14 11v6",
		key: "outv1u"
	}],
	["path", {
		d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",
		key: "miytrc"
	}],
	["path", {
		d: "M3 6h18",
		key: "d0wm0j"
	}],
	["path", {
		d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
		key: "e791ji"
	}]
]), N = w("triangle-alert", [
	["path", {
		d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
		key: "wmoenq"
	}],
	["path", {
		d: "M12 9v4",
		key: "juzpu7"
	}],
	["path", {
		d: "M12 17h.01",
		key: "p32p05"
	}]
]), P = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element");
	function n(e, n, r) {
		var i = null;
		if (r !== void 0 && (i = "" + r), n.key !== void 0 && (i = "" + n.key), "key" in n) for (var a in r = {}, n) a !== "key" && (r[a] = n[a]);
		else r = n;
		return n = r.ref, {
			$$typeof: t,
			type: e,
			key: i,
			ref: n === void 0 ? null : n,
			props: r
		};
	}
	e.jsx = n, e.jsxs = n;
})), F = (/* @__PURE__ */ o(((e, t) => {
	t.exports = P();
})))(), I = "text-muted-foreground", L = "font-mono", R = (...e) => e.filter(Boolean).join(" ");
function z({ variant: e = "default", size: t = "default", className: n, ...r }) {
	return /* @__PURE__ */ (0, F.jsx)("button", {
		className: R("inline-flex items-center justify-center gap-1.5 rounded-md font-medium transition-colors disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring", {
			default: "h-9 px-4 py-2 text-sm",
			sm: "h-7 rounded-md px-2.5 text-xs"
		}[t], {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			outline: "border border-border bg-transparent shadow-sm hover:bg-accent hover:text-accent-foreground",
			ghost: "hover:bg-accent hover:text-accent-foreground"
		}[e], n),
		...r
	});
}
function B({ value: e, onValueChange: t, placeholder: n, children: r }) {
	return /* @__PURE__ */ (0, F.jsxs)("select", {
		className: "flex h-9 w-full items-center rounded-md border border-border bg-transparent px-3 py-1 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
		value: e || "",
		onChange: (e) => t(e.target.value),
		children: [/* @__PURE__ */ (0, F.jsx)("option", {
			value: "",
			disabled: !0,
			children: n ?? "Select…"
		}), r]
	});
}
function V({ value: e, children: t }) {
	return /* @__PURE__ */ (0, F.jsx)("option", {
		value: e,
		className: "bg-popover text-popover-foreground",
		children: t
	});
}
function H({ className: e }) {
	return /* @__PURE__ */ (0, F.jsx)("div", { className: R("animate-pulse rounded-md bg-muted", e) });
}
function U({ label: e, value: t }) {
	return /* @__PURE__ */ (0, F.jsxs)("div", {
		className: "rounded-lg border border-border bg-card p-4",
		children: [/* @__PURE__ */ (0, F.jsx)("div", {
			className: R("text-xs font-medium uppercase tracking-wide", I),
			children: e
		}), /* @__PURE__ */ (0, F.jsx)("div", {
			className: "mt-1 text-2xl font-bold",
			children: t
		})]
	});
}
//#endregion
//#region frontend/api.ts
var W = f("fastdl-sync");
async function G() {
	return (await W.get("/pairings")).pairings ?? [];
}
async function K() {
	return (await W.get("/candidates")).servers ?? [];
}
async function q(e) {
	return W.post("/pairings", e);
}
async function J(e) {
	await W.delete(`/pairings/${e}`);
}
async function Y(e) {
	await W.post(`/pairings/${e}/sync`, {});
}
//#endregion
//#region frontend/components.tsx
function X(e) {
	if (!e) return "never";
	let t = Math.max(0, (Date.now() - Date.parse(e)) / 1e3);
	return t < 60 ? `${Math.floor(t)}s ago` : t < 3600 ? `${Math.floor(t / 60)}m ago` : t < 86400 ? `${Math.floor(t / 3600)}h ago` : `${Math.floor(t / 86400)}d ago`;
}
function Z({ run: e }) {
	return /* @__PURE__ */ (0, F.jsxs)("div", {
		className: "space-y-0.5 py-1",
		children: [/* @__PURE__ */ (0, F.jsxs)("div", {
			className: "flex items-center gap-2 text-xs",
			style: { color: I },
			children: [
				e.ok ? /* @__PURE__ */ (0, F.jsx)(T, { className: "h-3.5 w-3.5 text-emerald-400 shrink-0" }) : /* @__PURE__ */ (0, F.jsx)(N, { className: "h-3.5 w-3.5 text-amber-400 shrink-0" }),
				/* @__PURE__ */ (0, F.jsx)("span", {
					className: "shrink-0",
					children: X(e.startedAt)
				}),
				/* @__PURE__ */ (0, F.jsx)("span", {
					className: "truncate",
					children: e.summary
				})
			]
		}), !e.ok && e.errors?.length ? /* @__PURE__ */ (0, F.jsx)("pre", {
			className: "ml-5 whitespace-pre-wrap break-all rounded bg-zinc-950 px-2 py-1 text-[11px] text-amber-300",
			style: { fontFamily: L },
			children: e.errors.slice(0, 3).join("\n")
		}) : null]
	});
}
function Q({ pairing: e, onSync: t, onDelete: n, syncing: r }) {
	let [i, a] = (0, m.useState)(!1), o = e.fastdlServer?.downloadUrl, s = () => {
		o && navigator.clipboard?.writeText(o).then(() => {
			a(!0), setTimeout(() => a(!1), 1500);
		});
	};
	return /* @__PURE__ */ (0, F.jsxs)("div", {
		className: "rounded-lg border border-zinc-800 bg-zinc-900/60 p-4 space-y-3",
		children: [
			/* @__PURE__ */ (0, F.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, F.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, F.jsxs)("div", {
							className: "flex items-center gap-2 text-sm font-semibold",
							children: [
								/* @__PURE__ */ (0, F.jsx)("span", {
									className: "truncate",
									children: e.sourceServer?.name ?? e.sourceServerUuid
								}),
								/* @__PURE__ */ (0, F.jsx)("span", {
									style: { color: I },
									children: "→"
								}),
								/* @__PURE__ */ (0, F.jsx)("span", {
									className: "truncate text-emerald-400",
									children: e.fastdlServer?.name ?? e.fastdlServerUuid
								})
							]
						}),
						/* @__PURE__ */ (0, F.jsxs)("div", {
							className: "text-xs mt-0.5",
							style: { color: I },
							children: [
								e.fileCount == null ? "not synced yet" : `${e.fileCount} files synced`,
								" · ",
								"last sync ",
								X(e.lastSyncAt)
							]
						}),
						e.lastError ? /* @__PURE__ */ (0, F.jsx)("pre", {
							className: "mt-1 whitespace-pre-wrap break-all rounded bg-zinc-950 px-2 py-1 text-[11px] text-amber-300",
							style: { fontFamily: L },
							children: e.lastError
						}) : null
					]
				}), /* @__PURE__ */ (0, F.jsxs)("div", {
					className: "flex items-center gap-1.5 shrink-0",
					children: [/* @__PURE__ */ (0, F.jsxs)(z, {
						size: "sm",
						variant: "outline",
						onClick: () => t(e.id),
						disabled: r,
						children: [r ? /* @__PURE__ */ (0, F.jsx)(k, { className: "h-3.5 w-3.5 animate-spin" }) : /* @__PURE__ */ (0, F.jsx)(j, { className: "h-3.5 w-3.5" }), "Sync now"]
					}), /* @__PURE__ */ (0, F.jsx)(z, {
						size: "sm",
						variant: "ghost",
						onClick: () => n(e.id),
						"aria-label": "Delete pairing",
						children: /* @__PURE__ */ (0, F.jsx)(M, { className: "h-3.5 w-3.5 text-red-400" })
					})]
				})]
			}),
			o && /* @__PURE__ */ (0, F.jsxs)("div", {
				className: "flex items-center gap-2 text-xs",
				children: [
					/* @__PURE__ */ (0, F.jsx)("span", {
						className: "shrink-0",
						style: { color: "text-muted-foreground" },
						children: "sv_downloadurl"
					}),
					/* @__PURE__ */ (0, F.jsx)("code", {
						className: "flex-1 truncate rounded bg-zinc-950 px-2 py-1 cursor-pointer hover:bg-zinc-800",
						style: { fontFamily: "font-mono" },
						onClick: s,
						title: "Click to copy",
						children: i ? "copied!" : `sv_downloadurl "${o}"`
					}),
					/* @__PURE__ */ (0, F.jsx)(z, {
						size: "sm",
						variant: "ghost",
						onClick: s,
						"aria-label": "Copy",
						children: /* @__PURE__ */ (0, F.jsx)(D, { className: "h-3 w-3" })
					})
				]
			}),
			e.recentRuns?.length > 0 && /* @__PURE__ */ (0, F.jsx)("div", {
				className: "border-t border-zinc-800 pt-2",
				children: e.recentRuns.slice(0, 3).map((e) => /* @__PURE__ */ (0, F.jsx)(Z, { run: e }, e.startedAt))
			})
		]
	});
}
function $() {
	let [e, t] = (0, m.useState)(null), [n, r] = (0, m.useState)(null), [i, a] = (0, m.useState)(""), [o, s] = (0, m.useState)(""), [c, l] = (0, m.useState)(!1), [u, d] = (0, m.useState)(/* @__PURE__ */ new Set()), [f, p] = (0, m.useState)(null), h = (0, m.useCallback)(async () => {
		try {
			let [e, n] = await Promise.all([G(), K()]);
			t(e), r(n);
		} catch (e) {
			p(e?.message ?? "Failed to load"), t([]), r([]);
		}
	}, []);
	(0, m.useEffect)(() => {
		h();
		let e = setInterval(h, 15e3);
		return () => clearInterval(e);
	}, [h]);
	let g = async () => {
		if (!i || !o || c) return;
		let e = n?.find((e) => e.uuid === i), t = n?.find((e) => e.uuid === o);
		if (!(!e || !t)) {
			l(!0), p(null);
			try {
				await q({
					sourceServerUuid: e.uuid,
					fastdlServerUuid: t.uuid,
					sourceServerNodeId: e.nodeId,
					fastdlServerNodeId: t.nodeId
				}), a(""), s(""), await h();
			} catch (e) {
				p(e?.message ?? "Failed to create pairing");
			} finally {
				l(!1);
			}
		}
	}, _ = async (e) => {
		d((t) => new Set(t).add(e));
		try {
			await Y(e), setTimeout(h, 1500), setTimeout(h, 6e3);
		} catch (e) {
			p(e?.message ?? "Sync failed to start");
		} finally {
			setTimeout(() => {
				d((t) => {
					let n = new Set(t);
					return n.delete(e), n;
				});
			}, 6e3);
		}
	}, v = async (e) => {
		try {
			await J(e), await h();
		} catch (e) {
			p(e?.message ?? "Delete failed");
		}
	}, y = n ?? [], b = e?.reduce((e, t) => e + (t.fileCount ?? 0), 0) ?? 0;
	return /* @__PURE__ */ (0, F.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, F.jsxs)("div", { children: [/* @__PURE__ */ (0, F.jsxs)("h2", {
				className: "text-2xl font-bold mb-1 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, F.jsx)(O, { className: "h-6 w-6 text-emerald-400" }), " Auto FastDL"]
			}), /* @__PURE__ */ (0, F.jsxs)("p", {
				className: "text-sm",
				style: { color: I },
				children: [
					"Mirrors game-server content (maps, models, sounds, materials) into FastDL servers. Upload once — joining clients download everything automatically. Add",
					" ",
					/* @__PURE__ */ (0, F.jsx)("code", {
						style: { fontFamily: L },
						children: "sv_downloadurl \"http://<fastdl-ip>:<port>\""
					}),
					" ",
					"on each game server."
				]
			})] }),
			f && /* @__PURE__ */ (0, F.jsxs)("div", {
				className: "flex items-center gap-2 rounded-lg border border-amber-700/40 bg-amber-950/30 px-3 py-2 text-sm text-amber-300",
				children: [
					/* @__PURE__ */ (0, F.jsx)(N, { className: "h-4 w-4 shrink-0" }),
					" ",
					f
				]
			}),
			/* @__PURE__ */ (0, F.jsxs)("div", {
				className: "grid grid-cols-1 sm:grid-cols-3 gap-4",
				children: [
					/* @__PURE__ */ (0, F.jsx)(U, {
						label: "Pairings",
						value: String(e?.length ?? 0)
					}),
					/* @__PURE__ */ (0, F.jsx)(U, {
						label: "Files synced",
						value: String(b)
					}),
					/* @__PURE__ */ (0, F.jsx)(U, {
						label: "Healthy",
						value: e ? String(e.filter((e) => e.recentRuns?.[0]?.ok !== !1).length) : "…"
					})
				]
			}),
			/* @__PURE__ */ (0, F.jsxs)("div", {
				className: "rounded-lg border border-zinc-800 bg-zinc-900/60 p-4",
				children: [/* @__PURE__ */ (0, F.jsxs)("h3", {
					className: "text-sm font-semibold mb-3 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, F.jsx)(A, { className: "h-4 w-4" }), " New pairing"]
				}), /* @__PURE__ */ (0, F.jsxs)("div", {
					className: "grid grid-cols-1 md:grid-cols-[1fr_1fr_auto] gap-3 items-center",
					children: [
						/* @__PURE__ */ (0, F.jsx)(B, {
							value: i,
							onValueChange: a,
							placeholder: "Game server (source)",
							children: y.map((e) => /* @__PURE__ */ (0, F.jsx)(V, {
								value: e.uuid,
								children: e.name
							}, e.uuid))
						}),
						/* @__PURE__ */ (0, F.jsx)(B, {
							value: o,
							onValueChange: s,
							placeholder: "FastDL server (target)",
							children: y.map((e) => /* @__PURE__ */ (0, F.jsx)(V, {
								value: e.uuid,
								children: e.name
							}, e.uuid))
						}),
						/* @__PURE__ */ (0, F.jsx)(z, {
							onClick: g,
							disabled: !i || !o || c,
							children: c ? /* @__PURE__ */ (0, F.jsx)(k, { className: "h-4 w-4 animate-spin" }) : "Pair"
						})
					]
				})]
			}),
			e === null ? /* @__PURE__ */ (0, F.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, F.jsx)(H, { className: "h-24 w-full" }), /* @__PURE__ */ (0, F.jsx)(H, { className: "h-24 w-full" })]
			}) : e.length === 0 ? /* @__PURE__ */ (0, F.jsxs)("div", {
				className: "rounded-lg border border-dashed border-zinc-800 p-8 text-center text-sm",
				style: { color: I },
				children: [/* @__PURE__ */ (0, F.jsx)(E, { className: "h-6 w-6 mx-auto mb-2 opacity-50" }), "No pairings yet. Pair a game server with your FastDL server above."]
			}) : /* @__PURE__ */ (0, F.jsx)("div", {
				className: "grid grid-cols-1 gap-3",
				children: e.map((e) => /* @__PURE__ */ (0, F.jsx)(Q, {
					pairing: e,
					onSync: _,
					onDelete: v,
					syncing: u.has(e.id)
				}, e.id))
			})
		]
	});
}
//#endregion
//#region frontend/index.ts
var ee = l({
	manifest: {
		name: "fastdl-sync",
		version: "1.0.4",
		displayName: "Auto FastDL",
		description: "Automatic FastDL content sync for HL1/Source game servers",
		author: "Catalyst Team"
	},
	tabs: [{
		id: "fastdl-admin",
		label: "Auto FastDL",
		icon: "Download",
		component: $,
		location: "admin",
		order: 85,
		requiredPermissions: ["admin.read"]
	}]
});
//#endregion
export { ee as default };
