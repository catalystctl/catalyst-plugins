//#region \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), s = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, c = (n, r, o) => (o = n == null ? {} : e(i(n)), s(r || !n || !n.__esModule || !a.call(n, "default") ? t(o, "default", {
	value: n,
	enumerable: !0
}) : o, n));
//#endregion
//#region ../sdk-frontend/plugin.ts
function l(e) {
	return {
		manifest: e.manifest,
		tabs: e.tabs,
		routes: e.routes,
		components: e.components,
		onMount: e.onMount,
		onUnmount: e.onUnmount
	};
}
//#endregion
//#region ../sdk-frontend/api.ts
var u = "";
async function d(e, t, n) {
	let { method: r = "GET", body: i, headers: a } = n ?? {}, o = `${u}/api/plugins/${e}/${t.replace(/^\//, "")}`;
	try {
		let e = await fetch(o, {
			method: r,
			credentials: "include",
			headers: {
				...i !== void 0 && !(i instanceof FormData) ? { "Content-Type": "application/json" } : {},
				...a
			},
			body: i === void 0 ? void 0 : i instanceof FormData ? i : JSON.stringify(i)
		});
		if (!e.ok) {
			let t = `HTTP ${e.status}`;
			try {
				let n = await e.json();
				t = n.error || n.message || t;
			} catch {}
			return {
				success: !1,
				error: t
			};
		}
		let t = await e.json();
		return t && typeof t == "object" && "success" in t ? t : {
			success: !0,
			data: t
		};
	} catch (e) {
		return {
			success: !1,
			error: e instanceof Error ? e.message : "Network error"
		};
	}
}
function f(e) {
	return {
		get(t) {
			return d(e, t);
		},
		post(t, n) {
			return d(e, t, {
				method: "POST",
				body: n
			});
		},
		put(t, n) {
			return d(e, t, {
				method: "PUT",
				body: n
			});
		},
		del(t) {
			return d(e, t, { method: "DELETE" });
		},
		delete(t) {
			return d(e, t, { method: "DELETE" });
		},
		patch(t, n) {
			return d(e, t, {
				method: "PATCH",
				body: n
			});
		}
	};
}
//#endregion
//#region ../node_modules/.pnpm/react@19.2.8/node_modules/react/cjs/react.production.js
var p = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element"), n = Symbol.for("react.consumer"), r = Symbol.for("react.context"), i = Symbol.for("react.forward_ref"), a = {
		isMounted: function() {
			return !1;
		},
		enqueueForceUpdate: function() {},
		enqueueReplaceState: function() {},
		enqueueSetState: function() {}
	}, o = Object.assign, s = {};
	function c(e, t, n) {
		this.props = e, this.context = t, this.refs = s, this.updater = n || a;
	}
	c.prototype.isReactComponent = {}, c.prototype.setState = function(e, t) {
		if (typeof e != "object" && typeof e != "function" && e != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
		this.updater.enqueueSetState(this, e, t, "setState");
	}, c.prototype.forceUpdate = function(e) {
		this.updater.enqueueForceUpdate(this, e, "forceUpdate");
	};
	function l() {}
	l.prototype = c.prototype;
	function u(e, t, n) {
		this.props = e, this.context = t, this.refs = s, this.updater = n || a;
	}
	var d = u.prototype = new l();
	d.constructor = u, o(d, c.prototype), d.isPureReactComponent = !0, Array.isArray;
	var f = {
		H: null,
		A: null,
		T: null,
		S: null
	}, p = Object.prototype.hasOwnProperty;
	function m(e, n, r) {
		var i = r.ref;
		return {
			$$typeof: t,
			type: e,
			key: n,
			ref: i === void 0 ? null : i,
			props: r
		};
	}
	e.Component = c, e.createContext = function(e) {
		return e = {
			$$typeof: r,
			_currentValue: e,
			_currentValue2: e,
			_threadCount: 0,
			Provider: null,
			Consumer: null
		}, e.Provider = e, e.Consumer = {
			$$typeof: n,
			_context: e
		}, e;
	}, e.createElement = function(e, t, n) {
		var r, i = {}, a = null;
		if (t != null) for (r in t.key !== void 0 && (a = "" + t.key), t) p.call(t, r) && r !== "key" && r !== "__self" && r !== "__source" && (i[r] = t[r]);
		var o = arguments.length - 2;
		if (o === 1) i.children = n;
		else if (1 < o) {
			for (var s = Array(o), c = 0; c < o; c++) s[c] = arguments[c + 2];
			i.children = s;
		}
		if (e && e.defaultProps) for (r in o = e.defaultProps, o) i[r] === void 0 && (i[r] = o[r]);
		return m(e, a, i);
	}, e.forwardRef = function(e) {
		return {
			$$typeof: i,
			render: e
		};
	}, e.useCallback = function(e, t) {
		return f.H.useCallback(e, t);
	}, e.useContext = function(e) {
		return f.H.useContext(e);
	}, e.useEffect = function(e, t) {
		return f.H.useEffect(e, t);
	}, e.useMemo = function(e, t) {
		return f.H.useMemo(e, t);
	}, e.useState = function(e) {
		return f.H.useState(e);
	};
})), m = /* @__PURE__ */ c((/* @__PURE__ */ o(((e, t) => {
	t.exports = p();
})))(), 1);
m.Component;
//#endregion
//#region ../node_modules/.pnpm/lucide-react@1.31.0_react@19.2.8/node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.mjs
var h = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), g = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), _ = (e) => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()), v = (e) => {
	let t = _(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, y = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	strokeWidth: 2,
	strokeLinecap: "round",
	strokeLinejoin: "round"
}, b = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, x = (0, m.createContext)({}), S = () => (0, m.useContext)(x), C = (0, m.forwardRef)(({ color: e, size: t, strokeWidth: n, absoluteStrokeWidth: r, className: i = "", children: a, iconNode: o, ...s }, c) => {
	let { size: l = 24, strokeWidth: u = 2, absoluteStrokeWidth: d = !1, color: f = "currentColor", className: p = "" } = S() ?? {}, g = r ?? d ? Number(n ?? u) * 24 / Number(t ?? l) : n ?? u;
	return (0, m.createElement)("svg", {
		ref: c,
		...y,
		width: t ?? l ?? y.width,
		height: t ?? l ?? y.height,
		stroke: e ?? f,
		strokeWidth: g,
		className: h("lucide", p, i),
		...!a && !b(s) && { "aria-hidden": "true" },
		...s
	}, [...o.map(([e, t]) => (0, m.createElement)(e, t)), ...Array.isArray(a) ? a : [a]]);
}), w = (e, t) => {
	let n = (0, m.forwardRef)(({ className: n, ...r }, i) => (0, m.createElement)(C, {
		ref: i,
		iconNode: t,
		className: h(`lucide-${g(v(e))}`, `lucide-${e}`, n),
		...r
	}));
	return n.displayName = v(e), n;
}, T = w("circle-check", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}], ["path", {
	d: "m9 12 2 2 4-4",
	key: "dzmm74"
}]]), E = w("circle-x", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "m15 9-6 6",
		key: "1uzhvr"
	}],
	["path", {
		d: "m9 9 6 6",
		key: "z0biqf"
	}]
]), D = w("loader-circle", [["path", {
	d: "M21 12a9 9 0 1 1-6.219-8.56",
	key: "13zald"
}]]), O = w("plus", [["path", {
	d: "M5 12h14",
	key: "1ays0h"
}], ["path", {
	d: "M12 5v14",
	key: "s699le"
}]]), k = w("refresh-cw", [
	["path", {
		d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
		key: "v9h5vc"
	}],
	["path", {
		d: "M21 3v5h-5",
		key: "1q7to0"
	}],
	["path", {
		d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
		key: "3uifl3"
	}],
	["path", {
		d: "M8 16H3v5",
		key: "1cv678"
	}]
]), A = w("trash-2", [
	["path", {
		d: "M10 11v6",
		key: "nco0om"
	}],
	["path", {
		d: "M14 11v6",
		key: "outv1u"
	}],
	["path", {
		d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",
		key: "miytrc"
	}],
	["path", {
		d: "M3 6h18",
		key: "d0wm0j"
	}],
	["path", {
		d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
		key: "e791ji"
	}]
]), ee = /* @__PURE__ */ o(((e) => {
	var t = Symbol.for("react.transitional.element"), n = Symbol.for("react.fragment");
	function r(e, n, r) {
		var i = null;
		if (r !== void 0 && (i = "" + r), n.key !== void 0 && (i = "" + n.key), "key" in n) for (var a in r = {}, n) a !== "key" && (r[a] = n[a]);
		else r = n;
		return n = r.ref, {
			$$typeof: t,
			type: e,
			key: i,
			ref: n === void 0 ? null : n,
			props: r
		};
	}
	e.Fragment = n, e.jsx = r, e.jsxs = r;
})), j = (/* @__PURE__ */ o(((e, t) => {
	t.exports = ee();
})))(), M = "text-muted-foreground", te = "font-mono", N = "#5865F2", P = (...e) => e.filter(Boolean).join(" ");
function F({ variant: e = "default", size: t = "default", className: n, ...r }) {
	let i = {
		default: "h-9 px-4 py-2 text-sm",
		sm: "h-7 rounded-md px-2.5 text-xs"
	}, a = {
		default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
		outline: "border border-border bg-transparent shadow-sm hover:bg-accent hover:text-accent-foreground",
		ghost: "hover:bg-accent hover:text-accent-foreground",
		discord: "text-white shadow hover:opacity-90",
		destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90"
	}, o = e === "discord" ? { backgroundColor: N } : void 0;
	return /* @__PURE__ */ (0, j.jsx)("button", {
		className: P("inline-flex items-center justify-center gap-1.5 rounded-md font-medium transition-colors disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring", i[t], a[e], n),
		style: o,
		...r
	});
}
function I({ className: e, ...t }) {
	return /* @__PURE__ */ (0, j.jsx)("input", {
		className: P("flex h-9 w-full rounded-md border border-border bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", e),
		...t
	});
}
function L({ className: e, ...t }) {
	return /* @__PURE__ */ (0, j.jsx)("label", {
		className: P("text-sm font-medium leading-none", e),
		...t
	});
}
function R({ value: e, onValueChange: t, placeholder: n, children: r, className: i }) {
	return /* @__PURE__ */ (0, j.jsxs)("select", {
		className: P("flex h-9 w-full items-center rounded-md border border-border bg-transparent px-2 py-1 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50", i),
		value: e || "",
		onChange: (e) => t(e.target.value),
		children: [/* @__PURE__ */ (0, j.jsx)("option", {
			value: "",
			disabled: !0,
			children: n ?? "Select…"
		}), r]
	});
}
function z({ value: e, children: t }) {
	return /* @__PURE__ */ (0, j.jsx)("option", {
		value: e,
		className: "bg-popover text-popover-foreground",
		children: t
	});
}
function B({ checked: e, onCheckedChange: t, label: n, description: r }) {
	return /* @__PURE__ */ (0, j.jsxs)("label", {
		className: "flex cursor-pointer items-start gap-2.5",
		children: [/* @__PURE__ */ (0, j.jsx)("input", {
			type: "checkbox",
			checked: e,
			onChange: (e) => t(e.target.checked),
			className: "mt-0.5 h-4 w-4 shrink-0 rounded border-border accent-[var(--primary)]"
		}), /* @__PURE__ */ (0, j.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, j.jsx)("span", {
				className: "block text-sm",
				children: n
			}), r ? /* @__PURE__ */ (0, j.jsx)("span", {
				className: P("block text-xs", M),
				children: r
			}) : null]
		})]
	});
}
function V({ title: e, description: t, children: n, actions: r }) {
	return /* @__PURE__ */ (0, j.jsxs)("div", {
		className: "rounded-lg border border-border bg-card p-4 space-y-3",
		children: [/* @__PURE__ */ (0, j.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, j.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, j.jsx)("h3", {
					className: "text-sm font-semibold tracking-tight",
					children: e
				}), t ? /* @__PURE__ */ (0, j.jsx)("p", {
					className: P("mt-0.5 text-xs", M),
					children: t
				}) : null]
			}), r ? /* @__PURE__ */ (0, j.jsx)("div", {
				className: "flex shrink-0 items-center gap-2",
				children: r
			}) : null]
		}), n]
	});
}
function H({ tone: e = "default", children: t }) {
	return /* @__PURE__ */ (0, j.jsx)("span", {
		className: P("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-medium", {
			default: "border-border bg-muted text-muted-foreground",
			success: "border-emerald-500/40 bg-emerald-500/10 text-emerald-500",
			warn: "border-amber-500/40 bg-amber-500/10 text-amber-500",
			danger: "border-red-500/40 bg-red-500/10 text-red-500"
		}[e]),
		children: t
	});
}
function U({ ok: e, children: t }) {
	return /* @__PURE__ */ (0, j.jsxs)("div", {
		className: "flex items-center gap-1.5 text-xs",
		children: [e ? /* @__PURE__ */ (0, j.jsx)(T, { className: "h-3.5 w-3.5 text-emerald-500 shrink-0" }) : /* @__PURE__ */ (0, j.jsx)(E, { className: "h-3.5 w-3.5 text-red-500 shrink-0" }), /* @__PURE__ */ (0, j.jsx)("span", {
			className: "min-w-0 break-words",
			children: t
		})]
	});
}
function W({ className: e }) {
	return /* @__PURE__ */ (0, j.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		className: P("h-4 w-4", e),
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, j.jsx)("path", { d: "M20.317 4.37a19.79 19.79 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.058a.082.082 0 0 0 .031.056 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128c.126-.094.252-.192.372-.291a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.3 12.3 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.84 19.84 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03ZM8.02 15.331c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418Zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418Z" })
	});
}
//#endregion
//#region frontend/api.ts
var G = f("discord-oauth");
async function K(e) {
	if (!e.success) throw Error(e.error || "Request failed");
	return e;
}
async function ne() {
	return K(await G.get("/settings"));
}
async function q(e) {
	await K(await G.put("/settings", e));
}
async function J() {
	return K(await G.post("/settings/test", {}));
}
async function Y() {
	return K(await G.get("/guild"));
}
async function X() {
	return (await K(await G.get("/panel-roles"))).roles ?? [];
}
async function re(e = 1, t = "") {
	return K(await G.get(`/links?page=${e}&search=${encodeURIComponent(t)}`));
}
async function ie(e) {
	await K(await G.del(`/links/${e}`));
}
async function ae() {
	return (await K(await G.post("/sync", {}))).summary;
}
async function oe() {
	return (await K(await G.get("/me"))).link ?? null;
}
async function se() {
	await K(await G.del("/me"));
}
var ce = "/api/plugins/discord-oauth/link";
//#endregion
//#region frontend/components.tsx
function Z(e) {
	if (!e) return "never";
	let t = Math.max(0, (Date.now() - Date.parse(e)) / 1e3);
	return t < 60 ? `${Math.floor(t)}s ago` : t < 3600 ? `${Math.floor(t / 60)}m ago` : t < 86400 ? `${Math.floor(t / 3600)}h ago` : `${Math.floor(t / 86400)}d ago`;
}
function Q(e) {
	return e ? `#${e.toString(16).padStart(6, "0")}` : void 0;
}
function $({ settings: e, redirectUri: t, onSaved: n }) {
	let [r, i] = (0, m.useState)(e.clientId), [a, o] = (0, m.useState)(""), [s, c] = (0, m.useState)(""), [l, u] = (0, m.useState)(!1), [d, f] = (0, m.useState)(!1), [p, h] = (0, m.useState)(e.guildId), [g, _] = (0, m.useState)(e.frontendUrl), [v, y] = (0, m.useState)(!1), [b, x] = (0, m.useState)(!1), [S, C] = (0, m.useState)(null), [w, T] = (0, m.useState)(null);
	(0, m.useEffect)(() => {
		i(e.clientId), h(e.guildId), _(e.frontendUrl), o(""), c(""), u(!1), f(!1);
	}, [e]);
	let E = async () => {
		y(!0), T(null);
		try {
			await q({
				clientId: r,
				guildId: p,
				frontendUrl: g,
				...a ? { clientSecret: a } : l ? { clientSecret: null } : {},
				...s ? { botToken: s } : d ? { botToken: null } : {}
			}), n();
		} catch (e) {
			T(e.message);
		} finally {
			y(!1);
		}
	}, O = async () => {
		x(!0);
		try {
			C(await J());
		} catch (e) {
			C({
				success: !0,
				oauthConfigured: !1,
				bot: {
					ok: !1,
					error: e.message
				},
				guild: {
					ok: !1,
					error: ""
				}
			});
		} finally {
			x(!1);
		}
	}, k = e.clientId ? `https://discord.com/oauth2/authorize?client_id=${e.clientId}&scope=bot&permissions=0` : null;
	return /* @__PURE__ */ (0, j.jsxs)(V, {
		title: "Discord application",
		description: "OAuth2 client for sign-in, plus an optional bot token for scheduled role sync.",
		actions: /* @__PURE__ */ (0, j.jsxs)(j.Fragment, { children: [/* @__PURE__ */ (0, j.jsxs)(F, {
			variant: "outline",
			size: "sm",
			onClick: O,
			disabled: b,
			children: [b ? /* @__PURE__ */ (0, j.jsx)(D, { className: "h-3 w-3 animate-spin" }) : null, "Test connection"]
		}), /* @__PURE__ */ (0, j.jsxs)(F, {
			size: "sm",
			onClick: E,
			disabled: v,
			children: [v ? /* @__PURE__ */ (0, j.jsx)(D, { className: "h-3 w-3 animate-spin" }) : null, "Save"]
		})] }),
		children: [
			/* @__PURE__ */ (0, j.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, j.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, j.jsx)(L, {
							htmlFor: "do-client-id",
							children: "Client ID"
						}), /* @__PURE__ */ (0, j.jsx)(I, {
							id: "do-client-id",
							value: r,
							onChange: (e) => i(e.target.value),
							placeholder: "1234567890123456789"
						})]
					}),
					/* @__PURE__ */ (0, j.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, j.jsx)(L, {
							htmlFor: "do-guild-id",
							children: "Guild ID"
						}), /* @__PURE__ */ (0, j.jsx)(I, {
							id: "do-guild-id",
							value: p,
							onChange: (e) => h(e.target.value.replace(/\D/g, "")),
							placeholder: "Server ID from Discord (Developer Mode → Copy ID)"
						})]
					}),
					/* @__PURE__ */ (0, j.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, j.jsxs)(L, {
								htmlFor: "do-frontend-url",
								children: ["Public URL ", /* @__PURE__ */ (0, j.jsx)(H, { children: "tunnel / proxy setups" })]
							}),
							/* @__PURE__ */ (0, j.jsx)(I, {
								id: "do-frontend-url",
								value: g,
								onChange: (e) => _(e.target.value),
								placeholder: "https://panel.example.com — set when a tunnel/proxy hides the public hostname"
							}),
							/* @__PURE__ */ (0, j.jsx)("p", {
								className: P("text-[11px]", M),
								children: "The origin users visit. Used for the Discord redirect URI and post-login redirects. Leave empty when the backend receives the real Host header (direct deployments). Required behind Cloudflare Tunnels or a dev proxy, where the backend would otherwise see localhost."
							})
						]
					}),
					/* @__PURE__ */ (0, j.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, j.jsxs)(L, {
								htmlFor: "do-client-secret",
								children: [
									"Client Secret",
									" ",
									e.hasClientSecret ? /* @__PURE__ */ (0, j.jsx)(H, {
										tone: "success",
										children: "configured"
									}) : /* @__PURE__ */ (0, j.jsx)(H, {
										tone: "warn",
										children: "missing"
									})
								]
							}),
							/* @__PURE__ */ (0, j.jsx)(I, {
								id: "do-client-secret",
								type: "password",
								value: a,
								onChange: (e) => o(e.target.value),
								placeholder: e.hasClientSecret ? "•••• (leave blank to keep)" : "Required for sign-in"
							}),
							e.hasClientSecret && !a ? /* @__PURE__ */ (0, j.jsx)(B, {
								checked: l,
								onCheckedChange: u,
								label: "Clear stored secret"
							}) : null
						]
					}),
					/* @__PURE__ */ (0, j.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, j.jsxs)(L, {
								htmlFor: "do-bot-token",
								children: [
									"Bot Token",
									" ",
									e.hasBotToken ? /* @__PURE__ */ (0, j.jsx)(H, {
										tone: "success",
										children: "configured"
									}) : /* @__PURE__ */ (0, j.jsx)(H, { children: "optional" })
								]
							}),
							/* @__PURE__ */ (0, j.jsx)(I, {
								id: "do-bot-token",
								type: "password",
								value: s,
								onChange: (e) => c(e.target.value),
								placeholder: e.hasBotToken ? "•••• (leave blank to keep)" : "Required for scheduled role sync"
							}),
							e.hasBotToken && !s ? /* @__PURE__ */ (0, j.jsx)(B, {
								checked: d,
								onCheckedChange: f,
								label: "Clear stored token"
							}) : null
						]
					})
				]
			}),
			/* @__PURE__ */ (0, j.jsxs)("div", {
				className: "space-y-1 rounded-md border border-border bg-muted/30 p-3 text-xs",
				children: [
					/* @__PURE__ */ (0, j.jsx)("div", {
						className: M,
						children: "Add this redirect URI in the Discord developer portal (OAuth2 → Redirects):"
					}),
					/* @__PURE__ */ (0, j.jsx)("code", {
						className: P("break-all text-[11px]", te),
						children: t
					}),
					/* @__PURE__ */ (0, j.jsx)("div", {
						className: P("mt-1", M),
						children: "Scopes: identify, email, guilds, guilds.members.read"
					}),
					k ? /* @__PURE__ */ (0, j.jsxs)("div", {
						className: P("mt-1", M),
						children: [
							"Invite the bot to your guild, then enable ",
							/* @__PURE__ */ (0, j.jsx)("strong", { children: "Server Members Intent" }),
							" in Bot settings:",
							" ",
							/* @__PURE__ */ (0, j.jsx)("a", {
								href: k,
								target: "_blank",
								rel: "noreferrer",
								className: "underline",
								children: "invite link"
							})
						]
					}) : null
				]
			}),
			S ? /* @__PURE__ */ (0, j.jsxs)("div", {
				className: "space-y-1.5",
				children: [
					/* @__PURE__ */ (0, j.jsx)(U, {
						ok: S.oauthConfigured,
						children: S.oauthConfigured ? "OAuth client configured (client id + secret)." : "OAuth client incomplete — set client ID and secret."
					}),
					S.bot.ok ? /* @__PURE__ */ (0, j.jsxs)(U, {
						ok: !0,
						children: [
							"Bot token valid — signed in as @",
							S.bot.username,
							"."
						]
					}) : /* @__PURE__ */ (0, j.jsxs)(U, {
						ok: !1,
						children: ["Bot: ", S.bot.error || "not configured"]
					}),
					S.guild.ok ? /* @__PURE__ */ (0, j.jsxs)(U, {
						ok: !0,
						children: [
							"Guild “",
							S.guild.name,
							"” reachable",
							S.guild.approximateMemberCount ? ` (~${S.guild.approximateMemberCount} members)` : "",
							"."
						]
					}) : /* @__PURE__ */ (0, j.jsxs)(U, {
						ok: !1,
						children: ["Guild: ", S.guild.error || "not configured"]
					})
				]
			}) : null,
			w ? /* @__PURE__ */ (0, j.jsx)(U, {
				ok: !1,
				children: w
			}) : null
		]
	});
}
function le({ settings: e, discordRoles: t, panelRoles: n, onSaved: r }) {
	let [i, a] = (0, m.useState)(e), [o, s] = (0, m.useState)(!1), [c, l] = (0, m.useState)(null);
	(0, m.useEffect)(() => a(e), [e]);
	let u = (e, t) => a((n) => ({
		...n,
		[e]: t
	})), d = async () => {
		s(!0), l(null);
		try {
			await q({
				requireGuildMembership: i.requireGuildMembership,
				requiredDiscordRoleIds: i.requiredDiscordRoleIds,
				autoRegister: i.autoRegister,
				linkExistingByEmail: i.linkExistingByEmail,
				markEmailVerified: i.markEmailVerified,
				defaultRoleIds: i.defaultRoleIds,
				loginDisabled: i.loginDisabled,
				removeLinkOnLeave: i.removeLinkOnLeave
			}), r();
		} catch (e) {
			l(e.message);
		} finally {
			s(!1);
		}
	}, f = (e, t) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t];
	return /* @__PURE__ */ (0, j.jsxs)(V, {
		title: "Sign-in rules",
		description: "Who may sign in with Discord, and what happens on first sign-in.",
		actions: /* @__PURE__ */ (0, j.jsxs)(F, {
			size: "sm",
			onClick: d,
			disabled: o,
			children: [o ? /* @__PURE__ */ (0, j.jsx)(D, { className: "h-3 w-3 animate-spin" }) : null, "Save"]
		}),
		children: [
			/* @__PURE__ */ (0, j.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, j.jsx)(B, {
						checked: !i.loginDisabled,
						onCheckedChange: (e) => u("loginDisabled", !e),
						label: "Discord sign-in enabled",
						description: "Temporarily hides the “Continue with Discord” button."
					}),
					/* @__PURE__ */ (0, j.jsx)(B, {
						checked: i.requireGuildMembership,
						onCheckedChange: (e) => u("requireGuildMembership", e),
						label: "Require guild membership",
						description: e.guildId ? "Users must be a member of the configured guild to sign in." : "Set a guild ID first."
					}),
					/* @__PURE__ */ (0, j.jsx)(B, {
						checked: i.autoRegister,
						onCheckedChange: (e) => u("autoRegister", e),
						label: "Create accounts on first sign-in",
						description: "New panel accounts are created for unknown Discord users."
					}),
					/* @__PURE__ */ (0, j.jsx)(B, {
						checked: i.linkExistingByEmail,
						onCheckedChange: (e) => u("linkExistingByEmail", e),
						label: "Link existing accounts by matching email",
						description: "A Discord identity with a verified email matching a panel account links to it (standard OIDC trust model)."
					}),
					/* @__PURE__ */ (0, j.jsx)(B, {
						checked: i.markEmailVerified,
						onCheckedChange: (e) => u("markEmailVerified", e),
						label: "Trust Discord email verification",
						description: "Mark created accounts as email-verified (Discord verifies emails)."
					}),
					/* @__PURE__ */ (0, j.jsx)(B, {
						checked: i.removeLinkOnLeave,
						onCheckedChange: (e) => u("removeLinkOnLeave", e),
						label: "Unlink accounts that leave the guild",
						description: "During scheduled syncs, links for users no longer in the guild are removed."
					})
				]
			}),
			t.length > 0 ? /* @__PURE__ */ (0, j.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, j.jsx)(L, { children: "Required Discord roles (any of — empty = no requirement)" }), /* @__PURE__ */ (0, j.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: t.map((e) => {
						let t = i.requiredDiscordRoleIds.includes(e.id);
						return /* @__PURE__ */ (0, j.jsx)("button", {
							type: "button",
							onClick: () => u("requiredDiscordRoleIds", f(i.requiredDiscordRoleIds, e.id)),
							className: P("rounded-full border px-2.5 py-1 text-xs transition-colors", t ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:bg-accent"),
							style: t && Q(e.color) ? {
								color: Q(e.color),
								borderColor: Q(e.color)
							} : void 0,
							children: e.name
						}, e.id);
					})
				})]
			}) : null,
			n.length > 0 ? /* @__PURE__ */ (0, j.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, j.jsx)(L, { children: "Default panel roles for created accounts" }), /* @__PURE__ */ (0, j.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: n.map((e) => {
						let t = i.defaultRoleIds.includes(e.id);
						return /* @__PURE__ */ (0, j.jsx)("button", {
							type: "button",
							onClick: () => u("defaultRoleIds", f(i.defaultRoleIds, e.id)),
							className: P("rounded-full border px-2.5 py-1 text-xs transition-colors", t ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:bg-accent"),
							children: e.name
						}, e.id);
					})
				})]
			}) : null,
			c ? /* @__PURE__ */ (0, j.jsx)(U, {
				ok: !1,
				children: c
			}) : null
		]
	});
}
function ue({ settings: e, discordRoles: t, panelRoles: n, onSaved: r }) {
	let [i, a] = (0, m.useState)(e.roleMappings || []), [o, s] = (0, m.useState)(!1), [c, l] = (0, m.useState)(null);
	return (0, m.useEffect)(() => a(e.roleMappings || []), [e]), /* @__PURE__ */ (0, j.jsxs)(V, {
		title: "Role mappings",
		description: e.syncMode === "addOnly" ? "Discord roles → panel roles. Mappings only ever add panel roles." : "Discord roles → panel roles. Mapped panel roles exactly mirror Discord membership; unmapped panel roles are never touched.",
		actions: /* @__PURE__ */ (0, j.jsxs)(j.Fragment, { children: [/* @__PURE__ */ (0, j.jsxs)(F, {
			variant: "outline",
			size: "sm",
			onClick: () => a((e) => [...e, {
				discordRoleId: "",
				panelRoleId: ""
			}]),
			children: [/* @__PURE__ */ (0, j.jsx)(O, { className: "h-3 w-3" }), "Add"]
		}), /* @__PURE__ */ (0, j.jsxs)(F, {
			size: "sm",
			onClick: async () => {
				s(!0), l(null);
				try {
					await q({ roleMappings: i }), r();
				} catch (e) {
					l(e.message);
				} finally {
					s(!1);
				}
			},
			disabled: o,
			children: [o ? /* @__PURE__ */ (0, j.jsx)(D, { className: "h-3 w-3 animate-spin" }) : null, "Save"]
		})] }),
		children: [i.length === 0 ? /* @__PURE__ */ (0, j.jsx)("div", {
			className: P("text-xs", M),
			children: "No mappings yet — add one to mirror a Discord role onto a panel role. Roles apply on Discord sign-in and during scheduled syncs (bot token required for the latter)."
		}) : /* @__PURE__ */ (0, j.jsxs)("div", {
			className: "space-y-2",
			children: [i.map((e, r) => /* @__PURE__ */ (0, j.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, j.jsx)(R, {
						value: e.discordRoleId,
						placeholder: "Discord role…",
						onValueChange: (e) => a((t) => t.map((t, n) => n === r ? {
							...t,
							discordRoleId: e
						} : t)),
						children: t.map((e) => /* @__PURE__ */ (0, j.jsx)(z, {
							value: e.id,
							children: e.name
						}, e.id))
					}),
					/* @__PURE__ */ (0, j.jsx)("span", {
						className: P("shrink-0 text-xs", M),
						children: "→"
					}),
					/* @__PURE__ */ (0, j.jsx)(R, {
						value: e.panelRoleId,
						placeholder: "Panel role…",
						onValueChange: (e) => a((t) => t.map((t, n) => n === r ? {
							...t,
							panelRoleId: e
						} : t)),
						children: n.map((e) => /* @__PURE__ */ (0, j.jsx)(z, {
							value: e.id,
							children: e.name
						}, e.id))
					}),
					/* @__PURE__ */ (0, j.jsx)(F, {
						variant: "ghost",
						size: "sm",
						className: "shrink-0",
						onClick: () => a((e) => e.filter((e, t) => t !== r)),
						"aria-label": "Remove mapping",
						children: /* @__PURE__ */ (0, j.jsx)(A, { className: "h-3.5 w-3.5" })
					})
				]
			}, r)), t.length === 0 ? /* @__PURE__ */ (0, j.jsx)("div", {
				className: P("text-xs", M),
				children: "Configure the bot token + guild ID and test the connection to load Discord roles."
			}) : null]
		}), c ? /* @__PURE__ */ (0, j.jsx)(U, {
			ok: !1,
			children: c
		}) : null]
	});
}
function de({ settings: e, onSaved: t }) {
	let [n, r] = (0, m.useState)(e.syncEnabled), [i, a] = (0, m.useState)(e.syncSchedule), [o, s] = (0, m.useState)(e.syncMode), [c, l] = (0, m.useState)(!1), [u, d] = (0, m.useState)(!1), [f, p] = (0, m.useState)(null), [h, g] = (0, m.useState)(null);
	return (0, m.useEffect)(() => {
		r(e.syncEnabled), a(e.syncSchedule), s(e.syncMode);
	}, [e]), /* @__PURE__ */ (0, j.jsxs)(V, {
		title: "Role sync",
		description: "Scheduled sync looks up every linked member with the bot token and re-applies mappings.",
		actions: /* @__PURE__ */ (0, j.jsxs)(j.Fragment, { children: [/* @__PURE__ */ (0, j.jsxs)(F, {
			variant: "outline",
			size: "sm",
			onClick: async () => {
				d(!0), p(null), g(null);
				try {
					let e = await ae();
					p(e.skipped ? `Skipped: ${e.skipped}` : `Synced ${e.processed} links — assigned ${e.assigned}, removed ${e.removed}` + (e.errors ? `, ${e.errors} errors` : "") + (e.notInGuild ? `, ${e.notInGuild} not in guild` : ""));
				} catch (e) {
					g(e.message);
				} finally {
					d(!1);
				}
			},
			disabled: u,
			children: [u ? /* @__PURE__ */ (0, j.jsx)(D, { className: "h-3 w-3 animate-spin" }) : /* @__PURE__ */ (0, j.jsx)(k, { className: "h-3 w-3" }), "Sync now"]
		}), /* @__PURE__ */ (0, j.jsxs)(F, {
			size: "sm",
			onClick: async () => {
				l(!0), g(null);
				try {
					await q({
						syncEnabled: n,
						syncSchedule: i,
						syncMode: o
					}), t();
				} catch (e) {
					g(e.message);
				} finally {
					l(!1);
				}
			},
			disabled: c,
			children: [c ? /* @__PURE__ */ (0, j.jsx)(D, { className: "h-3 w-3 animate-spin" }) : null, "Save"]
		})] }),
		children: [
			/* @__PURE__ */ (0, j.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, j.jsx)(B, {
					checked: n,
					onCheckedChange: r,
					label: "Scheduled sync enabled",
					description: "Runs on the cron schedule below (bot token required)."
				}), /* @__PURE__ */ (0, j.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, j.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, j.jsx)(L, {
							htmlFor: "do-sync-schedule",
							children: "Schedule (cron, panel timezone)"
						}), /* @__PURE__ */ (0, j.jsx)(I, {
							id: "do-sync-schedule",
							value: i,
							onChange: (e) => a(e.target.value),
							placeholder: "0 * * * *"
						})]
					}), /* @__PURE__ */ (0, j.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, j.jsx)(L, {
							htmlFor: "do-sync-mode",
							children: "Sync mode"
						}), /* @__PURE__ */ (0, j.jsxs)(R, {
							value: o,
							onValueChange: (e) => s(e),
							children: [/* @__PURE__ */ (0, j.jsx)(z, {
								value: "replaceManaged",
								children: "Mirror — remove panel roles when Discord role is lost"
							}), /* @__PURE__ */ (0, j.jsx)(z, {
								value: "addOnly",
								children: "Additive — never remove panel roles"
							})]
						})]
					})]
				})]
			}),
			f ? /* @__PURE__ */ (0, j.jsx)(U, {
				ok: !h,
				children: f
			}) : null,
			h ? /* @__PURE__ */ (0, j.jsx)(U, {
				ok: !1,
				children: h
			}) : null
		]
	});
}
function fe() {
	let [e, t] = (0, m.useState)(null), [n, r] = (0, m.useState)(1), [i, a] = (0, m.useState)(""), [o, s] = (0, m.useState)(!0), [c, l] = (0, m.useState)(null), u = (0, m.useCallback)(async () => {
		s(!0);
		try {
			t(await re(n, i));
		} catch {
			t({
				links: [],
				total: 0
			});
		} finally {
			s(!1);
		}
	}, [n, i]);
	(0, m.useEffect)(() => {
		u();
	}, [u]);
	let d = e ? Math.max(1, Math.ceil(e.total / 25)) : 1;
	return /* @__PURE__ */ (0, j.jsxs)(V, {
		title: `Linked accounts${e ? ` (${e.total})` : ""}`,
		description: "Panel accounts linked to a Discord identity.",
		children: [
			/* @__PURE__ */ (0, j.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, j.jsx)(I, {
					placeholder: "Search username, email or Discord ID…",
					value: i,
					onChange: (e) => {
						r(1), a(e.target.value);
					},
					className: "max-w-xs"
				}), /* @__PURE__ */ (0, j.jsx)(F, {
					variant: "outline",
					size: "sm",
					onClick: () => void u(),
					disabled: o,
					children: o ? /* @__PURE__ */ (0, j.jsx)(D, { className: "h-3 w-3 animate-spin" }) : /* @__PURE__ */ (0, j.jsx)(k, { className: "h-3 w-3" })
				})]
			}),
			!o && e?.links.length === 0 ? /* @__PURE__ */ (0, j.jsx)("div", {
				className: P("text-xs", M),
				children: "No linked accounts yet."
			}) : /* @__PURE__ */ (0, j.jsx)("div", {
				className: "divide-y divide-border rounded-md border border-border",
				children: (e?.links ?? []).map((e) => /* @__PURE__ */ (0, j.jsxs)("div", {
					className: "flex items-center gap-3 px-3 py-2.5",
					children: [
						e.avatar ? /* @__PURE__ */ (0, j.jsx)("img", {
							src: e.avatar,
							alt: "",
							className: "h-7 w-7 shrink-0 rounded-full"
						}) : /* @__PURE__ */ (0, j.jsx)("div", {
							className: "flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-muted",
							children: /* @__PURE__ */ (0, j.jsx)(W, { className: "h-3.5 w-3.5" })
						}),
						/* @__PURE__ */ (0, j.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, j.jsxs)("div", {
								className: "flex flex-wrap items-center gap-1.5 text-xs",
								children: [
									/* @__PURE__ */ (0, j.jsx)("span", {
										className: "font-medium",
										children: e.globalName || e.username || e.discordId
									}),
									e.panelUsername ? /* @__PURE__ */ (0, j.jsxs)("span", {
										className: M,
										children: ["→ ", e.panelUsername]
									}) : null,
									e.panelBanned ? /* @__PURE__ */ (0, j.jsx)(H, {
										tone: "danger",
										children: "banned"
									}) : null,
									e.lastError ? /* @__PURE__ */ (0, j.jsx)(H, {
										tone: "warn",
										children: e.lastError
									}) : null
								]
							}), /* @__PURE__ */ (0, j.jsxs)("div", {
								className: P("text-[11px]", M),
								children: [
									"linked ",
									Z(e.linkedAt),
									" · synced ",
									Z(e.lastSyncedAt),
									" · ",
									e.roles?.length ?? 0,
									" discord roles"
								]
							})]
						}),
						/* @__PURE__ */ (0, j.jsx)(F, {
							variant: "ghost",
							size: "sm",
							disabled: c === e.userId,
							onClick: async () => {
								l(e.userId);
								try {
									await ie(e.userId), await u();
								} finally {
									l(null);
								}
							},
							children: /* @__PURE__ */ (0, j.jsx)(A, { className: "h-3.5 w-3.5" })
						})
					]
				}, e.userId))
			}),
			d > 1 ? /* @__PURE__ */ (0, j.jsxs)("div", {
				className: "flex items-center justify-between text-xs",
				children: [
					/* @__PURE__ */ (0, j.jsx)(F, {
						variant: "outline",
						size: "sm",
						disabled: n <= 1,
						onClick: () => r((e) => e - 1),
						children: "Previous"
					}),
					/* @__PURE__ */ (0, j.jsxs)("span", {
						className: M,
						children: [
							"Page ",
							n,
							" / ",
							d
						]
					}),
					/* @__PURE__ */ (0, j.jsx)(F, {
						variant: "outline",
						size: "sm",
						disabled: n >= d,
						onClick: () => r((e) => e + 1),
						children: "Next"
					})
				]
			}) : null
		]
	});
}
function pe() {
	let [e, t] = (0, m.useState)(null), [n, r] = (0, m.useState)(null), [i, a] = (0, m.useState)([]), [o, s] = (0, m.useState)(null), c = (0, m.useCallback)(async () => {
		try {
			let [e, n] = await Promise.all([ne(), X().catch(() => [])]);
			if (t(e), a(n), e.config.botToken && e.config.guildId && e.config.hasBotToken) try {
				let e = await Y();
				r({
					name: e.guild.name,
					roles: e.roles
				});
			} catch {
				r(null);
			}
			else r(null);
		} catch (e) {
			s(e.message);
		}
	}, []);
	(0, m.useEffect)(() => {
		c();
	}, [c]);
	let l = e?.config, u = (0, m.useMemo)(() => l ? l.guildId ? n ? /* @__PURE__ */ (0, j.jsx)(H, {
		tone: "success",
		children: n.name
	}) : /* @__PURE__ */ (0, j.jsx)(H, { children: "guild not verified" }) : /* @__PURE__ */ (0, j.jsx)(H, {
		tone: "warn",
		children: "no guild"
	}) : null, [l, n]);
	return o ? /* @__PURE__ */ (0, j.jsx)("div", {
		className: "space-y-4",
		children: /* @__PURE__ */ (0, j.jsx)(V, {
			title: "Discord OAuth",
			description: "Failed to load plugin configuration.",
			children: /* @__PURE__ */ (0, j.jsx)(U, {
				ok: !1,
				children: o
			})
		})
	}) : l ? /* @__PURE__ */ (0, j.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, j.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, j.jsx)(W, { className: "h-5 w-5" }),
					/* @__PURE__ */ (0, j.jsx)("h2", {
						className: "text-lg font-semibold tracking-tight",
						children: "Discord OAuth"
					}),
					u,
					l.loginDisabled ? /* @__PURE__ */ (0, j.jsx)(H, {
						tone: "warn",
						children: "sign-in disabled"
					}) : null,
					/* @__PURE__ */ (0, j.jsxs)("span", {
						className: P("text-xs", M),
						children: [
							l.roleMappings.length,
							" mapping",
							l.roleMappings.length === 1 ? "" : "s",
							" · sync",
							" ",
							l.syncEnabled ? `every ${l.syncSchedule}` : "off"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, j.jsx)($, {
				settings: l,
				redirectUri: e?.redirectUri || "",
				onSaved: () => void c()
			}),
			/* @__PURE__ */ (0, j.jsx)(le, {
				settings: l,
				discordRoles: n?.roles ?? [],
				panelRoles: i,
				onSaved: () => void c()
			}),
			/* @__PURE__ */ (0, j.jsx)(ue, {
				settings: l,
				discordRoles: n?.roles ?? [],
				panelRoles: i,
				onSaved: () => void c()
			}),
			/* @__PURE__ */ (0, j.jsx)(de, {
				settings: l,
				onSaved: () => void c()
			}),
			/* @__PURE__ */ (0, j.jsx)(fe, {})
		]
	}) : /* @__PURE__ */ (0, j.jsx)("div", {
		className: "space-y-4",
		children: /* @__PURE__ */ (0, j.jsx)(V, {
			title: "Discord OAuth",
			children: /* @__PURE__ */ (0, j.jsx)("div", {
				className: P("animate-pulse text-sm", M),
				children: "Loading…"
			})
		})
	});
}
function me() {
	let [e, t] = (0, m.useState)(null), [n, r] = (0, m.useState)(!0), [i, a] = (0, m.useState)(!1), [o, s] = (0, m.useState)(null), c = (0, m.useCallback)(async () => {
		try {
			t(await oe());
		} catch (e) {
			s(e.message);
		} finally {
			r(!1);
		}
	}, []);
	(0, m.useEffect)(() => {
		c();
	}, [c]);
	let l = typeof window < "u" && window.location.search.includes("discord=linked"), u = typeof window < "u" && new URLSearchParams(window.location.search).get("oauthError");
	return /* @__PURE__ */ (0, j.jsxs)("div", {
		className: "rounded-lg border border-border bg-card p-4 space-y-3",
		children: [
			/* @__PURE__ */ (0, j.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, j.jsx)(W, { className: "h-4 w-4" }),
					/* @__PURE__ */ (0, j.jsx)("h3", {
						className: "text-sm font-semibold tracking-tight",
						children: "Discord"
					}),
					e ? /* @__PURE__ */ (0, j.jsx)(H, {
						tone: "success",
						children: "linked"
					}) : /* @__PURE__ */ (0, j.jsx)(H, { children: "not linked" })
				]
			}),
			n ? /* @__PURE__ */ (0, j.jsx)("div", {
				className: P("animate-pulse text-sm", M),
				children: "Loading…"
			}) : e ? /* @__PURE__ */ (0, j.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					e.avatar ? /* @__PURE__ */ (0, j.jsx)("img", {
						src: e.avatar,
						alt: "",
						className: "h-9 w-9 rounded-full"
					}) : null,
					/* @__PURE__ */ (0, j.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, j.jsx)("div", {
							className: "text-xs font-medium",
							children: e.globalName || e.username || e.discordId
						}), /* @__PURE__ */ (0, j.jsxs)("div", {
							className: P("text-[11px]", M),
							children: [
								e.username ? `@${e.username}` : e.discordId,
								" · linked ",
								Z(e.linkedAt)
							]
						})]
					}),
					/* @__PURE__ */ (0, j.jsxs)(F, {
						variant: "outline",
						size: "sm",
						disabled: i,
						onClick: async () => {
							a(!0);
							try {
								await se(), await c();
							} catch (e) {
								s(e.message);
							} finally {
								a(!1);
							}
						},
						children: [i ? /* @__PURE__ */ (0, j.jsx)(D, { className: "h-3 w-3 animate-spin" }) : null, "Unlink"]
					})
				]
			}) : /* @__PURE__ */ (0, j.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, j.jsx)("p", {
					className: P("text-xs", M),
					children: "Link your Discord account to sign in with Discord and receive panel roles from your Discord roles."
				}), /* @__PURE__ */ (0, j.jsxs)(F, {
					variant: "discord",
					size: "sm",
					onClick: () => window.location.href = ce,
					children: [/* @__PURE__ */ (0, j.jsx)(W, { className: "h-3.5 w-3.5" }), "Link Discord"]
				})]
			}),
			l ? /* @__PURE__ */ (0, j.jsx)(U, {
				ok: !0,
				children: "Discord account linked."
			}) : null,
			u ? /* @__PURE__ */ (0, j.jsxs)(U, {
				ok: !1,
				children: [
					"Linking failed (",
					u,
					")."
				]
			}) : null,
			o ? /* @__PURE__ */ (0, j.jsx)(U, {
				ok: !1,
				children: o
			}) : null
		]
	});
}
//#endregion
//#region frontend/index.ts
var he = l({
	manifest: {
		name: "discord-oauth",
		version: "1.0.0",
		displayName: "Discord OAuth",
		description: "Sign in with Discord, link accounts, and sync Discord guild roles to panel roles",
		author: "Catalyst Team"
	},
	tabs: [{
		id: "discord-oauth",
		label: "Discord OAuth",
		icon: "MessageCircle",
		component: pe,
		location: "admin",
		order: 86,
		requiredPermissions: ["admin.read"]
	}],
	components: [{
		slot: "profile-connections",
		component: me,
		order: 10
	}]
});
//#endregion
export { he as default };
